-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 24, 2022 at 08:38 AM
-- Server version: 8.0.28-0ubuntu0.20.04.3
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `g41nsgg`
--

-- --------------------------------------------------------

--
-- Table structure for table `affiliates`
--

CREATE TABLE `affiliates` (
  `id` int NOT NULL,
  `ownerId` int NOT NULL,
  `code` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `usersCount` int NOT NULL DEFAULT '0',
  `uniqueDepositorsCount` int NOT NULL DEFAULT '0',
  `totalDeposited` int NOT NULL DEFAULT '0',
  `totalEarnings` int NOT NULL DEFAULT '0',
  `totalWagered` bigint NOT NULL DEFAULT '0',
  `balance` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_earnings`
--

CREATE TABLE `affiliate_earnings` (
  `id` int NOT NULL,
  `codeId` int NOT NULL,
  `refId` int NOT NULL,
  `type` enum('DEPOSIT','WAGER') NOT NULL,
  `amount` int NOT NULL,
  `feeAmount` int NOT NULL,
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_level_table`
--

CREATE TABLE `affiliate_level_table` (
  `level` int NOT NULL,
  `min` int NOT NULL,
  `max` int NOT NULL,
  `cut` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `auth_external_links`
--

CREATE TABLE `auth_external_links` (
  `accountType` enum('OAUTH_STEAM') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `accountId` varchar(48) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `userId` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `coinpayments_transactions`
--

CREATE TABLE `coinpayments_transactions` (
  `id` int NOT NULL,
  `coinpaymentsId` varchar(64) NOT NULL,
  `currency` varchar(6) NOT NULL,
  `userId` int NOT NULL,
  `type` enum('DEPOSIT','WITHDRAW') NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `cryptoAmount` varchar(32) NOT NULL,
  `fiatAmount` int NOT NULL,
  `coinsAmount` int NOT NULL DEFAULT '0',
  `txId` varchar(128) NOT NULL,
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `coinpayments_wallets`
--

CREATE TABLE `coinpayments_wallets` (
  `id` int NOT NULL,
  `currency` varchar(16) NOT NULL,
  `address` varchar(128) NOT NULL,
  `assignedTo` int NOT NULL,
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `dailycases_history`
--

CREATE TABLE `dailycases_history` (
  `id` int NOT NULL,
  `caseId` int NOT NULL,
  `userId` int NOT NULL,
  `prize` int NOT NULL,
  `ticket` decimal(27,18) NOT NULL,
  `ingredientType` enum('COINS','ITEM') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ingredientItemName` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `ingredientItemPrice` int DEFAULT NULL COMMENT 'As USD',
  `ingredientItemIcon` varchar(192) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `dailycases_opens`
--

CREATE TABLE `dailycases_opens` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `caseId` int NOT NULL,
  `day` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `discord_user_links`
--

CREATE TABLE `discord_user_links` (
  `userId` int NOT NULL,
  `discordUserId` varchar(32) NOT NULL,
  `discordUserName` varchar(64) NOT NULL,
  `discordUserDiscriminator` varchar(16) NOT NULL,
  `accessToken` varchar(64) NOT NULL,
  `refreshToken` varchar(64) NOT NULL,
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `discord_user_redirects`
--

CREATE TABLE `discord_user_redirects` (
  `state` varchar(64) NOT NULL,
  `userId` int NOT NULL,
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `events_rain_pots`
--

CREATE TABLE `events_rain_pots` (
  `id` int NOT NULL,
  `prize` int NOT NULL,
  `state` enum('STARTED','ENDING','ENDED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'STARTED',
  `createdAt` int NOT NULL,
  `lastUpdateMs` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `events_rain_pot_players`
--

CREATE TABLE `events_rain_pot_players` (
  `id` int NOT NULL,
  `potId` int NOT NULL,
  `userId` int NOT NULL,
  `joinedAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_blackjack_rounds`
--

CREATE TABLE `game_blackjack_rounds` (
  `id` int NOT NULL,
  `tableId` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `serverSecret` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `randomOrgSecret` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `verificationLink` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `seed` varchar(156) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `deckCount` tinyint NOT NULL,
  `hash` varchar(156) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `shoeString` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dealerHand` text CHARACTER SET utf8 COLLATE utf8_bin,
  `state` enum('OPEN','CLOSED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'OPEN',
  `createdAt` int NOT NULL,
  `endedAt` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_blackjack_round_bets`
--

CREATE TABLE `game_blackjack_round_bets` (
  `id` int NOT NULL,
  `roundId` int NOT NULL,
  `userId` int NOT NULL,
  `playerOffset` tinyint NOT NULL,
  `handsJson` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `payoutsJson` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `totalBetAmount` int NOT NULL,
  `totalWinnings` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_coinflip_rooms`
--

CREATE TABLE `game_coinflip_rooms` (
  `id` int NOT NULL,
  `ownerId` int NOT NULL,
  `ownerColor` enum('BLACK','RED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ownerSkinsValue` int NOT NULL,
  `ownerChance` float NOT NULL DEFAULT '0',
  `ownerOfferId` int NOT NULL DEFAULT '0',
  `opponentId` int NOT NULL DEFAULT '0',
  `opponentSkinsValue` int NOT NULL DEFAULT '0',
  `opponentChance` float NOT NULL DEFAULT '0',
  `lastOpponentOfferId` int NOT NULL DEFAULT '0',
  `rangeMin` int NOT NULL,
  `rangeMax` int NOT NULL,
  `collectedTaxAmount` int NOT NULL DEFAULT '0',
  `totalSkinsValueWithTax` int NOT NULL DEFAULT '0',
  `serverSecret` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `randomOrgSecret` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `verificationLink` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `seed` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `seedHash` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ticket` decimal(27,18) NOT NULL,
  `winnerId` int NOT NULL DEFAULT '0',
  `winnerColor` enum('BLACK','RED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'BLACK',
  `winningsOfferId` int NOT NULL DEFAULT '0',
  `phase` enum('AWAITING_OWNER_DEPOSIT','AWAITING_OPPONENT','AWAITING_OPPONENT_DEPOSIT','STARTING','FLIPPING','FLIPPED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'AWAITING_OWNER_DEPOSIT',
  `endPhase` enum('AWAITING_CLAIM','CLAIM','DOUBLEDOWN') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'AWAITING_CLAIM',
  `taxPhase` enum('AWAITING_TAX','TAXED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'AWAITING_TAX',
  `taxesCalculated` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` int NOT NULL,
  `lastUpdateMs` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_coinflip_room_items`
--

CREATE TABLE `game_coinflip_room_items` (
  `id` int NOT NULL,
  `roomId` int NOT NULL,
  `type` enum('OWNER','OPPONENT') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `amount` smallint NOT NULL,
  `market_hash_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `image` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `value` int NOT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_crash_rounds`
--

CREATE TABLE `game_crash_rounds` (
  `id` int NOT NULL,
  `serverSecret` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `randomOrgSecret` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `verificationLink` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `houseEdge` float NOT NULL,
  `seedHash` varchar(156) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `multiplier` float NOT NULL,
  `gameDuration` int NOT NULL,
  `hash` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `state` enum('PREPARATION','ROLLING','CRASHED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'PREPARATION',
  `createdAt` int NOT NULL,
  `closedAt` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_crash_round_bets`
--

CREATE TABLE `game_crash_round_bets` (
  `id` int NOT NULL,
  `roundId` int NOT NULL,
  `userId` int NOT NULL,
  `autoCashout` float NOT NULL,
  `amount` int NOT NULL,
  `status` enum('AWAITING','PROCESSED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'AWAITING',
  `cashedOut` tinyint(1) NOT NULL DEFAULT '0',
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_roulette_rounds`
--

CREATE TABLE `game_roulette_rounds` (
  `id` int NOT NULL,
  `serverSecret` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `randomOrgSecret` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `verificationLink` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `seed` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `random` float NOT NULL,
  `roll` tinyint NOT NULL,
  `wobble` float NOT NULL,
  `hash` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `state` enum('PREPARATION','ROLLING','CLOSED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'PREPARATION',
  `createdAt` int NOT NULL,
  `closedAt` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_roulette_round_bets`
--

CREATE TABLE `game_roulette_round_bets` (
  `id` int NOT NULL,
  `roundId` int NOT NULL,
  `userId` int NOT NULL,
  `color` enum('RED','GOLD','BLACK') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `amount` int NOT NULL,
  `status` enum('AWAITING','PROCESSED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'AWAITING',
  `won` tinyint(1) NOT NULL,
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_upgrader_rounds`
--

CREATE TABLE `game_upgrader_rounds` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `houseEdge` float NOT NULL,
  `clientSeed` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `serverSeed` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `randomOrgSecret` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `verificationLink` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `seed` varchar(192) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ticket` decimal(27,18) NOT NULL,
  `rollType` enum('UNDER','OVER') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `inputBetAmount` int NOT NULL DEFAULT '0',
  `outputBetAmount` int NOT NULL,
  `multiplier` float NOT NULL,
  `chance` float NOT NULL,
  `won` tinyint(1) NOT NULL DEFAULT '0',
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_upgrader_round_items`
--

CREATE TABLE `game_upgrader_round_items` (
  `id` int NOT NULL,
  `roundId` int NOT NULL,
  `type` enum('INPUT','OUTPUT') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `app` enum('RUST','CSGO','DOTA2') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `market_hash_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `image` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `game_upgrader_user_inventory`
--

CREATE TABLE `game_upgrader_user_inventory` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `app` enum('RUST','CSGO','DOTA2') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `market_hash_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `image` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `price` int NOT NULL,
  `state` enum('ACTIVE','PLAYED','IN_OFFER','WITHDRAWN','SOLD','SOLD_FORCE') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'ACTIVE',
  `linkedTransactionId` int NOT NULL DEFAULT '0',
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `giftcards`
--

CREATE TABLE `giftcards` (
  `id` int NOT NULL,
  `code` varchar(64) NOT NULL,
  `amount` int NOT NULL,
  `coinsAmount` int NOT NULL DEFAULT '0',
  `usedBy` int NOT NULL DEFAULT '0',
  `usedAt` int NOT NULL DEFAULT '0',
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `global_settings`
--

CREATE TABLE `global_settings` (
  `id` int NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `minBet` int NOT NULL DEFAULT '50',
  `maxBet` int NOT NULL DEFAULT '100000' COMMENT 'As Coins',
  `coinflip_maxBet` int NOT NULL DEFAULT '1234' COMMENT 'As USD',
  `levelScale` float NOT NULL DEFAULT '1.1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `leaderboards`
--

CREATE TABLE `leaderboards` (
  `id` int NOT NULL,
  `type` enum('DAILY','WEEKLY','MONTHLY') NOT NULL,
  `runnerCount` tinyint NOT NULL DEFAULT '0',
  `createdAt` int NOT NULL,
  `state` enum('OPEN','CLOSED') NOT NULL DEFAULT 'OPEN',
  `endsAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leaderboard_prizes`
--

CREATE TABLE `leaderboard_prizes` (
  `id` int NOT NULL,
  `leaderboardId` int NOT NULL,
  `place` tinyint NOT NULL,
  `itemName` varchar(256) NOT NULL,
  `itemIcon` text NOT NULL,
  `itemPrice` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leaderboard_settings`
--

CREATE TABLE `leaderboard_settings` (
  `type` enum('DAILY','WEEKLY','MONTHLY') NOT NULL,
  `prizePlace1` int NOT NULL,
  `prizePlace2` int NOT NULL,
  `prizePlace3` int NOT NULL,
  `prizeRunnerFactorFirstN` float NOT NULL,
  `prizeRunnerFactorSecondN` float NOT NULL DEFAULT '0.75',
  `runnerFactorFirstNCount` tinyint NOT NULL DEFAULT '10',
  `runnerCount` tinyint NOT NULL DEFAULT '7'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leaderboard_tickets`
--

CREATE TABLE `leaderboard_tickets` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `game` enum('ROULETTE','CRASH','50X','TOWERS','DICE','MINES','SLOTS') NOT NULL,
  `amount` int NOT NULL,
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leaderboard_winners`
--

CREATE TABLE `leaderboard_winners` (
  `id` int NOT NULL,
  `leaderboardId` int NOT NULL,
  `place` tinyint NOT NULL,
  `winnerId` int NOT NULL,
  `amount` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `promocodes`
--

CREATE TABLE `promocodes` (
  `id` int NOT NULL,
  `code` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `prize` int NOT NULL,
  `uses` int NOT NULL DEFAULT '0',
  `maxUses` int NOT NULL DEFAULT '0',
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `promocode_uses`
--

CREATE TABLE `promocode_uses` (
  `id` int NOT NULL,
  `codeId` int NOT NULL,
  `userId` int NOT NULL,
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `steam_bot_items`
--

CREATE TABLE `steam_bot_items` (
  `id` int NOT NULL,
  `botId` int NOT NULL,
  `app` enum('RUST','CSGO','DOTA2') NOT NULL DEFAULT 'RUST',
  `assetid` varchar(32) NOT NULL,
  `amount` smallint NOT NULL DEFAULT '1',
  `market_hash_name` varchar(64) NOT NULL,
  `image` text NOT NULL,
  `price` int NOT NULL,
  `available` tinyint(1) DEFAULT NULL,
  `busy` tinyint(1) NOT NULL DEFAULT '0',
  `assignedOfferId` int DEFAULT NULL,
  `createdAt` int NOT NULL,
  `lastUpdate` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `steam_manual_prices`
--

CREATE TABLE `steam_manual_prices` (
  `id` int NOT NULL,
  `app` enum('RUST','CSGO','DOTA2') NOT NULL DEFAULT 'RUST',
  `market_hash_name` varchar(92) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `steam_shop_items`
--

CREATE TABLE `steam_shop_items` (
  `id` int NOT NULL,
  `botId` int NOT NULL,
  `app` enum('RUST','CSGO','DOTA2') NOT NULL DEFAULT 'RUST',
  `assetid` varchar(32) NOT NULL,
  `amount` smallint NOT NULL DEFAULT '1',
  `market_hash_name` varchar(64) NOT NULL,
  `image` text NOT NULL,
  `name_color` varchar(8) NOT NULL,
  `price` int NOT NULL,
  `available` tinyint(1) DEFAULT NULL,
  `busy` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `steam_trade_blacklisted`
--

CREATE TABLE `steam_trade_blacklisted` (
  `id` int NOT NULL,
  `app` enum('RUST','CSGO','DOTA2') NOT NULL DEFAULT 'RUST',
  `market_hash_name` varchar(92) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `steam_trade_bots`
--

CREATE TABLE `steam_trade_bots` (
  `id` int NOT NULL,
  `steamId` varchar(24) NOT NULL,
  `isOnline` tinyint(1) NOT NULL DEFAULT '0',
  `type` enum('VAULT','MULE','COINFLIP') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'MULE',
  `tradeUrl` varchar(192) DEFAULT NULL,
  `inventorySize_RUST` smallint NOT NULL DEFAULT '0',
  `inventorySize_CSGO` smallint NOT NULL DEFAULT '0',
  `inventorySize_DOTA2` smallint NOT NULL DEFAULT '0',
  `lastInventoryRefresh_RUST` int NOT NULL DEFAULT '0',
  `lastInventoryRefresh_CSGO` int NOT NULL DEFAULT '0',
  `lastInventoryRefresh_DOTA2` int NOT NULL DEFAULT '0',
  `lastTransfer` int NOT NULL DEFAULT '0',
  `lastPing` int NOT NULL DEFAULT '0',
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `steam_trade_offers`
--

CREATE TABLE `steam_trade_offers` (
  `id` int NOT NULL,
  `botId` int NOT NULL,
  `targetBotId` int NOT NULL DEFAULT '0',
  `muleState` enum('VAULT','MULE') NOT NULL DEFAULT 'MULE',
  `type` enum('DEPOSIT','WITHDRAW') NOT NULL,
  `target` enum('BALANCE','COINFLIP','UPGRADER') NOT NULL DEFAULT 'BALANCE',
  `targetId` int NOT NULL DEFAULT '0',
  `app` enum('RUST','CSGO','DOTA2') NOT NULL DEFAULT 'RUST',
  `steamOfferId` varchar(32) DEFAULT NULL,
  `trackingId` varchar(64) NOT NULL,
  `userId` int NOT NULL,
  `tradeUrl` varchar(128) NOT NULL,
  `requestState` enum('CREATING','IN_QUEUE','CREATED','FAILED') NOT NULL DEFAULT 'CREATING',
  `steamState` enum('INVALID','ACTIVE','ACCEPTED','COUNTERED','EXPIRED','CANCELED','DECLINED','INVALID_ITEMS','CREATED_NEEDS_CONFIRMATION','CANCELED_BY_SECOND_FACTOR','IN_ESCROW') DEFAULT NULL,
  `pricingType` enum('USD','COINS') NOT NULL DEFAULT 'COINS',
  `amount` int NOT NULL,
  `bonusRatio` float NOT NULL DEFAULT '0',
  `bonusAmount` int NOT NULL DEFAULT '0',
  `overall` int NOT NULL,
  `refunded` tinyint(1) NOT NULL DEFAULT '0',
  `itemBusinessHandled` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` int NOT NULL,
  `lastUpdate` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `steam_trade_offer_items`
--

CREATE TABLE `steam_trade_offer_items` (
  `id` int NOT NULL,
  `offerId` int NOT NULL,
  `app` enum('RUST','CSGO','DOTA2') NOT NULL DEFAULT 'RUST',
  `assetid` varchar(32) NOT NULL,
  `amount` smallint NOT NULL DEFAULT '1',
  `market_hash_name` varchar(64) NOT NULL,
  `image` text NOT NULL,
  `value` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `steam_trade_overstocks`
--

CREATE TABLE `steam_trade_overstocks` (
  `id` int NOT NULL,
  `app` enum('RUST','CSGO','DOTA2') NOT NULL,
  `market_hash_name` varchar(128) NOT NULL,
  `maxCount` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `steam_trade_vault_mule_transactions`
--

CREATE TABLE `steam_trade_vault_mule_transactions` (
  `id` int NOT NULL,
  `muleBotId` int NOT NULL,
  `userId` int NOT NULL,
  `state` enum('CREATED','ACTIVE','FAILED','COMPLETED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'CREATED',
  `finalOfferId` int DEFAULT NULL,
  `createdAt` int NOT NULL,
  `lastUpdate` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `steam_trade_vault_mule_transaction_links`
--

CREATE TABLE `steam_trade_vault_mule_transaction_links` (
  `id` int NOT NULL,
  `transactionId` int NOT NULL,
  `offerId` int NOT NULL,
  `state` enum('ACTIVE','COMPLETED','FAILED') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'ACTIVE',
  `createdAt` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `urlId` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `role` enum('USER','MODERATOR','ADMIN') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'USER',
  `accountType` enum('CREDENTIALS','OAUTH_STEAM') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `accountId` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `createdAt` int NOT NULL,
  `lastLogin` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `users -> user_data_common CREATE` AFTER INSERT ON `users` FOR EACH ROW INSERT INTO user_data_common SET user_data_common.userId=NEW.id
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `users -> user_data_cooldowns CREATE` AFTER INSERT ON `users` FOR EACH ROW INSERT INTO user_data_cooldowns SET user_data_cooldowns.userId=NEW.id
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `users -> user_data_games CREATE` AFTER INSERT ON `users` FOR EACH ROW INSERT INTO user_data_games SET user_data_games.userId=NEW.id
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `users -> user_data_settings CREATE` AFTER INSERT ON `users` FOR EACH ROW INSERT INTO user_data_settings SET user_data_settings.userId=NEW.id
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `users -> user_stats CREATE` AFTER INSERT ON `users` FOR EACH ROW INSERT INTO user_stats SET user_stats.userId=NEW.id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_data_common`
--

CREATE TABLE `user_data_common` (
  `userId` int NOT NULL,
  `displayName` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `avatar` varchar(192) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `balance` int NOT NULL DEFAULT '0',
  `withdrawWagerNeed` int NOT NULL DEFAULT '0',
  `exp` int NOT NULL DEFAULT '0',
  `muteEndsAt` int NOT NULL DEFAULT '0',
  `isBanned` tinyint(1) NOT NULL DEFAULT '0',
  `hasTradeLock` tinyint(1) NOT NULL DEFAULT '0',
  `whitelistRequest` tinyint(1) NOT NULL DEFAULT '0',
  `isWhitelisted` int NOT NULL DEFAULT '0',
  `affiliateId` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_data_cooldowns`
--

CREATE TABLE `user_data_cooldowns` (
  `userId` int NOT NULL,
  `lastFaucetClaim` int NOT NULL DEFAULT '0',
  `lastDailyCaseOpen` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_data_games`
--

CREATE TABLE `user_data_games` (
  `userId` int NOT NULL,
  `upgraderClientSeed` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `upgraderServerSeed` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_data_settings`
--

CREATE TABLE `user_data_settings` (
  `userId` int NOT NULL,
  `tradeUrl` varchar(192) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `volume` tinyint NOT NULL DEFAULT '100' COMMENT 'Between 0 - 100',
  `isAnon` tinyint(1) NOT NULL DEFAULT '0',
  `isPrivate` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_gamehistory`
--

CREATE TABLE `user_gamehistory` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `game` enum('ROULETTE','CRASH','BLACKJACK','COINFLIP','UPGRADER','MINES') NOT NULL,
  `roundId` int NOT NULL DEFAULT '0',
  `betPricing` enum('COINS','USD') NOT NULL,
  `betAmount` int NOT NULL,
  `betAmountWithRisk` int NOT NULL,
  `betTo` varchar(48) NOT NULL DEFAULT '',
  `won` int NOT NULL,
  `betWinner` varchar(49) NOT NULL,
  `multiplier` float NOT NULL DEFAULT '0',
  `winnings` int NOT NULL DEFAULT '0',
  `riskPayoutRate` float NOT NULL DEFAULT '0',
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `logType` enum('NEW_ACCOUNT','LOGIN','SET_TRADE_URL') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `userAgent` tinytext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `additional` varchar(192) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `ipAddress` varchar(192) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `userId` int NOT NULL,
  `authToken` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `userAgent` tinytext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ipAddress` varchar(192) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `expiresAt` int NOT NULL DEFAULT '0',
  `lastUpdate` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_stats`
--

CREATE TABLE `user_stats` (
  `userId` int NOT NULL,
  `totalDeposited` int NOT NULL DEFAULT '0',
  `totalWithdrawn` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_trades`
--

CREATE TABLE `user_trades` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `way` enum('DEPOSIT','WITHDRAW') NOT NULL,
  `type` enum('STEAM_SKINS','COINPAYMENTS','GIFTCARD','SKINSBACK','PAYDASH','UPGRADER') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `amount` int NOT NULL,
  `time` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `user_transactions`
--

CREATE TABLE `user_transactions` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `way` enum('IN','OUT') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `amount` int NOT NULL,
  `type` varchar(92) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `newBalance` int NOT NULL,
  `time` int NOT NULL,
  `timestamp` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_wagers`
--

CREATE TABLE `user_wagers` (
  `id` int NOT NULL,
  `userId` int NOT NULL,
  `game` enum('ROULETTE','CRASH','BLACKJACK','UPGRADER','MINES') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `amount` int NOT NULL,
  `time` int NOT NULL,
  `timestamp` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `affiliates`
--
ALTER TABLE `affiliates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ownerId` (`ownerId`),
  ADD UNIQUE KEY `code` (`code`),
  ADD UNIQUE KEY `ownerId_2` (`ownerId`,`code`);

--
-- Indexes for table `affiliate_earnings`
--
ALTER TABLE `affiliate_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `codeId` (`codeId`,`time`),
  ADD KEY `codeId_2` (`codeId`,`feeAmount`,`time`);

--
-- Indexes for table `affiliate_level_table`
--
ALTER TABLE `affiliate_level_table`
  ADD PRIMARY KEY (`level`);

--
-- Indexes for table `auth_external_links`
--
ALTER TABLE `auth_external_links`
  ADD UNIQUE KEY `accountType` (`accountType`,`accountId`),
  ADD UNIQUE KEY `userId` (`userId`);

--
-- Indexes for table `coinpayments_transactions`
--
ALTER TABLE `coinpayments_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coinpaymentsId` (`coinpaymentsId`),
  ADD KEY `userId` (`userId`,`createdAt`),
  ADD KEY `currency` (`currency`,`userId`,`type`,`createdAt`);

--
-- Indexes for table `coinpayments_wallets`
--
ALTER TABLE `coinpayments_wallets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `currency` (`currency`,`assignedTo`),
  ADD UNIQUE KEY `currency_2` (`currency`,`address`);

--
-- Indexes for table `dailycases_history`
--
ALTER TABLE `dailycases_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`createdAt`),
  ADD KEY `id` (`id`,`userId`);

--
-- Indexes for table `dailycases_opens`
--
ALTER TABLE `dailycases_opens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userId` (`userId`,`day`);

--
-- Indexes for table `discord_user_links`
--
ALTER TABLE `discord_user_links`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `discord_user_redirects`
--
ALTER TABLE `discord_user_redirects`
  ADD UNIQUE KEY `state` (`state`);

--
-- Indexes for table `events_rain_pots`
--
ALTER TABLE `events_rain_pots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `state` (`state`);

--
-- Indexes for table `events_rain_pot_players`
--
ALTER TABLE `events_rain_pot_players`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `potId` (`potId`,`userId`),
  ADD KEY `id` (`id`,`potId`);

--
-- Indexes for table `game_blackjack_rounds`
--
ALTER TABLE `game_blackjack_rounds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`tableId`,`state`);

--
-- Indexes for table `game_blackjack_round_bets`
--
ALTER TABLE `game_blackjack_round_bets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roundId` (`roundId`),
  ADD KEY `roundId_2` (`roundId`,`userId`);

--
-- Indexes for table `game_coinflip_rooms`
--
ALTER TABLE `game_coinflip_rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`opponentId`,`phase`),
  ADD KEY `id_2` (`id`,`phase`);

--
-- Indexes for table `game_coinflip_room_items`
--
ALTER TABLE `game_coinflip_room_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`roomId`,`type`),
  ADD KEY `id_2` (`id`,`roomId`);

--
-- Indexes for table `game_crash_rounds`
--
ALTER TABLE `game_crash_rounds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_crash_round_bets`
--
ALTER TABLE `game_crash_round_bets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_roulette_rounds`
--
ALTER TABLE `game_roulette_rounds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`state`,`closedAt`);

--
-- Indexes for table `game_roulette_round_bets`
--
ALTER TABLE `game_roulette_round_bets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`color`),
  ADD KEY `roundId` (`roundId`,`userId`,`color`);

--
-- Indexes for table `game_upgrader_rounds`
--
ALTER TABLE `game_upgrader_rounds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_upgrader_round_items`
--
ALTER TABLE `game_upgrader_round_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_upgrader_user_inventory`
--
ALTER TABLE `game_upgrader_user_inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`userId`),
  ADD KEY `userId` (`userId`,`createdAt`),
  ADD KEY `userId_2` (`userId`,`state`),
  ADD KEY `state` (`state`,`linkedTransactionId`);

--
-- Indexes for table `giftcards`
--
ALTER TABLE `giftcards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `usedBy` (`usedBy`,`usedAt`),
  ADD KEY `code_2` (`code`,`usedBy`);

--
-- Indexes for table `global_settings`
--
ALTER TABLE `global_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leaderboards`
--
ALTER TABLE `leaderboards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`,`state`),
  ADD KEY `id` (`id`,`type`,`state`);

--
-- Indexes for table `leaderboard_prizes`
--
ALTER TABLE `leaderboard_prizes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`leaderboardId`),
  ADD KEY `leaderboardId` (`leaderboardId`);

--
-- Indexes for table `leaderboard_settings`
--
ALTER TABLE `leaderboard_settings`
  ADD PRIMARY KEY (`type`);

--
-- Indexes for table `leaderboard_tickets`
--
ALTER TABLE `leaderboard_tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`createdAt`),
  ADD KEY `amount` (`amount`,`createdAt`),
  ADD KEY `createdAt` (`createdAt`);

--
-- Indexes for table `leaderboard_winners`
--
ALTER TABLE `leaderboard_winners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `promocodes`
--
ALTER TABLE `promocodes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `code_2` (`code`,`uses`,`maxUses`);

--
-- Indexes for table `promocode_uses`
--
ALTER TABLE `promocode_uses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codeId` (`codeId`,`userId`);

--
-- Indexes for table `steam_bot_items`
--
ALTER TABLE `steam_bot_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `botId` (`botId`,`assetid`),
  ADD UNIQUE KEY `botId_2` (`botId`,`app`,`assetid`),
  ADD KEY `app` (`app`),
  ADD KEY `available` (`available`,`busy`),
  ADD KEY `botId_3` (`botId`,`lastUpdate`),
  ADD KEY `botId_4` (`botId`,`available`,`assignedOfferId`);

--
-- Indexes for table `steam_manual_prices`
--
ALTER TABLE `steam_manual_prices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `app` (`app`,`market_hash_name`);

--
-- Indexes for table `steam_shop_items`
--
ALTER TABLE `steam_shop_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `botId` (`botId`,`assetid`),
  ADD UNIQUE KEY `botId_2` (`botId`,`app`,`assetid`),
  ADD KEY `app` (`app`),
  ADD KEY `available` (`available`,`busy`);

--
-- Indexes for table `steam_trade_blacklisted`
--
ALTER TABLE `steam_trade_blacklisted`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `app` (`app`,`market_hash_name`);

--
-- Indexes for table `steam_trade_bots`
--
ALTER TABLE `steam_trade_bots`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `steamId` (`steamId`),
  ADD KEY `isOnline` (`isOnline`,`lastPing`),
  ADD KEY `isOnline_2` (`isOnline`,`type`,`lastPing`);

--
-- Indexes for table `steam_trade_offers`
--
ALTER TABLE `steam_trade_offers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `trackingId` (`trackingId`),
  ADD KEY `requestState` (`requestState`,`createdAt`),
  ADD KEY `userId` (`userId`,`createdAt`),
  ADD KEY `type` (`type`,`userId`,`createdAt`),
  ADD KEY `userId_2` (`userId`,`requestState`),
  ADD KEY `userId_3` (`userId`,`requestState`,`steamState`),
  ADD KEY `botId` (`botId`,`requestState`,`createdAt`),
  ADD KEY `type_2` (`type`,`steamState`,`itemBusinessHandled`,`lastUpdate`),
  ADD KEY `targetId` (`targetId`,`userId`,`steamState`),
  ADD KEY `type_4` (`type`,`target`,`requestState`,`steamState`,`refunded`,`lastUpdate`);

--
-- Indexes for table `steam_trade_offer_items`
--
ALTER TABLE `steam_trade_offer_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`offerId`),
  ADD KEY `id_2` (`id`,`offerId`,`market_hash_name`);

--
-- Indexes for table `steam_trade_overstocks`
--
ALTER TABLE `steam_trade_overstocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `steam_trade_vault_mule_transactions`
--
ALTER TABLE `steam_trade_vault_mule_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `finalOfferId` (`finalOfferId`),
  ADD KEY `id` (`id`,`state`);

--
-- Indexes for table `steam_trade_vault_mule_transaction_links`
--
ALTER TABLE `steam_trade_vault_mule_transaction_links`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `offerId` (`offerId`),
  ADD KEY `id` (`id`,`transactionId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `createdAt` (`createdAt`),
  ADD KEY `accountId` (`accountId`);

--
-- Indexes for table `user_data_common`
--
ALTER TABLE `user_data_common`
  ADD PRIMARY KEY (`userId`),
  ADD KEY `userId` (`userId`,`balance`),
  ADD KEY `userId_2` (`userId`,`affiliateId`),
  ADD KEY `displayName` (`displayName`);

--
-- Indexes for table `user_data_cooldowns`
--
ALTER TABLE `user_data_cooldowns`
  ADD PRIMARY KEY (`userId`),
  ADD KEY `userId` (`userId`,`lastFaucetClaim`);

--
-- Indexes for table `user_data_games`
--
ALTER TABLE `user_data_games`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `user_data_settings`
--
ALTER TABLE `user_data_settings`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `user_gamehistory`
--
ALTER TABLE `user_gamehistory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`time`),
  ADD KEY `userId_2` (`userId`,`game`,`time`),
  ADD KEY `userId_3` (`userId`,`won`,`time`),
  ADD KEY `userId_4` (`userId`),
  ADD KEY `userId_5` (`userId`,`betAmount`,`time`),
  ADD KEY `userId_6` (`userId`,`winnings`,`time`),
  ADD KEY `userId_7` (`userId`,`betAmount`,`winnings`,`time`),
  ADD KEY `userId_8` (`userId`,`betAmountWithRisk`,`time`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_logs_userId` (`userId`) USING BTREE;

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD UNIQUE KEY `authToken` (`authToken`),
  ADD KEY `userId` (`userId`,`lastUpdate`);

--
-- Indexes for table `user_stats`
--
ALTER TABLE `user_stats`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `user_trades`
--
ALTER TABLE `user_trades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`time`),
  ADD KEY `type` (`type`,`time`),
  ADD KEY `way` (`way`,`type`,`time`),
  ADD KEY `userId_2` (`userId`,`way`,`time`);

--
-- Indexes for table `user_transactions`
--
ALTER TABLE `user_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`way`,`time`),
  ADD KEY `way` (`way`,`time`),
  ADD KEY `time` (`time`),
  ADD KEY `userId_2` (`userId`);

--
-- Indexes for table `user_wagers`
--
ALTER TABLE `user_wagers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`time`),
  ADD KEY `amount` (`amount`,`time`),
  ADD KEY `time` (`time`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `affiliates`
--
ALTER TABLE `affiliates`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `affiliate_earnings`
--
ALTER TABLE `affiliate_earnings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `affiliate_level_table`
--
ALTER TABLE `affiliate_level_table`
  MODIFY `level` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coinpayments_transactions`
--
ALTER TABLE `coinpayments_transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coinpayments_wallets`
--
ALTER TABLE `coinpayments_wallets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dailycases_history`
--
ALTER TABLE `dailycases_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dailycases_opens`
--
ALTER TABLE `dailycases_opens`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events_rain_pots`
--
ALTER TABLE `events_rain_pots`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events_rain_pot_players`
--
ALTER TABLE `events_rain_pot_players`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_blackjack_rounds`
--
ALTER TABLE `game_blackjack_rounds`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_blackjack_round_bets`
--
ALTER TABLE `game_blackjack_round_bets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_coinflip_rooms`
--
ALTER TABLE `game_coinflip_rooms`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_coinflip_room_items`
--
ALTER TABLE `game_coinflip_room_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_crash_rounds`
--
ALTER TABLE `game_crash_rounds`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_crash_round_bets`
--
ALTER TABLE `game_crash_round_bets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_roulette_rounds`
--
ALTER TABLE `game_roulette_rounds`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_roulette_round_bets`
--
ALTER TABLE `game_roulette_round_bets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_upgrader_rounds`
--
ALTER TABLE `game_upgrader_rounds`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_upgrader_round_items`
--
ALTER TABLE `game_upgrader_round_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_upgrader_user_inventory`
--
ALTER TABLE `game_upgrader_user_inventory`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `giftcards`
--
ALTER TABLE `giftcards`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leaderboards`
--
ALTER TABLE `leaderboards`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leaderboard_prizes`
--
ALTER TABLE `leaderboard_prizes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leaderboard_tickets`
--
ALTER TABLE `leaderboard_tickets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leaderboard_winners`
--
ALTER TABLE `leaderboard_winners`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `promocodes`
--
ALTER TABLE `promocodes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `promocode_uses`
--
ALTER TABLE `promocode_uses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_bot_items`
--
ALTER TABLE `steam_bot_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_manual_prices`
--
ALTER TABLE `steam_manual_prices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_shop_items`
--
ALTER TABLE `steam_shop_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_trade_blacklisted`
--
ALTER TABLE `steam_trade_blacklisted`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_trade_bots`
--
ALTER TABLE `steam_trade_bots`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_trade_offers`
--
ALTER TABLE `steam_trade_offers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_trade_offer_items`
--
ALTER TABLE `steam_trade_offer_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_trade_overstocks`
--
ALTER TABLE `steam_trade_overstocks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_trade_vault_mule_transactions`
--
ALTER TABLE `steam_trade_vault_mule_transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `steam_trade_vault_mule_transaction_links`
--
ALTER TABLE `steam_trade_vault_mule_transaction_links`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_gamehistory`
--
ALTER TABLE `user_gamehistory`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_stats`
--
ALTER TABLE `user_stats`
  MODIFY `userId` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_trades`
--
ALTER TABLE `user_trades`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_transactions`
--
ALTER TABLE `user_transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_wagers`
--
ALTER TABLE `user_wagers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `game_roulette_round_bets`
--
ALTER TABLE `game_roulette_round_bets`
  ADD CONSTRAINT `fk_games_roulette_round_bets_roundId` FOREIGN KEY (`roundId`) REFERENCES `game_roulette_rounds` (`id`),
  ADD CONSTRAINT `fk_games_roulette_round_bets_userId` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_data_common`
--
ALTER TABLE `user_data_common`
  ADD CONSTRAINT `fk_user_data_common_userId` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_data_cooldowns`
--
ALTER TABLE `user_data_cooldowns`
  ADD CONSTRAINT `fk_user_data_cooldowns_userId` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_data_settings`
--
ALTER TABLE `user_data_settings`
  ADD CONSTRAINT `fk_user_data_settings_userId` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD CONSTRAINT `fk_user_logs_ticketId` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `fk_user_sessions_userId` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_stats`
--
ALTER TABLE `user_stats`
  ADD CONSTRAINT `fk_user_stats_userId` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
