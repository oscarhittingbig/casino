
require("dotenv").config();
require('console-stamp')(console, '[ddd mmm dd yyyy HH:MM:ss]');
const path = require('path');
const fs = require('fs');

process.setMaxListeners(0);

global.devMode = process.env.debug == 'true';
global.appRoot = path.dirname(require.main.filename) + `/../../`;
global.srcRoot = global.appRoot + 'src/';
global.getSrcPath = function(path) { return global.srcRoot + path; };
global.getDataPath = function(path) { return global.appRoot + 'data/' + path; };
global.getTemplatePath = function(path) { return global.appRoot + 'data/templates/' + path; };
global.getFilesInDirectory = function(directory) { 
   let fileObjs = [];
   const fileNames = fs.readdirSync(directory);
   fileNames.forEach(fileName => {
    const filePath = directory + '/' + fileName;
    fileName = fileName.replace('.js', '');
    fileObjs.push({ name: fileName, path: filePath });
    });
    return fileObjs;
};
global.loadFromPath = function({args, path, obj, recursive, isModule}) {
    const files = global.getFilesInDirectory(path).sort((a, b) => { 
        const isADirectory = !(a.path.endsWith('.js'));
        const isBDirectory = !(b.path.endsWith('.js'));
        return (isADirectory === isBDirectory)? 0 : isADirectory? 1 : -1 
    });
   
    for (let i in files) {
        const file = files[i];
        const isDirectory = file.path.endsWith('.js') == false;      
        const excluded = file.path.endsWith("classes");
        if (isDirectory && excluded) continue;  
        if (isDirectory && recursive) { global.loadFromPath({args, path: file.path, obj: obj[file.name], recursive, isModule}); continue;}
        else if (isDirectory && recursive == false) continue;
        obj[file.name] = isModule ? require(file.path) : new (require(file.path))(args)
    }
}
global.capitalizeFirstLetter = function(str) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLocaleLowerCase('tr-TR');
};
global.capitalizeFirstLetters = function(str) {
    str = str.split(' ').map(global.capitalizeFirstLetter).join(' ');
    return str;
};
global.getBetween = function (str, first, last) {
    let firstIndex = str.indexOf(first) + first.length;
    let lastIndex = str.indexOf(last, firstIndex);
    let part = str.substring(firstIndex, lastIndex)
    return part;
};
global.replaceAll = function(str, find, replace) {
    return str.toString().replace(new RegExp(find, 'ig'), replace);
  };
global.clearHTML = function(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
global.randomString = function(length) {
    return Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
}

global.WORKER = parseInt(process.env.NODE_APP_INSTANCE) + 1;
global.MAIN = (process.env.NODE_APP_INSTANCE == 0) ? true : false;

if (global.MAIN) { console.log(`Master - Node Instance ${process.env.NODE_APP_INSTANCE} ~ PID ${process.pid}`); } else { console.log(`Cluster - Node Instance ${process.env.NODE_APP_INSTANCE} ~ PID ${process.pid}`); }


/*
if (global.devMode) global.appDir = path.dirname(require.main.filename) + `/../../`;
else global.appDir = path.dirname(require.main.filename) + `/../../`;
*/
