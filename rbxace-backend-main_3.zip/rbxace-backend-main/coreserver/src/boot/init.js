require('./global');
const loader = require('./loader');



async function main() {
    const args = loader.generateArgs();
    await args.repositories.roulette.game.init();
    await args.repositories.crash.game.init();
    await args.repositories.blackjack.game.initTables();

    await args.repositories.coinflip.game.init();
    
    await args.repositories.rain.core.init();

    await args.repositories.leaderboard.worker.mainThread();

    loader.startWorkers(args);

    await args.workers.globalUpdater.sync();
    args.repositories.redis.listen();
}

main();