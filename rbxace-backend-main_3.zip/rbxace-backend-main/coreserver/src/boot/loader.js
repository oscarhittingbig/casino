module.exports = {
    getModules(args) {
        global.loadFromPath({args, path: global.getSrcPath('core/modules/'), obj: args.modules, recursive: false, isModule: true});
    },

    getRepositories(args) {
        global.loadFromPath({args, path: global.getSrcPath('core/repositories/'), obj: args.repositories, recursive: true, isModule: false});
    },

    getServices(args) {
        global.loadFromPath({args, path: global.getSrcPath('core/services/'), obj: args.services, recursive: true, isModule: false});
    },

    startWorkers(args) {
        let emptyObj = {};
        global.loadFromPath({args, path: global.getSrcPath('core/workers/'), obj: args.workers, recursive: false, isModule: false});
    },

    generateArgs() {
        const args = { modules: {}, repositories: {}, services: {}, workers: {} };
        args.inject = function (obj) { Object.keys(args).forEach(argKey => { obj[argKey] = args[argKey] }) };
        this.getModules(args);
        this.getRepositories(args);
        this.getServices(args);
        return args;
    },


};