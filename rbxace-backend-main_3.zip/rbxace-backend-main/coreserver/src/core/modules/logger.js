const fs = require('fs');

function log(name, message) {
    try {
        if (typeof message == 'object') message = JSON.stringify(message);
        
        let fileName = `logs/${name}.log`;

        let time = new Date().toLocaleString();
        let data = `[${time}] ${message}\n`;

        fs.appendFileSync(fileName, data);
    } catch (err) {
        console.log('something went wrong on logging');
        console.log(err);
    }
}


module.exports = {
    log: log
};