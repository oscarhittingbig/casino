const moment = require('moment');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  getLevelData(amount) {
    const levelsData = global.affiliates_levelTable;
    for (let i in levelsData) {
      const levelData = levelsData[i];
      if (amount >= levelData.max && levelData.max !== 0) continue;
      let currentProgress = 0;
      let diff = levelData.max - levelData.min;
      let expDiff = amount - levelData.min;
      currentProgress = parseFloat(((expDiff / diff) * 100).toFixed(2));
      if (levelData.max == 0) currentProgress = 0;
      return {
        levels: levelsData,
        exp: amount,
        currentProgress,
        currentLevel: levelData.level,
        currentCut: levelData.cut
      };
    }
  }


  async handleAffiliateWagerEarning(userId, amount) {
    try {
      const affiliateId = (await this.modules.db.query("SELECT affiliateId FROM user_data_common WHERE userId = ?", [userId]))[0].affiliateId;
      if (!affiliateId) return;

      const affiliateData = (await this.modules.db.query("SELECT id, totalWagered FROM affiliates WHERE ownerId = ?", [affiliateId]))[0];

      const affiliateCut = this.repositories.affiliates.getLevelData(affiliateData.totalWagered).currentCut;

      const feeAmount = Math.floor(amount * affiliateCut / 100);
      if (feeAmount <= 0) return;

      const updateAffiliateSuccess = await this.modules.db.exec("UPDATE affiliates SET totalWagered = totalWagered + ?, balance = balance + ? WHERE ownerId = ?", [amount, feeAmount, affiliateId]);
      const insertAffiliateEarningSuccess = await this.modules.db.insert("INSERT INTO affiliate_earnings SET ?", [
        {
          codeId: affiliateData.id,
          refId: userId,
          type: 'WAGER',
          amount,
          feeAmount,
          time: moment().utc().unix()
        }
      ]);
    } catch (err) {

    }
  }

}