const moment = require('moment');

const sleep = require('await-sleep');
module.exports = class {

  constructor(params) {
    params.inject(this);

  }


  async createNewRound(tableId) {
    let roundVariables = await this.repositories.blackjack.fairness.generateRoundVariables();
    const { deckCount, serverSecret, randomOrgSecret, verificationLink, seed, hash, shoeString} = roundVariables;
    roundVariables.id = await this.modules.db.insert("INSERT INTO game_blackjack_rounds SET ?", [{
         tableId,
        serverSecret,
          randomOrgSecret,
          verificationLink,
          deckCount,
          seed,
          hash,
          shoeString,
          createdAt: moment().utc().unix()
      }]);
      return roundVariables;
  }

  async getRound(tableId) {
    const roundSql = await this.modules.db.query("SELECT * FROM game_blackjack_rounds WHERE tableId = ? AND state = 'OPEN' ORDER BY id DESC LIMIT 1", [tableId]);
    if (roundSql.length) {
      const variables = roundSql[0];
      let shoe = [];
      const shoeCardsString = variables.shoeString.split(', ');
      for (let i in shoeCardsString) {
        const str = shoeCardsString[i];
        const cardData = str.split('');
        let pip = cardData[0];
        let index = cardData[1];
        if (cardData.length > 2) index += cardData[2];
        shoe.push({ pip, index });
      }
      variables.shoe = shoe;
      return variables;
    };
    return await this.createNewRound(tableId);
  }

  async closeRound(id) {
    const updateSuccess = await this.modules.db.exec("UPDATE game_blackjack_rounds SET state = 'CLOSED', endedAt = ? WHERE id = ?", [moment().utc().unix(), id]);
    //if (!updateSuccess) throw new Error("Round state couldn't be updated!");
  }


}