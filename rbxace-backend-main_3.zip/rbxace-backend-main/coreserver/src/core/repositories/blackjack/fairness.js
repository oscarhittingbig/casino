const crypto = require("crypto");
const shuffleSeed = require('shuffle-seed')

module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      DECK_COUNT: 6
    };
  }

  generateDecks() {
    const pips = ['♤', '♡', '♧', '♢'];
    const indexes = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    let cards = [];
    for (let i = 0;i < this.defs.DECK_COUNT;i++) {
      pips.forEach(pip => {
        indexes.forEach(index => {
          cards.push({ pip, index });
        })
      })
    }
    return cards;
  }

  cardsToString(cards) {
    return cards.reduce((arr, obj) => { let str = `${obj.pip}${obj.index}`; arr.push(str); return arr;}, []).join(', ');
  }

  async generateRoundVariables() {
    const serverSecret = this.repositories.random.generateRandomString(32);
    let randomOrgSecret = '', verificationLink = '';
    
    const randomOrgVariables = await this.repositories.random.generateServiceString();
    if (randomOrgVariables) {
        randomOrgSecret = randomOrgVariables.string;
        verificationLink = randomOrgVariables.verificationLink;
    }

    const seed = `${serverSecret}:${randomOrgSecret}`;
    const hash = crypto.createHash("sha512").update(seed).digest("hex");

    const decks = this.generateDecks();
    let shoe = shuffleSeed.shuffle(decks, seed);
   
    
    /*
    shoe[0] =  { index: 'J', pip: '♤' };
    shoe[1] =  { index: 'A', pip: '♤' };
    shoe[2] =  { index: 'J', pip: '♢' };
    */
    /*
    const shoe = [
      { index: '7', pip: '♡' },
      { index: '7', pip: '♤' },
      { index: '7', pip: '♤' },
      { index: '7', pip: '♤' },
      { index: '7', pip: '♡' },
      { index: '7', pip: '♤' },
      { index: '7', pip: '♡' },
      { index: '7', pip: '♤' },
      { index: '7', pip: '♡' },
      { index: '7', pip: '♤' },
      { index: '7', pip: '♡' },
      { index: '7', pip: '♤' },
      { index: '7', pip: '♡' },
      { index: '7', pip: '♤' },
      { index: '7', pip: '♡' },
      { index: '7', pip: '♤' },
      { pip: '♧', index: 'A' },
      { pip: '♢', index: 'A' },
      { pip: '♤', index: 'A' },
      { pip: '♡', index: '10' },
      { pip: '♧', index: '10' },
      { pip: '♢', index: '10' },
      { pip: '♤', index: '10' },
      { pip: '♡', index: '10' },
      { pip: '♧', index: '10' },
      { pip: '♢', index: '10' },
      { pip: '♤', index: '10' },
      { pip: '♡', index: '10' },
      { pip: '♧', index: '10' },
      { pip: '♢', index: 'A' },
      { pip: '♤', index: 'A' },
      { pip: '♡', index: 'A' },
      { pip: '♧', index: 'A' },
      { pip: '♢', index: 'A' },
      { pip: '♤', index: 'A' },
      { pip: '♡', index: 'A' },
      { pip: '♧', index: 'A' },
      { pip: '♢', index: 'A' },
    ];
    */
    
    
    const shoeString = this.cardsToString(shoe);

    const roundVaribles = {
      deckCount: this.defs.DECK_COUNT,
      serverSecret,
      randomOrgSecret,
      verificationLink,
      seed,
      hash,
      shoe,
      shoeString
    };

    return roundVaribles;
  }


}