const TableDealer = require('./table/dealer');
const TablePlayer = require('./table/player');
const TableThread = require('./table/thread');

const sleep = require('await-sleep');

module.exports = class {

  constructor({ params, game, defs, id, index, type }) {
    params.inject(this);
    this.params = params;
    this.defs = defs;

    this.id = id;
    this.type = type;
    this.index = index;
    this.data = { id: this.id, type: this.type };
    this.ioChannelName = `game:blackjack:table:${this.id}`;
    this.roundData = {

    };
    this.lastBets = {};
    this.isAvailable = true;
    /*
    setTimeout(() => {
      this.calculateHandScore([
        { index: 'A' },
        { index: 'Q' },
        { index: 'K' },
      ]);
    }, 1000)
    */

  }

  setAvailability(isAvailable) {
    this.isAvailable = isAvailable;
  }

  get publicRoundData() {
    try {
      const playersData = {};

      Object.keys(this.roundData.players).forEach((playerOffset) => {
        playersData[playerOffset] = this.roundData.players[playerOffset].data;
      });
      const dealerData = JSON.parse(JSON.stringify(this.roundData.dealer.data));
      dealerData.hand.cards.forEach(card => {
        if (card.invisible) {
          card.pip = '♢';
          card.index = 'A';
        }
      });
      const roundData = {
        id: this.id, //lobby id
        roundId: this.roundData.id,
        index: this.index,
        type: this.type,
        defs: {
          minBet: this.defs.minBet,
          maxBet: this.defs.maxBet
        },
        dealer: dealerData,
        players: playersData,
        phase: this.roundData.phase,
        playingPlayerOffset: this.roundData.playingPlayerOffset,
        lastPhaseStartedAt: this.roundData.lastPhaseStartedAt
      };
      return roundData;
    } catch (err) {
      return {}
    }
  }

  get wrapper() {
    return this.repositories.blackjack;
  }

  get allPlayersDecided() {
    let allPlayersDecided = true;
    Object.keys(this.roundData.players).forEach(offset => {
      const player = this.roundData.players[offset];
      if (player.hasMainBet && !player.data.lastDecision) allPlayersDecided = false;
    });
    return allPlayersDecided;
  }

  get allPlayersAvailable() {
    let allPlayersAvailable = true;
    Object.keys(this.roundData.players).forEach(offset => {
      const player = this.roundData.players[offset];
      if (!player.isAvailable) allPlayersAvailable = false;
    });
    return allPlayersAvailable;
  }

  get anyBet() {
    let hasBet = false;
    const playerOffsets = Object.keys(this.roundData.players);
    for (let i in playerOffsets) {
      let offset = playerOffsets[i];
      if (this.roundData.players[offset].hasBet) hasBet = true;
    }
    return hasBet;
  }

  get isInsuranceRound() {
    return this.roundData.dealer.firstCard.index == 'A';
  }

  async init() {
    const roundVariables = await this.wrapper.db.getRound(this.id);
    const dealer = new TableDealer({ params: this.params, table: this });
    const players = {};
    for (let i = 1; i <= 5; i++) {
      players[i] = new TablePlayer({ params: this.params, table: this, offset: i });
    }
    this.roundData = {
      ...roundVariables,
      dealer,
      players,
      phase: 'WAITING_FOR_PLAYERS',
      playingPlayerOffset: 5, //right to left, 1, 2, 3, 4, 5
      lastPhaseStartedAt: 0
    }
    this.thread = new TableThread({ params: this.params, table: this })
  }

  pickCard() {
    const card = this.roundData.shoe[0];
    //const card = { pip: '♤', index: 'A' }
    this.roundData.shoe.shift();
    return card;
  }


  addBetsToHands() {
    Object.keys(this.roundData.players).forEach(offset => {
      let player = this.roundData.players[offset];
      player.data.hands['MAIN'].betAmount = player.data.bets['MAIN'].amount;
    });
  }

  clearLastBets() {
    this.lastBets = {};
  }
  saveLastBets() {
    const lastBets = {};
    Object.keys(this.roundData.players).forEach(offset => {
      let player = this.roundData.players[offset];
      if (player.data.user) lastBets[player.data.user.id] = player.data.bets;
    });
    this.lastBets = JSON.parse(JSON.stringify(lastBets));
  }

  async deal() {
    await sleep(1000);
    for (let currentLoop = 1; currentLoop <= 2; currentLoop++) {

      for (let playerOffset = 5; playerOffset >= 0; playerOffset--) {
        if (playerOffset > 0) {
          const player = this.roundData.players[playerOffset];
          if (player.hasBet) {
            player.drawCard('MAIN');
            await sleep(900);
          }
        } else {
          const invisible = currentLoop > 1;
          this.roundData.dealer.drawCard(invisible);
          await sleep(900);
        }
      }
    }
    await sleep(1500);

    await this.awardSideBets();

    if (this.isInsuranceRound) this.setPhase('INSURANCE');
    else this.setPhase('PLAYING')
  }

  resetUserDecisions() {
    Object.keys(this.roundData.players).forEach(offset => {
      let player = this.roundData.players[offset];
      player.data.lastDecision = null;
    });

    const packetName = `blackjack:round:resetUserDecisions`;
    const packetData = {};
    this.publishPacket(packetName, packetData);
  }

  resetPhaseTimer() {
    this.roundData.lastPhaseStartedAt = Date.now();

    const packetName = `blackjack:round:resetPhaseTimer`;
    const packetData = {
      newLastPhaseStartedAt: this.roundData.lastPhaseStartedAt
    };
    this.publishPacket(packetName, packetData);
  }

  async processBets() {
    const playerOffsets = Object.keys(this.roundData.players);
    for (let i in playerOffsets) {
      const offset = playerOffsets[i];
      let player = this.roundData.players[offset];

      //if no bet
      if (player.data.user && !player.hasBet) player.setUser(null);

      try {
        await this.repositories.user.updateBalance({ way: 'OUT', userId: player.data.user.id, amount: player.totalBetAmount, transactionType: 'BET_BLACKJACK', alterType: 'BET', alterName: 'BLACKJACK' });
      } catch (err) {
        player.setUser(null);
      }
    }
  }

  setPhase(newPhase) {
    this.roundData.phase = newPhase;
    this.resetPhaseTimer();
    const packetName = `blackjack:round:setPhase`;
    const packetData = { newPhase, newLastPhaseStartedAt: this.roundData.lastPhaseStartedAt };
    this.publishPacket(packetName, packetData);
    this.resetUserDecisions();
  }

  goToNextPlayer() {
    this.roundData.playingPlayerOffset--;
    if (this.roundData.playingPlayerOffset == 0) this.setPhase('DEALER');
    else {
      const packetName = `blackjack:round:setPlayingPlayerOffset`;
      const packetData = {
        newOffset: this.roundData.playingPlayerOffset
      };
      this.publishPacket(packetName, packetData);
    }
  }

  async processInsurances() {
    if (!this.isInsuranceRound) return;

    const hasDealerBlackjack = this.roundData.dealer.data.hand.score == 21;
    const playerOffsets = Object.keys(this.roundData.players);
    for (let i in playerOffsets) {
      const offset = playerOffsets[i];
      let player = this.roundData.players[offset];
      if (player.data.insuranceCost > 0) {
        const payout = { betType: 'INSURANCE', betAmount: player.data.insuranceCost, winnings: 0 };
        if (hasDealerBlackjack) {
          payout.winnings = Math.floor(player.data.insuranceCost * 2) + player.data.bets['MAIN'].amount;
          await this.repositories.user.updateBalance({ way: 'IN', userId: player.data.user.id, amount: payout.winnings, transactionType: 'BET_BLACKJACK_INSURANCE_WINNINGS' });
        }
        player.data.payouts.push(payout);
      }
      player.data.insuranceCost = 0;
    }

    const packetName = `blackjack:round:removeInsurances`;
    const packetData = {};
    this.publishPacket(packetName, packetData);

  }





  async awardSideBets() {
    const payouts = { '21+3': {}, 'PERFECT_PAIRS': {} };
    for (let playerOffset = 1; playerOffset <= 5; playerOffset++) {
      try {
        let player = this.roundData.players[playerOffset];
        const playerHand = player.data.hands['MAIN'];
        const betTypes = Object.keys(payouts);
        for (let i in betTypes) {
          const betType = betTypes[i];
          const betAmount = player.data.bets[betType].amount;
          if (betAmount == 0) continue;
          player.data.bets[betType].amount = 0;

          const cards = betType == '21+3' ? [...playerHand.cards, this.roundData.dealer.firstCard] : playerHand.cards;

          let payout = this.repositories.blackjack.odds[betType == '21+3' ? 'calculatePlusThreePayout' : 'calculatePerfectPairsPayout'](cards);
          payout.betType = betType;
          payout.winnings = Math.floor(betAmount * payout.rate);
          payout.betAmount = betAmount;
          this.roundData.players[playerOffset].data.payouts.push(payout);
          payouts[betType][playerOffset] = payout;
          if (payout.winnings > 0) {
            await this.repositories.user.updateBalance({ way: 'IN', userId: player.data.user.id, amount: payout.winnings, transactionType: betType == '21+3' ? 'BET_BLACKJACK_PLUSTHREE_WINNINGS' : 'BET_BLACKJACK_PERFECTPAIRS_WINNINGS' });
          }

        }
      } catch (err) {
        this.modules.logger.log('game-blackjack-awardSideBets-errors', err.name);
        this.modules.logger.log('game-blackjack-awardSideBets-errors', err.stack);
        this.modules.logger.log('game-blackjack-awardSideBets-errors', err.message);
      }
    }

    const packetName = `blackjack:round:setSideBetPayouts`;
    const packetData = {
      payouts
    };
    this.publishPacket(packetName, packetData);
    //PAYOUTS WILL BE USED TO FINALIZE BETS, SAVE THEM TO DATABASE
  }

  async awardMainBets() {
    const payouts = {};
    const playerOffsets = Object.keys(this.roundData.players);
    for (let i in playerOffsets) {
      const offset = playerOffsets[i];
      const player = this.roundData.players[offset];
      if (!player.data.user || !player.hasMainBet) continue;

      payouts[offset] = [];

      const insuranceRound = this.roundData.dealer.firstCard.index == 'A';
      const dealerScore = this.roundData.dealer.data.hand.score;
      const dealerHasBJ = this.roundData.dealer.hasBJ;

      const handTypes = Object.keys(player.data.hands);
      for (let j in handTypes) {
        const handType = handTypes[j];
        const hand = player.data.hands[handType];
        const betAmount = hand.betAmount;
        if (betAmount <= 0 || (player.data.splitted && handType == 'MAIN')) continue;

        const handName = `${handType.replace('SPLITTED_', '')} HAND`;
        const payout = { betType: 'MAIN', handName, name: 'NOTHING', betAmount, winnings: 0, rate: 0 };

        if (hand.score <= 21) {
          const isBlackjack = hand.score == 21 && hand.cards.length == 2;
          if (hand.score > dealerScore || dealerScore > 21 || (hand.score == 21 && !dealerHasBJ && isBlackjack)) { //player wins
            payout.winnings = betAmount * 2;
            payout.rate = 2;
            payout.name = `WIN ~ ${handName}`;
            if (isBlackjack) {
              payout.rate = 2.5;
              payout.name = `BJ ~ ${handName}`;
              payout.winnings += betAmount * 0.5;
            }
          } else if (
            (hand.score == 21 && dealerScore == 21 && !dealerHasBJ && !isBlackjack)
            || (hand.score == 21 && dealerScore == 21 && dealerHasBJ && isBlackjack)
            || (hand.score == dealerScore && !dealerHasBJ && !isBlackjack)
          ) { //tie
            payout.rate = 1;
            payout.name = `PUSH ~ ${handName}`;
            payout.winnings = betAmount;
          } else { //lose

          }
        }

        if (payout.winnings > 0) {
          await this.repositories.user.updateBalance({ way: 'IN', userId: player.data.user.id, amount: payout.winnings, transactionType: 'BET_BLACKJACK_WINNINGS' });
        }
        payouts[offset].push(payout);
        this.roundData.players[offset].data.payouts.push(payout);
      }


      //this.roundData.players[offset].data.payouts['MAIN'] = payout;
      //console.log('payout there', payout);
      //this.roundData.players[offset].data.payouts['MAIN'] = payout;
      //player.data.payouts['MAIN'] = payouts[offset];
    }


    const packetName = `blackjack:round:setMainPayouts`;
    const packetData = {
      payouts
    };
    this.publishPacket(packetName, packetData);
  }

  async finalizeBets() {
    const playerOffsets = Object.keys(this.roundData.players);
    for (let i in playerOffsets) {
      let offset = playerOffsets[i];
      let player = this.roundData.players[offset];
      if (!player.data.user) continue;
      try {
        let totalBetAmount = 0;
        let totalWinnings = 0;
        player.data.payouts.map((payout) => {
          totalBetAmount += payout.betAmount;
          totalWinnings += payout.winnings;
        });

        let won = totalWinnings > 0;
        const multiplier = 0;
        const riskPayoutRate = 2;
        await this.repositories.user.finalizeBet({ userId: player.data.user.id, game: 'BLACKJACK', roundId: this.roundData.id, betAmount: totalBetAmount, betTo: '', won, betWinner: '', multiplier, winnings: totalWinnings, riskPayoutRate });
        this.repositories.middlewares.betting.on_finalizeBet({ game: 'BLACKJACK', userId: player.data.user.id, betAmount: totalBetAmount, won, riskPayoutRate })

        await this.modules.db.exec("INSERT INTO game_blackjack_round_bets SET ?", [{
          roundId: this.roundData.id,
          userId: player.data.user.id,
          playerOffset: offset,
          handsJson: JSON.stringify(player.data.hands),
          payoutsJson: JSON.stringify(player.data.payouts),
          totalBetAmount,
          totalWinnings
        }]);

      } catch (err) {
        this.modules.logger.log('game-blackjack-finalizeBets-errors', err.name);
        this.modules.logger.log('game-blackjack-finalizeBets-errors', err.stack);
        this.modules.logger.log('game-blackjack-finalizeBets-errors', err.message);
      }
      //console.log('finalize bet', player.data.user.id, totalBetAmount, totalWinnings);
      //save side bets to database
      //const insuranceRound = this.roundData.dealer.firstCard.index == 'A';
    }
  }

  async finalizeDealerHand() {
    this.roundData.dealer.data.hand.cards.forEach((entry) => { delete entry.invisible });
    await this.modules.db.exec("UPDATE game_blackjack_rounds SET dealerHand = ? WHERE id = ?", [JSON.stringify(this.roundData.dealer.data.hand), this.roundData.id])

  }


  resetUserVariables() {
    const playerOffsets = Object.keys(this.roundData.players);
    for (let i in playerOffsets) {
      const offset = playerOffsets[i];
      let player = this.roundData.players[offset];
      player.resetVariables();
    }

    this.roundData.playingPlayerOffset = 5;
  }

  async resetRoundVariables() {
    this.resetUserVariables();
    this.roundData.dealer.resetVariables();
    //close
    await this.wrapper.db.closeRound(this.roundData.id);
    const roundVariables = await this.wrapper.db.createNewRound(this.id);
    this.roundData = {
      ...this.roundData,
      ...roundVariables
    }

    const packetName = `blackjack:round:setData`;
    const packetData = {
      newData: this.publicRoundData
    };
    this.publishPacket(packetName, packetData);
  }




  publishPacket(packetName, packetData) {
    packetData = {
      tableId: this.id,
      ...packetData
    };
    this.repositories.redis.publish('workers', packetName, packetData);
    this.repositories.redis.ioPublishChannel(this.ioChannelName, packetName, packetData);
  }

}