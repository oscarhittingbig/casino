module.exports = class {

  constructor({params, table}) {
    params.inject(this);
    this.table = table;

    this.data = {
      hand: {
        cards: [],
        score: 0
      }
    };
  }

  get firstCard() {
    return this.data.hand.cards[0];
  }

  get hasBJ() {
    const score = this.repositories.blackjack.odds.calculateHandScore(this.data.hand.cards);
    return this.data.hand.cards.length == 2 && score == 21;
  }

  drawCard(invisible = undefined) {
    const card = this.table.pickCard();
    this.pushCard(card, invisible);
  }

  pushCard(card, invisible) {
    if (invisible) card.invisible = true;
    else card.invisible = false;
    this.data.hand.cards.push(card);
    if (!invisible) this.data.hand.score = this.repositories.blackjack.odds.calculateHandScore(this.data.hand.cards);
  
    const packetName = `blackjack:dealer:pushCard`;
    const packetData = {
      newCard: JSON.parse(JSON.stringify(card)),
      newScore: this.data.hand.score
    };
    if (invisible) {
      packetData.newCard.pip = '♢';
      packetData.newCard.index = 'A';
    }
    this.table.publishPacket(packetName, packetData);
  }

  showHiddenCard() {
    let card = this.data.hand.cards[1];
    card.invisible = false;
    this.data.hand.score = this.repositories.blackjack.odds.calculateHandScore(this.data.hand.cards);
    const packetName = `blackjack:dealer:showHiddenCard`;
    const packetData = {
      newCard: card,
      newScore: this.data.hand.score
    };
    this.table.publishPacket(packetName, packetData);
  }

  resetVariables() {
    this.data.hand = { cards: [], score: 0 };
  }





}