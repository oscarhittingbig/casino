const sleep = require('await-sleep');

module.exports = class {

  constructor({ params, table, offset }) {
    params.inject(this);
    this.table = table;

    this.data = {
      offset,
      user: null,
      hands: {
        'MAIN': { cards: [], score: 0, played: false, betAmount: 0 },
        'SPLITTED_LEFT': { cards: [], score: 0, played: false, betAmount: 0 },
        'SPLITTED_RIGHT': { cards: [], score: 0, played: false, betAmount: 0 }
      },
      bets: {
        'MAIN': { amount: 0, chips: [] },
        '21+3': { amount: 0, chips: [] },
        'PERFECT_PAIRS': { amount: 0, chips: [] }
      },
      sideBetsProcessed: false,

      payouts: [],
      splitted: false, //maybesend splitted?
      decisionHand: 'MAIN',

      winnings: [],

      lastDecision: null,
      decisionMade: false, //maybe send setDecisionMade for specific user? 

      insuranceCost: 0,
      lastInsuranceCost: 0,
      insuranceTaken: false
    };

    this.isAvailable = true;
  }

  get hasBet() {
    let has = false;
    Object.keys(this.data.bets).forEach(betType => { if (this.data.bets[betType].amount > 0) has = true; })
    return has;
  }

  get totalBetAmount() {
    let sum = 0;
    Object.keys(this.data.bets).forEach(betType => {
      sum += this.data.bets[betType].amount;
    });
    return sum;
  }

  get hasPair() {
    return this.data.hands['MAIN'].cards[0].index == this.data.hands['MAIN'].cards[1].index;
  }

  get hasMainBet() {
    return this.data.bets['MAIN'].amount > 0;
  }

  get currentHand() {
    return this.data.hands[this.data.decisionHand];
  }

  get identifiers() {
    return {
      offset: this.data.offset,
    };
  }

  get isHandAt21() {
    return this.currentHand.score == 21;
  }

  setAvailability(isAvailable) {
    this.isAvailable = isAvailable;
  }

  resetBets() {
    Object.keys(this.data.bets).forEach((betType) => {
      this.data.bets[betType].amount = 0;
      this.data.bets[betType].chips = [];
    });
  }

  setUser(user) {
    this.data.user = user;
    this.resetBets();
    const packetName = 'blackjack:player:setUser';
    const packetData = {
      ...this.identifiers,
      user,
      bets: this.data.bets
    };
    this.table.publishPacket(packetName, packetData);
  }

  placeBet(handType, amount) {
    let newBet = { amount: 0, chips: [] }
    if (handType == 'MAIN' || handType == '21+3' || handType == 'PERFECT_PAIRS') {
      this.data.bets[handType].amount += amount;
      this.data.bets[handType].chips.push(amount);
      newBet = this.data.bets[handType];
    }

    if (handType == 'MAIN' || handType == 'SPLITTED_LEFT' || handType == 'SPLITTED_RIGHT') {
      this.data.hands[handType].betAmount += amount;
      newBet.amount = this.data.hands[handType].betAmount;
    }

    //it needs to be altered after round is started

    const packetName = 'blackjack:player:setBetAmount';
    const packetData = {
      ...this.identifiers,
      handType,
      newBet
    };
    this.table.publishPacket(packetName, packetData);
  }

  async commandBet(command) {
    let betsAltered = false;
    const betKeys = Object.keys(this.data.bets);
    switch (command) {
      case 'REDO':
        if (this.table.lastBets[this.data.user.id]) {
          this.data.bets = this.table.lastBets[this.data.user.id];
          betsAltered = true;
        }
        break;

      case 'DOUBLE':

        for (let i in betKeys) {
          const betKey = betKeys[i];
          this.data.bets[betKey].amount *= 2;
          if (this.data.bets[betKey].amount > this.table.defs.maxBet)
            this.data.bets[betKey].amount = this.table.defs.maxBet;
          else this.data.bets[betKey].chips = this.data.bets[betKey].chips.concat(this.data.bets[betKey].chips);
        }
        betsAltered = true;

        break;

      case 'CLEAR':

        for (let i in betKeys) {
          const betKey = betKeys[i];
          this.data.bets[betKey].amount = 0;
          this.data.bets[betKey].chips = [];
          this.data.hands['MAIN'].betAmount = 0;
        }
        betsAltered = true;

        break;
    }

    if (!betsAltered) return;
    const packetName = 'blackjack:player:setBets';
    const packetData = {
      ...this.identifiers,
      newBets: this.data.bets
    };
    this.table.publishPacket(packetName, packetData);
  }

  drawCard(handType, manualDraw) {
    if (manualDraw) this.data.hands[handType].played = true;
    const card = this.table.pickCard();
    this.pushCard(handType, card);
  }

  pushCard(handType, card) {
    this.data.hands[handType].cards.push(card);
    const newScore = this.repositories.blackjack.odds.calculateHandScore(this.data.hands[handType].cards);
    this.data.hands[handType].score = newScore;

    //console.log(`Card for player ${playerOffset} -- ${card.pip} ${card.index}`)

    const packetName = 'blackjack:player:pushCard';
    const packetData = {
      ...this.identifiers,
      handType,
      newCard: card,
      newScore,
      newPlayed: this.data.hands[handType].played
    };
    this.table.publishPacket(packetName, packetData);
  }

  addInsurance(insuranceCost) {
    //this.placeBet('MAIN', insuranceCost);

    this.data.insuranceCost = insuranceCost;
    this.data.lastInsuranceCost = insuranceCost;
    const packetName = 'blackjack:player:addInsurance';
    const packetData = {
      ...this.identifiers,
      newInsuranceCost: insuranceCost
      //newBet: this.data.bets['MAIN']
    };
    this.table.publishPacket(packetName, packetData);
  }

  async doubleDown() {

    try {

      if (this.data.hands[this.data.decisionHand].played) return;
      const betAmount = this.currentHand.betAmount;
      await this.repositories.user.updateBalance({ way: 'OUT', userId: this.data.user.id, amount: betAmount, transactionType: 'BET_BLACKJACK', alterType: 'BET', alterName: 'BLACKJACK' });
      
      //
      this.placeBet(this.data.decisionHand, betAmount);
      await sleep(1000);
      this.drawCard(this.data.decisionHand, true);
      await sleep(1500);
    } catch (err) {

    } finally {
      this.goToNextHand();
    }

    /*
    const packetName = 'blackjack:player:doubleDown';
    const packetData = {
      ...this.identifiers,
      handKey: this.data.decisionHand,
      betAmount: currentHand.betAmount
    };
    this.table.publishPacket(packetName, packetData);
    */
  }
  setPlayed() {
    this.data.hands[this.data.decisionHand].played = true;
  }
  async hit() {
    this.setPlayed();
    this.drawCard(this.data.decisionHand, true);
    await sleep(1000);
    if (this.currentHand.score >= 21) {
      this.goToNextHand();
    }
    else {
      this.table.resetPhaseTimer();
      this.setDecision(null);
    }
  }
  async splitHand() {
    try {
      //to disable aces ->  || this.data.hands['MAIN'].cards[0].index == 'A'
      if (this.data.splitted || !this.hasPair || this.data.hands['MAIN'].played) return this.goToNextHand();

      const betAmount = this.currentHand.betAmount;
      await this.repositories.user.updateBalance({ way: 'OUT', userId: this.data.user.id, amount: betAmount, transactionType: 'BET_BLACKJACK', alterType: 'BET', alterName: 'BLACKJACK' });
      

      this.setPlayed();
      this.data.splitted = true;
      const mainHand = this.data.hands['MAIN'];
      for (let i = 0; i < 2; i++) {
        const card = mainHand.cards[i];
        const handKey = i == 0 ? 'SPLITTED_LEFT' : 'SPLITTED_RIGHT';
        this.data.hands[handKey].cards.push(card);
        this.data.hands[handKey].score = this.repositories.blackjack.odds.calculateHandScore(this.data.hands[handKey].cards);
        this.data.hands[handKey].betAmount = mainHand.betAmount;
      }

      this.data.hands['MAIN'].cards = [];
      this.data.hands['MAIN'].score = 0;
      this.data.hands['MAIN'].betAmount = 0;

      const packetName = 'blackjack:player:splitHand';
      const packetData = {
        ...this.identifiers,
        newHands: this.data.hands,
        newDecisionHand: this.data.decisionHand
      };
      this.table.publishPacket(packetName, packetData);
      await sleep(1000);
      this.drawCard('SPLITTED_RIGHT', false);
      await sleep(1500);
      this.drawCard('SPLITTED_LEFT', false);
      await sleep(1500);
      this.table.resetPhaseTimer();
      this.setDecision(null);
      this.setDecisionHand('SPLITTED_RIGHT');
    } catch (err) {
      this.goToNextHand();
    }
  }

  goToNextHand() {
    if (this.data.decisionHand == 'MAIN') {
      this.table.goToNextPlayer();
    } else if (this.data.decisionHand == 'SPLITTED_RIGHT') {
      this.setDecisionHand('SPLITTED_LEFT');
      this.table.resetPhaseTimer();
      this.setDecision(null);
    } else {
      this.table.goToNextPlayer();
    }
  }

  setDecisionHand(handType) {
    this.data.decisionHand = handType;
    this.table.resetPhaseTimer();
    const packetName = 'blackjack:player:setDecisionHand';
    const packetData = {
      ...this.identifiers,
      newDecisionHand: this.data.decisionHand
    };
    this.table.publishPacket(packetName, packetData);
  }


  setDecision(decision) {

    this.data.lastDecision = decision;
    //if (decision && !decision.startsWith("INSURANCE")) this.data.hands[this.data.decisionHand].played = true;
    //If It is users second movement, then stop?
    //reset timer there maybe?

    const packetName = 'blackjack:player:setDecision';
    const packetData = {
      ...this.identifiers,
      newDecision: this.data.lastDecision
    };
    this.table.publishPacket(packetName, packetData);
  }


  resetHands() {
    const handKeys = Object.keys(this.data.hands);
    for (let i in handKeys) {
      const handKey = handKeys[i];
      this.data.hands[handKey] = { cards: [], score: 0, played: false, betAmount: 0 };
    }
  }


  resetBets() {
    const betKeys = ['MAIN', '21+3', 'PERFECT_PAIRS'];
    for (let i in betKeys) {
      const betKey = betKeys[i];
      this.data.bets[betKey] = { amount: 0, chips: [] };
      //this.data.payouts[betKey] = { name: 'NOTHING', betAmount: 0, winnings: 0, rate: 0};
    }
    this.data.payouts = [];
  }

  resetVariables() {
    this.resetHands();
    this.resetBets();

    this.data.splitted = false;
    this.data.sideBetsProcessed = false;
    this.data.decisionHand = 'MAIN';
    this.data.lastDecision = null;
    this.data.decisionMade = false; //maybe send setDecisionMade for specific user? 
    this.data.hasInsurance = false;
    this.data.insuranceTaken = false;
    this.data.lastInsuranceCost = 0;
    this.data.insuranceCost = 0;

    this.isAvailable = true;
  }

}