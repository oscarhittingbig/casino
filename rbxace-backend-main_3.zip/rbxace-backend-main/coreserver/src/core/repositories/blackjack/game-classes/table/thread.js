const sleep = require('await-sleep');

module.exports = class {

  constructor({ params, table }) {
    params.inject(this);
    this.table = table;

    this.defs = {

    }

    this.replayThread();
  }

  get remainingTime() {
    const now = Date.now();
    const elapsed = now - this.table.roundData.lastPhaseStartedAt;
    return (this.repositories.blackjack.game.defs.INTERVALS[this.table.roundData.phase] || 0) - elapsed;
  }

  replayThread() {
    setTimeout(this.mainThread.bind(this), 100);
  }

  async mainThread() {
    try {
      const roundPhase = this.table.roundData.phase;
      if (roundPhase == 'WAITING_FOR_PLAYERS') return;

      switch (roundPhase) {
        case 'PREPARATION': await this.handlePreparationPhase(); break;
        case 'DEALING': await this.handleDealingPhase(); break;
        case 'INSURANCE': await this.handleInsurancePhase(); break;
        case 'PLAYING': await this.handlePlayingPhase(); break;
        case 'DEALER': await this.handleDealerPhase(); break;
        case 'END_GAME': await this.handleEndGamePhase(); break;
      }

    } catch (err) {
      console.log(err)
    } finally {
      this.replayThread();
    }
  }

  async handlePreparationPhase() {
    //console.log('Preparation', this.remainingTime, this.table.allPlayersAvailable, 'anybet', this.table.anyBet)
    if (this.remainingTime > 0 || !this.table.allPlayersAvailable) return;
    await this.table.processBets();
    if (!this.table.anyBet) {
      this.table.clearLastBets();
      return this.table.setPhase('WAITING_FOR_PLAYERS');
    }
    this.table.saveLastBets();
    this.table.addBetsToHands();
    this.table.setPhase('DEALING');
  }

  async handleDealingPhase() {
    await this.table.deal();
  }

  async handleInsurancePhase() {
    //console.log(this.remainingTime, this.table.allPlayersDecided, this.table.allPlayersAvailable)
    if ( (this.remainingTime > 0 && !this.table.allPlayersDecided) || !this.table.allPlayersAvailable) return;
    this.table.setAvailability(false);
    await sleep(2000);
    const dealer = this.table.roundData.dealer;
    let ends = false;

    if (dealer.hasBJ) {
      dealer.showHiddenCard();
      await sleep(1500);
      ends = true;
    }

    await this.table.processInsurances();
    if (ends) this.table.setPhase('END_GAME')
    else this.table.setPhase('PLAYING')
    this.table.setAvailability(true);
  }

  async handlePlayingPhase() {
    const currentPlayer = this.table.roundData.players[this.table.roundData.playingPlayerOffset];
    if (!currentPlayer.hasMainBet) return this.table.goToNextPlayer();
    if (currentPlayer.isHandAt21) return currentPlayer.goToNextHand();

    if (!currentPlayer.isAvailable) return;
    if (this.remainingTime > 0 && !currentPlayer.data.lastDecision) return;
    if (currentPlayer.data.lastDecision) {
      let toNext = false;
      currentPlayer.setAvailability(false);
      await sleep(1000);
      switch (currentPlayer.data.lastDecision) {

        case "DOUBLEDOWN":
          await currentPlayer.doubleDown();
          break;

        case 'HIT':
          await currentPlayer.hit();
          break;

          case 'STAND':
            currentPlayer.goToNextHand();
            break;

            case 'SPLIT':
              await currentPlayer.splitHand();
              break;
      }
      //if (!toNext) currentPlayer.setDecision(null);
      currentPlayer.setAvailability(true);
    } else {
      this.table.goToNextPlayer();
    }


  }

  async handleDealerPhase() {
    const dealer = this.table.roundData.dealer;
    await sleep(1000);
    dealer.showHiddenCard();
    await sleep(1500);

    while (dealer.data.hand.score <= 16) {
      dealer.drawCard(false);
      await sleep(1500);
    }

    this.table.setPhase('END_GAME')
  }

  async handleEndGamePhase() {
    if (this.remainingTime > 0) return;

    await this.table.awardMainBets();
    await this.table.finalizeBets();
    await this.table.finalizeDealerHand();
    await sleep(2500),
    await this.table.resetRoundVariables();

    this.table.setPhase('PREPARATION')
  }




}