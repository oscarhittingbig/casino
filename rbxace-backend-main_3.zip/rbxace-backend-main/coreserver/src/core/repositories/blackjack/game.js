const Table = require("./game-classes/table");

module.exports = class {

  constructor(params) {
    params.inject(this);
    this.params = params; //may be necessary

    this.defs = {
      TABLE_TYPES: {
        STANDARD: {
          TABLE_COUNT: 5,
          BET_MIN: 100,
          BET_MAX: 50000
        },
        HIGHROLLER: {
          TABLE_COUNT: 5,
          BET_MIN: 5000,
          BET_MAX: 500000
        }
      },
      INTERVALS: {
        PREPARATION: 10 * 1000,
        INSURANCE: 10 * 1000,
        PLAYING: 10 * 1000,
        END_GAME: 2.5 * 1000
      }
      /*
      TABLE_TYPES: {
        STANDARD: {
          TABLE_COUNT: 5,
          BET_MIN: 1000,
          BET_MAX: 10000
        },
        HIGHROLLER: {
          TABLE_COUNT: 5,
          BET_MIN: 50000,
          BET_MAX: 500000
        }
      }
      */
    };

    this.tables = {};
    Object.keys(this.defs.TABLE_TYPES).forEach(tableType => this.tables[tableType] = []);

    this.init();
  }

  get publicTablesData() {
    const tables = {};
    Object.keys(this.defs.TABLE_TYPES).forEach((tableType) => {
      tables[tableType] = [];
      this.tables[tableType].forEach(table => {
        tables[tableType].push(table.publicRoundData);
      })
    });


    return tables;
  }

  init() {
    const tableTypes = Object.keys(this.defs.TABLE_TYPES);
    tableTypes.forEach( (tableType) => {
      const tableTypeDef = this.defs.TABLE_TYPES[tableType];
      for (let i = 0; i < tableTypeDef.TABLE_COUNT; i++) {
        const table = new Table({
          params: this.params,
          defs: {
            game: this,
            type: tableType,
            minBet: tableTypeDef.BET_MIN,
            maxBet: tableTypeDef.BET_MAX
          },
          id: `${tableType}_${(i + 1)}`,
          index: (i + 1),
          type: tableType,
        });
        this.tables[tableType].push(table);
      }
    });
   
  }

  async initTables() {
    const tableTypes = Object.keys(this.defs.TABLE_TYPES);
    for (let i in tableTypes) {
      const tableType = tableTypes[i];
      for (let i in this.tables[tableType]) {
        const table = this.tables[tableType][i];
        await table.init();
      }
    }
    
  }

}