const crypto = require("crypto");
const shuffleSeed = require('shuffle-seed')

module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      CARD_POINTS: {
        'A': 11,
        'Q': 10,
        'K': 10,
        'J': 10
      },
      CARD_POINTS_FOR_PLUSTHREE: {
        'A': 14,
        'K': 13,
        'Q': 12,
        'J': 11
      },
      PIP_COLORS: {
        '♧': 'BLACK',
        '♢': 'RED',
        '♡': 'RED',
        '♤': 'BLACK'
      }
    }
    

    /*
    setTimeout(() => {


      console.log(this.calculatePlusThreePayout([
        { index: '5', pip: '♤' },
        { index: '7', pip: '♤' },
        { index: 'A', pip: '♤' }
      ]));

      

      //console.log(this.generateRoundVariables())
    }, 1000);
    */

  }
  

  getCardValue(index, plusThree) {
    return this.defs.CARD_POINTS[index] ? this.defs[plusThree ? 'CARD_POINTS_FOR_PLUSTHREE' : 'CARD_POINTS'][index] : parseInt(index);
  }

  extractParametersFromHand(cards, plusThree) {
    cards = JSON.parse(JSON.stringify(cards));
    if (plusThree) {
      cards.forEach((card) => {
        card.value = this.getCardValue(card.index, plusThree);
      });
      cards = cards.sort((a, b) => a.value - b.value);

      if (cards[0].value == 2 && cards[2].index == 'A') {
        cards[2].value = 1;
        cards = cards.sort((a, b) => a.value - b.value);
      }
    }
    let indexes = [];
    let colors = [];
    let pips = [];
    let values = [];

    for (let i in cards) {
      const card = cards[i];
      indexes.push(card.index)
      colors.push(this.defs.PIP_COLORS[card.pip]);
      pips.push(card.pip);
      values.push(card.value);
    }
    return { indexes, colors, pips, values };
  }

  calculateHandScore(cards, plusThree) {
    let score = 0;
    const aceCount = cards.filter(el => el.index == 'A').length;
    const cardsWithoutAce = cards.filter(el => el.index !== 'A');
    cardsWithoutAce.forEach(card => {
      score += this.getCardValue(card.index, plusThree);
    });
    let aceValue = 11;
    if (score + (aceCount * aceValue) > 21) aceValue = 1;
    score += aceCount * aceValue;
    return score;
  }


  calculatePlusThreePayout(cards) {
    const { indexes, colors, pips, values } = this.extractParametersFromHand(cards, true);
    //SUITED THREE OF A KIND
    if (indexes[0] == indexes[1] && indexes[1] == indexes[2]
      && pips[0] == pips[1] && pips[1] == pips[2])
      return { name: 'SUITED_THREE_OF_A_KIND', rate: 100 };

    //STRAIGHT FLUSH
    if ((values[0] + 1) == values[1] && (values[1] + 1) == values[2]
      && pips[0] == pips[1] && pips[1] == pips[2])
      return { name: 'STRAIGHT_FLUSH', rate: 40 };

    //THREE OFF A KIND
    if (values[0] == values[1] && values[1] == values[2])
      return { name: 'THREE_OF_A_KIND', rate: 30 };

    //STRAIGHT
    if ((values[0] + 1) == values[1] && (values[1] + 1) == values[2])
      return { name: 'STRAIGHT', rate: 10 };

    //FLUSH
    if (pips[0] == pips[1] && pips[1] == pips[2])
      return { name: 'FLUSH', rate: 5 };

    return { name: 'NOTHING', rate: 0 };
  }

  calculatePerfectPairsPayout(cards) {
    const { indexes, colors, pips } = this.extractParametersFromHand(cards);

    if (indexes[0] !== indexes[1]) return { name: 'NOTHING', rate: 0 };
    if (colors[0] == colors[1] && pips[0] == pips[1]) return { name: 'PERFECT_PAIR', rate: 25 };
    else if (colors[0] == colors[1]) return { name: 'COLORED_PAIR', rate: 10 };
    else return { name: 'MIXED_PAIR', rate: 5 };
  }



}