const sleep = require('await-sleep');
module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      CHIP_AMOUNTS: {
        'STANDARD': [100, 500, 1000, 5000, 10000, 50000],
        'HIGHROLLER': [5000, 25000, 50000, 100000, 150000, 250000]
      }
    }
  }

  getTable(data) {
    const targetTableId = data.tableId;
    const tableTypes = Object.keys(this.repositories.blackjack.game.tables);
    for (let i in tableTypes) {
      const tableType = tableTypes[i];
      const table = this.repositories.blackjack.game.tables[tableType].find(el => el.id == targetTableId);
      if (table) return table;
    }
    return null;
  }

  getPlayer(table, data) {
    const { user } = data;
    const offsets = Object.keys(table.roundData.players);
    for (let i in offsets) {
      const offset = offsets[i];
      if (table.roundData.players[offset].data.user && table.roundData.players[offset].data.user.id == user.id)
      return table.roundData.players[offset];
    }
    return null;
  }

  playerCanDecide(table, player, user) {
    return table.roundData.phase == 'PLAYING'
      && table.roundData.playingPlayerOffset == playerOffset
      && player.isAvailable
  }



  async on_player_sit(data) {
    let table = this.getTable(data);
    if (!table) return;

    const { user, offset } = data;
    let player = table.roundData.players[offset];

    try {
      if (table.roundData.phase !== 'WAITING_FOR_PLAYERS' && table.roundData.phase !== 'PREPARATION')
      throw new Error("SOCKET_BLACKJACK_SIT_ROUNDPHASEERROR")
      
      const playerOffsets = Object.keys(table.roundData.players);
      for (let i in playerOffsets) {
        const offset = playerOffsets[i];
        let player = table.roundData.players[offset];
        if (player.data.user && player.data.user.id == user.id) throw new Error('SOCKET_BLACKJACK_SIT_ALREADYJOINED');
      }

      const userBalance = await this.repositories.user.getBalance(user.id);
      if (userBalance < this.defs.CHIP_AMOUNTS[table.type][0]) throw new Error("SOCKET_BLACKJACK_SIT_CANTAFFORDMINCHIP")

      if (player.user) throw new Error('SOCKET_BLACKJACK_SIT_NOTAVAILABLE');
      player.setUser(user);
      if (table.roundData.phase == 'WAITING_FOR_PLAYERS') table.setPhase('PREPARATION');
    } catch(err) {
      this.repositories.user.notify(user.id, 'error', err.message)
    }
  }

  async on_player_leave(data) {
    let table = this.getTable(data);
    if (!table) return;

    let player = this.getPlayer(data);
    if (!player) return;

    try {
      if (table.roundData.phase !== 'WAITING_FOR_PLAYERS' && table.roundData.phase !== 'PREPARATION')
      throw new Error("SOCKET_BLACKJACK_SIT_ROUNDPHASEERROR")
      player.setUser(null);
    } catch(err) {
      this.repositories.user.notify(user.id, 'error', err.message)
    }
  }

  async on_player_placeBet(data) {
    let table = this.getTable(data);
    if (!table) return;
    let player = this.getPlayer(table, data);
    if (!player) return;

    const { user, betType, betAmount } = data;
    let availabilityAltered = false;
    try {
      if ( (table.roundData.phase !== 'PREPARATION')
        || !player.data.user
        || player.data.user.id !== user.id
        || !player.isAvailable) throw new Error("SOCKET_BLACKJACK_CANTDOITNOW");

      if (!this.defs.CHIP_AMOUNTS[table.type].includes(betAmount)) throw new Error("NO WAY!");

      const userBalance = await this.repositories.user.getBalance(user.id);
      const newBetAmount = player.data.bets[betType].amount + betAmount;
      const newTotalBetAmount = player.totalBetAmount + betAmount;
      if (userBalance < newTotalBetAmount)
      throw new Error("PAGE_GENERAL_INSUFFICIENTBALANCE");

      if (newBetAmount > table.defs.maxBet) 
      throw new Error("SOCKET_BLACKJACK_MAXBETREACHED");

      player.setAvailability(false);
      availabilityAltered = true;
      //await this.repositories.user.updateBalance({ way: 'OUT', userId: user.id, amount: betAmount, transactionType: 'BET_BLACKJACK', alterType: 'BET', alterName: 'BLACKJACK' });
      player.placeBet(betType, betAmount);

    } catch (err) {
      this.repositories.user.notify(user.id, 'error', err.message)
    } finally {
      if (availabilityAltered) player.setAvailability(true);
    }
    

  }

  async on_player_commandBet(data) {
    let table = this.getTable(data);
    if (!table) return;
    let player = this.getPlayer(table, data);
    if (!player) return;

    const { user, command } = data;
    let availabilityAltered = false;
    try {
      if ( (table.roundData.phase !== 'PREPARATION')
        || !player.data.user
        || player.data.user.id !== user.id
        || !player.isAvailable) throw new Error("SOCKET_BLACKJACK_CANTDOITNOW");

      player.setAvailability(false);
      availabilityAltered = true;
      await player.commandBet(command);

    } catch (err) {
      this.repositories.user.notify(user.id, 'error', err.message)
    } finally {
      if (availabilityAltered) player.setAvailability(true);
    }
  }

  async on_player_setInsuranceStatus(data) {
    let table = this.getTable(data);
    if (!table) return;
    let player = this.getPlayer(table, data);
    if (!player) return;

    const { user, wants } = data;
    if (table.roundData.phase !== 'INSURANCE'
      || !player.data.user
      || player.data.user.id !== user.id
      || !player.hasMainBet
      || !table.isAvailable
      || !player.isAvailable) return;

   
    player.setAvailability(false);
    try {
      if (!wants) return player.setDecision('INSURANCE_NO');

      const betAmount = player.data.bets['MAIN'].amount;
      const insuranceCost = Math.ceil(betAmount * 0.5);
      await this.repositories.user.updateBalance({ way: 'OUT', userId: user.id, amount: insuranceCost, transactionType: 'BET_BLACKJACK', alterType: 'BET', alterName: 'BLACKJACK' });
      player.addInsurance(insuranceCost);
      player.setDecision('INSURANCE_YES');
      //we should log everything there maybe?
      //or update at database?
    } catch (err) {
      this.repositories.user.notify(user.id, 'error', err.message)
    } finally {
      player.setAvailability(true);
    }

    
  }


  async on_player_setDecision(data) {
    let table = this.getTable(data);
    if (!table) return;
    let player = this.getPlayer(table, data);
    if (!player) return;

    const { user, decision } = data;

    if ( !(table.roundData.phase == 'PLAYING'
      && table.roundData.playingPlayerOffset >= player.data.offset
      && !player.data.lastDecision
      && player.isAvailable)
    ) return;

    player.setDecision(decision);

  }



  async on_player_stand(data) {
    let table = this.getTable(data);
    if (!table) return;
    let player = this.getPlayer(table, data);
    if (!player) return;

    const { user, playerOffset } = data;
    if (!this.playerCanDecide(table, player, user) || player.currentHand.score >= 21) return;
    player.goToNextHand();
  }

  async on_player_hit(data) {
    let table = this.getTable(data);
    if (!table) return;
    let player = this.getPlayer(table, data);
    if (!player) return;

    const { user, playerOffset } = data;
    if (!this.playerCanDecide(table, player, user) || player.currentHand.score >= 21 ) return;
    player.setAvailability(false);
    player.drawCard(player.currentHand, true);
    await sleep(1000);
    if (player.currentHand.score >= 21) player.goToNextHand();
    else this.table.resetPhaseTimer();
    player.setAvailability(true);
  }

  async on_player_doubleDown(data) {
    let table = this.getTable(data);
    if (!table) return;
    let player = this.getPlayer(table, data);
    if (!player) return;

    const { user, playerOffset } = data;
    if (!this.playerCanDecide(table, player, user) || player.currentHand.score >= 21) return;
   
   
    player.setAvailability(false);
    try {
      const betAmount = player.currentHand.betAmount;
      await this.repositories.user.updateBalance({ way: 'OUT', userId: user.id, amount: insuranceCost, transactionType: 'BET_BLACKJACK', alterType: 'BET', alterName: 'BLACKJACK' });
      player.doubleDown();
      await sleep(1000);
      player.drawCard(player.currentHand, true);
      await sleep(1000);
      player.goToNextHand();

    } catch (err) {
      this.repositories.user.notify(user.id, 'error', err.message)
    } finally {

    }


    player.setAvailability(true);
  }

  async on_player_splitHand(data) {
    return;
    /* DEPRECATED */
    let table = this.getTable(data);
    if (!table) return;
    let player = this.getPlayer(table, data);
    if (!player) return;

    const { user, playerOffset } = data;
    if (table.roundData.phase !== 'PLAYING'
      || !player.user
      || player.user.id !== user.id
      || table.roundData.playingPlayerOffset !== playerOffset
      || player.splitted
      || !player.hasPair
      || !player.isAvailable) return;

    player.setAvailability(false);
    player.splitHand();
    const handKeys = ['SPLITTED_LEFT', 'SPLITTED_RIGHT'];
    for (let i in handKeys) {
      const handKey = handKeys[i];
      player.drawCard(handKey);
      await sleep(1000);
    }
    player.setDecisionHand('SPLITTED_RIGHT');
    player.setAvailability(true);
  }


}