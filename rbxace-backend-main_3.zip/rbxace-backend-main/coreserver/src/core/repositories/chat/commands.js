const moment = require('moment');
module.exports = class {

  constructor(params) {
    params.inject(this);
  }


  async handle(channel, user, commandInput) {
    let commandParams = commandInput.split(" ");
    let command = commandParams[0];
    commandParams.shift();


    switch (command) {
      case "mute":
        if (user.roleLevel >= 10) {
          this.handleCommand_Mute(channel, user, commandParams);
        }
        break;

      case "unmute":
        if (user.roleLevel >= 10) {
          this.handleCommand_Unmute(channel, user, commandParams);
        }
        break;

      case "ban":
        if (user.roleLevel >= 100) {
          this.handleCommand_Ban(channel, user, commandParams);
        }
        break;

        case "unban":
          if (user.roleLevel >= 100) {
            this.handleCommand_Unban(channel, user, commandParams);
          }
  
          break;

          case "maintenance":
            if (user.roleLevel >= 100) {
              this.handleCommand_Maintenance(channel, user, commandParams);
            }
    
            break;

            case "unmaintenance":
              if (user.roleLevel >= 100) {
                this.handleCommand_Unmaintenance(channel, user, commandParams);
              }
      
              break;

              case "fundrain":
                if (user.roleLevel >= 100) {
                  this.handleCommand_onFundRain(channel, user, commandParams);
                }
        
                break;

      case "clear":
        if (user.roleLevel >= 10) {
          this.handleCommand_Clear(channel, commandParams);
        }
        break;
    }

  }


  
  async handleCommand_Mute(channel, user, commandParams) {
    let userId = commandParams[0];
    let timeInSeconds = commandParams[1];

    if (userId == undefined || timeInSeconds == undefined) {
      return;
    }

    let mutedUser = await this.modules.db.select("user_data_common", "userId", userId);
    if (mutedUser == null) {
      return;
    }

    let now = moment().utc().unix();
    let muteTime = parseInt(timeInSeconds);
    let muteEndsAt = now + muteTime;

    let muted = await this.modules.db.exec("UPDATE user_data_common SET muteEndsAt = ? WHERE userId = ?", [muteEndsAt, userId]);

    if (muted) {
      this.repositories.redis.publishAll("chat:mute", { userId, muteEndsAt });
      this.repositories.chat.main.pushClear({userId});
      this.repositories.user.notify(user.id, 'success', `${targetUser.displayName} has been muted for ${timeInSeconds} seconds!`);
    }
  }

  async handleCommand_Unmute(channel, user, commandParams) {
    let userId = commandParams[0];

    if (userId == undefined) {
      return;
    }

    let targetUser = await this.modules.db.select("user_data_common", "userId", userId);
    if (targetUser == null) {
      return;
    }

    let unmuted = await this.modules.db.exec("UPDATE user_data_common SET muteEndsAt = 0 WHERE userId = ?", [userId]);

    if (unmuted) {
      this.repositories.redis.publishAll("chat:unmute", { userId });
      this.repositories.user.notify(user.id, 'success', `${targetUser.displayName} has been unmuted!`);
    }
  }

  async handleCommand_Ban(channel, user, commandParams) {
    let userId = commandParams[0];

    if (userId == undefined) {
      return;
    }

    let targetUser = await this.modules.db.select("user_data_common", "userId", userId);
    if (targetUser == null) {
      return;
    }

    let banned = await this.modules.db.exec("UPDATE user_data_common SET isBanned = 1 WHERE userId = ?", [userId]);

    if (banned) {
      this.repositories.redis.publishAll("chat:ban", { userId });
      this.repositories.chat.main.pushClear({userId});
      this.repositories.user.notify(user.id, 'success', `${targetUser.displayName} has been banned!`);
    }
  }

  async handleCommand_Unban(channel, user, commandParams) {
    let userId = commandParams[0];

    if (userId == undefined) {
      return;
    }

    let targetUser = await this.modules.db.select("users", "userId", userId);
    if (targetUser == null) {
      return;
    }

    let unbanned =  await this.modules.db.exec("UPDATE user_data_common SET isBanned = 0 WHERE userId = ?", [userId]);

    if (unbanned) {
      this.repositories.redis.publishAll("chat:unban", { userId });
      this.repositories.user.notify(user.id, 'success', `${targetUser.displayName} has been unbanned!`);
    }
  }

  async handleCommand_Maintenance(channel, user, commandParams) {
    let updated = await this.modules.db.exec("UPDATE global_settings SET maintenance = 1");
    this.repositories.chat.main.announceSysMessage({ message: `The server is under maintenance!`});
  }

  async handleCommand_Unmaintenance(channel, user, commandParams) {
    let updated = await this.modules.db.exec("UPDATE global_settings SET maintenance = 0");
    this.repositories.chat.main.announceSysMessage({ message: `The server is live now!`});
  }

  async handleCommand_onFundRain(channel, user, commandParams) {
    let amount = parseInt(commandParams[0]);
    if (!amount || isNaN(amount) || amount <= 0) return;

    await this.repositories.rain.core.increasePotPrize(amount);
    this.repositories.chat.main.announceSysMessage({ message: `Rain pot has been funded ${amount} coins!`});
  }

  async handleCommand_Clear(channel, commandParams) {
    let userId = commandParams[0];
    if (userId == undefined) {
      userId = 0;
    }
    this.repositories.chat.main.pushClear({channel});
    this.repositories.redis.publishAll("chat:clear", { channel });
    if (!userId) {
      this.repositories.chat.main.announceSysMessage({channel, message: `Chat has been cleared by moderators!`});
    }
  }



}