const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      COOLDOWN_SEND: 4750,
      MAX_MESSAGE_COUNT: 50,
      BLACKLISTED_WORDS: [ 'scam', 'nigger', 'nig', 'chink', 'chinc', 'faggot', 'fag', 'coon', 'c00n', 'co0n', 'mooncricket', 'porchmonkey' ]
    }

    this.messages = { 'EN': [], 'RU': [], 'FR': [], 'ES': [], 'TR': [] };
    this.online = 0;

    this.init();
  }

  init() {
    Object.keys(this.messages).forEach(channel => {
      this.messages[channel] = this.modules.cache.fileGet(`chat-${channel}`);
    });

    setInterval(() => {
      this.updateOnlineCount();
    }, 2000);
  }

  logMessage(channel, message) {
    let logMsg = "";
    if (message.type == 'SYS') {
      logMsg = `System -> ${message.content}`;
    } else if (message.type == 'USER') {
      logMsg = `[${message.user.id}] ${message.user.displayName} (${message.user.rank}) [${channel}] -> ${message.content}`;
    }

    this.modules.logger.log("chat", logMsg);
  }

  cacheChat(channel) {
    this.modules.cache.fileSet("chat-" + channel, this.messages[channel]);
  }

  filterMessage(str) {
    this.defs.BLACKLISTED_WORDS.forEach((word) => {
      let censored = '';
      while (censored.length < word.length) censored += '*';
      str = global.replaceAll(str, word, censored)
    });
    return str;

  }

  pushMessage(channel, message) {

    this.messages[channel].push(message);
    if (this.messages[channel].length > this.defs.MAX_MESSAGE_COUNT) {
      this.messages[channel] = this.messages[channel].slice(-this.defs.MAX_MESSAGE_COUNT);
    }
  }


  addNewMessage(channel, message) {
    message.id = uuidv1();
    //message.content = this.filterMessage(message.content);
    let messageData = { channel, message };
    this.pushMessage(channel, message)

    this.repositories.redis.publish("workers", "chat:pushMessage", messageData);
    this.repositories.redis.ioPublishChannel(`chat-${channel}`, "chat:pushMessage", messageData);

    this.cacheChat(channel);
    this.logMessage(channel, message);
  }

  generateSysMessage(message) {
    return { 
        id: uuidv1(), 
        type: 'SYS', 
        content: message
    };
  }

  announceSysMessage({channel, message}) {
    if (channel) return this.addNewMessage(channel, this.generateSysMessage(message));
    Object.keys(this.messages).forEach((channelKey) => {
      this.addNewMessage(channelKey, this.generateSysMessage(message));
    })
  }

  sendSysMessageToUser(userId, message) {
    this.repositories.redis.ioPublishToUser(userId, 'chat:pushMessage', { message: this.generateSysMessage(message) });
  }


  
  /* May be useful for future */
  pushClear({channel, userId}) {
    if (userId) {
      let channels = Object.keys(this.messages);
      for (let i = 0; i < channels.length; i++) {
        let channelKey = channels[i];

        this.messages[channelKey] = this.messages[channelKey].filter(
          (message) => message.type != "USER" || message.user.id != userId
        );

        this.cacheChat(channelKey);
      }

    } else {
      this.messages[channel] = [];
      this.cacheChat(channel);
    }
  }

  updateOnlineCount() {
    try {

      this.modules.io.sockets.adapter.clients(["global"], (err, clients) => {
        try {
          let newOnline = clients.length;
          if (this.online !== newOnline) {
            this.repositories.redis.publish("workers", "misc:setOnline", newOnline);
            this.repositories.redis.ioPublish("misc:setOnline", newOnline);
            this.online = newOnline;
          }

        } catch (err) {
        }

      });

    } catch (err) {
    }
  }


}