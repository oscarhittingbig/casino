const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async on_sendMessage(data) {
    try {
      let cd = this.modules.cache.getCooldown(`SOCKET_CHAT_SENDMESSAGE|${data.message.user.id}`, this.repositories.chat.main.defs.COOLDOWN_SEND / 1000);
      if (cd > 0 && data.message.user.roleLevel < 10) return;

      if (data.message.content.startsWith("/")) {
        await this.repositories.chat.commands.handle(data.channel, data.message.user, data.message.content.substring(1));
        this.repositories.chat.main.logMessage(data.channel, data.message.content);
        return;
      }

      data.message.id = uuidv1();
      this.repositories.chat.main.addNewMessage(data.channel, data.message)
    } catch (err) {

    }
  }


}