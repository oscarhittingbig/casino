const moment = require('moment');

const sleep = require('await-sleep');
module.exports = class {

  constructor(params) {
    params.inject(this);

  }



  async createRoom(data) {
    const rangeRatio = 0.1; // +- 15% 

    const { ownerId, ownerColor, ownerSkinsValue } = data;
    const rangeMin = ownerSkinsValue * (1 - rangeRatio);
    const rangeMax = ownerSkinsValue * (1 + rangeRatio);

    const { serverSecret, randomOrgSecret, verificationLink, seed, seedHash, ticket, winnerColor } = await this.repositories.coinflip.fairness.generateRoundVariables();
    const roomId = await this.modules.db.insert("INSERT INTO game_coinflip_rooms SET ?", [{
      ownerId,
      ownerColor,
      ownerSkinsValue,
      rangeMin,
      rangeMax,
      serverSecret,
      randomOrgSecret,
      verificationLink,
      seed,
      seedHash,
      ticket,
      winnerColor,
      createdAt: moment().utc().unix()
    }]);
    return roomId;
  }

  async updateRoom(roomId, newPhase) {
    const updateSuccess = await this.modules.db.exec("UPDATE game_coinflip_rooms SET phase = ? WHERE id = ?", [newPhase, roomId]);
    if (!updateSuccess) this.modules.logger.log('game-coinflip-db-errors', `Room with Id ${roomId} - New Phase ${newPhase} - couldn't be updated!`);
  }

  async clearOpponent(roomId) {
    const updateSuccess = await this.modules.db.exec("UPDATE game_coinflip_rooms SET opponentId = 0, phase = 'AWAITING_OPPONENT' WHERE id = ?", [roomId]);
    if (!updateSuccess) this.modules.logger.log('game-coinflip-db-errors', `Room with Id ${roomId} - Couldn't be cleared from opponent!`);
  }
  
  async updateChances({roomId, ownerChance, opponentChance}) {
    const updateSuccess = await this.modules.db.exec("UPDATE game_coinflip_rooms SET ownerChance = ?, opponentChance = ? WHERE id = ?", [ownerChance, opponentChance, roomId]);
    if (!updateSuccess) this.modules.logger.log('game-coinflip-db-errors', `Room with Id ${roomId} - Chances couldn't be updated!`);
  }
  
  async getUserProfile(userId) {
    const user = (await this.modules.db.query("SELECT users.*, user_data_common.displayName, user_data_common.avatar, user_data_common.balance, user_data_common.isBanned, user_data_common.exp, user_data_settings.tradeUrl, user_data_settings.volume, user_data_settings.isAnon, user_data_settings.isPrivate FROM users INNER JOIN user_data_common ON user_data_common.userId = users.id INNER JOIN user_data_settings ON user_data_settings.userId = users.id WHERE id = ?", [userId]))[0];
    const modifiedUserData = this.repositories.user.modifyUserData(user);
    const userProfile = this.repositories.user.getUserProfile(modifiedUserData);
    return userProfile;
  }

  async finalizeResults({roomId, winnerId, winnerColor}) {
    const updateSuccess =  await this.modules.db.exec("UPDATE game_coinflip_rooms SET winnerId = ?, winnerColor = ? WHERE id = ?", [winnerId, winnerColor, roomId]);
    if (!updateSuccess) this.modules.logger.log('game-coinflip-db-errors', `Room couldn't be finalized, winner id #${winnerId} !`);
  }

  generatePlayerStructure({ profile, items, skinsValue, color }) {
    return {
      user: profile,
      items,
      skinsValue,
      color,
      chance: 50
    }
  }

  async getPlayerData({ roomId, userId, skinsValue, color, offerId }) {
    const data = { skinsValue, color };
    data.profile = await this.getUserProfile(userId);
    /*
    if (hasCompletedOffer) {
      data.items = await this.modules.db.query("SELECT market_hash_name, value, app, image, amount FROM steam_trade_offer_items WHERE offerId = ? ORDER BY id ASC", [offerId]);
    }
    */
    const profileData = this.generatePlayerStructure(data);
    return profileData;
  }

  async getActiveRoomIds(){
    const activeRoomIds = await this.modules.db.query("SELECT id FROM game_coinflip_rooms WHERE phase >= 2 AND phase <= 4");
    return activeRoomIds.reduce((arr, obj) => { arr.push(obj.id); return arr; }, []);
  }

  async addItems({roomId, type, items}) {
    for (let i in items) {
      const item = items[i];
      const insertSuccess = await this.modules.db.exec("INSERT INTO game_coinflip_room_items SET ?", [{
        roomId,
        type,
        amount: item.amount,
        market_hash_name: item.market_hash_name,
        image: item.image,
        value: item.value
      }]);
      if (!insertSuccess) this.modules.logger.log('game-coinflip-db-errors', `Item couldn't be added to room ${roomId} -- ${JSON.stringify(item)}`);
    }

  }

  async getRoom(id) {
    const room = await this.modules.db.select("game_coinflip_rooms", "id", id);

    const owner = await this.getPlayerData({ 
      roomId: room.id, 
      userId: room.ownerId, 
      skinsValue: room.ownerSkinsValue, 
      color: room.ownerColor, 
      hasCompletedOffer: true,
      offerId: room.ownerOfferId
    });

    let opponent = null;
    if (room.opponentId !== 0) {
      const opponentDeposited = room.phase == 'FLIPPING' || room.phase == 'FLIPPED' || room.phase == 'STARTING';
      opponent = await this.getPlayerData({ 
        roomId: room.id, 
        userId: room.opponentId, 
        skinsValue: room.opponentSkinsValue, 
        color: room.ownerColor == 'BLACK' ? 'RED' : 'BLACK', 
        hasCompletedOffer: opponentDeposited,
        offerId: room.lastOpponentOfferId
      });
    }

    const roomData = {
      id: room.id,
      phase: room.phase,
      seedHash: room.seedHash,
      ticket: room.ticket,
      range: {
        min: room.rangeMin,
        max: room.rangeMax
      },
      owner,
      opponent,
      lastOpponentOfferId: room.lastOpponentOfferId,
      winnerColor:null,
      createdAt: room.createdAt,
      lastUpdateMs: Date.now(),
      ticker: 0
    };

    const items = await this.modules.db.query("SELECT * FROM game_coinflip_room_items WHERE roomId = ? ORDER BY id ASC", [room.id]);
    const itemsGroupped = items.reduce((obj, el) => { if (!obj[el.type]) obj[el.type] = []; obj[el.type].push(el); return obj;}, {});
    Object.keys(itemsGroupped).forEach((type) => {
      roomData[type.toLowerCase()].items = itemsGroupped[type];
    })

    return roomData;
  }

  async getLastOpponentOfferId(roomId) {
    return (await this.modules.db.query("SELECT lastOpponentOfferId FROM game_coinflip_rooms WHERE id = ?", [roomId]))[0].lastOpponentOfferId;
  }

  async joinRoom(data) {
    const { roomId, opponentId, opponentSkinsValue } = data;
    const updateSuccess = await this.modules.db.exec("UPDATE game_coinflip_rooms SET phase = 'AWAITING_OPPONENT_DEPOSIT', opponentId = ?, opponentSkinsValue = ? WHERE id = ? AND opponentId = 0 AND phase = 'AWAITING_OPPONENT'", [opponentId, opponentSkinsValue, roomId])
    return updateSuccess;
  }

}