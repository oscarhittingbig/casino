const crypto = require("crypto");
const Chance = require('chance');

module.exports = class {

  constructor(params) {
    params.inject(this);


    setInterval(() => {
      //console.log(this.generateRoundVariables())
    }, 1000);

  }
  
  getWinnerColor(ticket) {
    if (ticket < 0.5) return 'BLACK';
    else return 'RED';
  }

  async generateRoundVariables() {
    const serverSecret = this.repositories.random.generateRandomString(32);
    let randomOrgSecret = '', verificationLink = '';
    
    const randomOrgVariables = await this.repositories.random.generateServiceString();
    if (randomOrgVariables) {
        randomOrgSecret = randomOrgVariables.string;
        verificationLink = randomOrgVariables.verificationLink;
    }

    const seed = `${serverSecret}:${randomOrgSecret}`;
    const ticket = new Chance(seed).floating({min: 0, max: 1, fixed: 15});
    const seedHash = crypto.createHash("sha256").update(seed).digest("hex");
    
    const winnerColor = this.getWinnerColor(ticket);
    return {
      serverSecret,
      randomOrgSecret,
      verificationLink,
      seed,
      seedHash,
      ticket,
      winnerColor
    }
  }


}