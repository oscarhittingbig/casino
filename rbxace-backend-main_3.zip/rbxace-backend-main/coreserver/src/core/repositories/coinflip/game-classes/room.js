const RoomThread = require('./room/thread');

const sleep = require('await-sleep');

module.exports = class {

  constructor({ params, id, data }) {
    params.inject(this);
    this.params = params;

    this.id = id;
    this.data = data;

    this.winner = null;

    this.init();
  }


  get publicRoomData() {
    let roomData = JSON.parse(JSON.stringify(this.data));
    delete roomData.serverSecret;
    delete roomData.randomOrgSecret;
    delete roomData.ticket;
    return roomData;
  }

  get wrapper() {
    return this.repositories.coinflip;
  }

  init() {
    this.thread = new RoomThread({ params: this.params, room: this })
  }

  async clearOpponent() {
    this.data.phase = 'AWAITING_OPPONENT';
    delete this.data.opponent;
    await this.wrapper.db.clearOpponent(this.id);

    this.publishPacket('coinflip:clearOpponent', {});
  }

  calculateChances() {
    let totalValue = 0;
    totalValue += this.data.owner.skinsValue;
    totalValue += this.data.opponent.skinsValue;

    return {
      ownerChance: parseFloat((this.data.owner.skinsValue / totalValue * 100).toFixed(2)),
      opponentChance: parseFloat((this.data.opponent.skinsValue / totalValue * 100).toFixed(2))
    }
  }


  async setOpponent(opponentId, skinsValue) {
    this.data.opponent = await this.wrapper.db.getPlayerData({ 
      roomId: this.id, 
      userId: opponentId, 
      skinsValue, 
      color: this.data.owner.color == 'BLACK' ? 'RED' : 'BLACK', 
      hasCompletedOffer: false 
    });

    this.data.lastUpdateMs = Date.now();
    this.data.phase = 'AWAITING_OPPONENT_DEPOSIT';

    const chances = this.calculateChances();
    this.data.owner.chance = chances.ownerChance;
    this.data.opponent.chance = chances.opponentChance;

    await this.wrapper.db.updateChances({roomId: this.id, ownerChance: chances.ownerChance, opponentChance: chances.opponentChance});

    const packetData = {
      opponent: this.data.opponent,
      lastUpdateMs: this.data.lastUpdateMs,
      chances
    };

    this.publishPacket('coinflip:setOpponent', packetData);
  }

  async on_opponent_depositCompletion(offer) {
    if (this.data.phase !== 'AWAITING_OPPONENT_DEPOSIT') return;
    this.modules.logger.log('coinflip-opponent-deposits', `Room id ${this.id} -- OFFER ${JSON.stringify(offer)}`);
    const lastOpponentOfferId = await this.wrapper.db.getLastOpponentOfferId(this.id);
    this.modules.logger.log('coinflip-opponent-deposits', `Room id ${this.id} -- LAST OFFER ${this.id}`);
    if (offer.id !== lastOpponentOfferId) return this.modules.logger.log('game-coinflip', `Room with id ${this.id} -- No matching lastOpponentOfferId, expected ${lastOpponentOfferId} but got ${offer.id}`);

    await this.wrapper.db.addItems({roomId: this.id, type: 'OPPONENT', items: offer.items});
    await this.wrapper.db.updateRoom(this.id, 'STARTING');
    this.data.opponent.items = offer.items;
    this.data.lastUpdateMs = Date.now();
    this.data.phase = 'STARTING';

    const packetData = {
      items: offer.items,
      lastUpdateMs: this.data.lastUpdateMs
    };

    this.publishPacket('coinflip:completeOpponentDeposit', packetData);

    this.redirectToRoom(offer.userId);
  }

  redirectToRoom(userId) {
    this.repositories.redis.ioPublishToUser(userId, 'coinflip:toggleRoomPopup', { roomId: this.id });
  }
  getLowerRegionEnd() {
    let totalValue = 0;
    totalValue += this.data.owner.skinsValue;
    totalValue += this.data.opponent.skinsValue;

    const targetValue = this.data.owner.color == 'BLACK' ? this.data.owner.skinsValue : this.data.opponent.skinsValue;
    const lowerRegionEnd = parseFloat( (targetValue / totalValue).toFixed(15) );
    return lowerRegionEnd;
  }

  pickWinnerVariables() {
    let color = 'RED';
    const blackRegionEnd = this.getLowerRegionEnd();
    if (this.data.ticket < blackRegionEnd) color = 'BLACK';

    const winner = color == this.data.owner.color ? this.data.owner.user : this.data.opponent.user;
    return { winner, color };
  }

  async flipCoin() {
    const { winner, color } = this.pickWinnerVariables();
    this.winner = winner;
    this.data.winnerColor = color;

    await this.setPhase('FLIPPING');
    const packetData = {
      winnerColor: color,
      lastUpdateMs: this.data.lastUpdateMs
    };

    this.publishPacket('coinflip:flipCoin', packetData);
  }

  async finalize() {
    this.wrapper.game.increaseStat(this.data.winnerColor);
    this.wrapper.game.pushHistory(this.data.winnerColor);
    await this.wrapper.db.finalizeResults({ roomId: this.id, winnerId: this.winner.id, winnerColor: this.data.winnerColor });
    this.repositories.redis.ioPublishToUser(this.winner.id, 'coinflip:toggleWinningPopup', { roomId: this.id });
    await this.setPhase('FLIPPED', true);
  }

  destroy() {
    this.repositories.coinflip.game.rooms = this.repositories.coinflip.game.rooms.filter(el => el.id !== this.id);
    this.publishPacket('coinflip:deleteRoom', {});
  }

  async setPhase(newPhase, publishPacket = false) {
    await this.wrapper.db.updateRoom(this.id, newPhase);
    
    this.data.lastUpdateMs = Date.now();
    this.data.phase = newPhase;

    if (!publishPacket) return;

    const packetData = {
      newPhase,
      lastUpdateMs: this.data.lastUpdateMs
    };

    this.publishPacket('coinflip:setPhase', packetData);
  }

  publishPacket(packetName, packetData) {
    packetData = {
      roomId: this.id,
      ...packetData
    };
    this.wrapper.game.publishPacket(packetName, packetData);
  }

}