const sleep = require('await-sleep');

module.exports = class {

  constructor({ params, room }) {
    params.inject(this);
    this.room = room;

    this.defs = {

    }

    this.destroyed = false;

    this.replayThread();
  }

  get remainingTime() {
    const now = Date.now();
    const elapsed = now - this.room.data.lastUpdateMs;
    return (this.repositories.coinflip.game.defs.INTERVALS[this.room.data.phase] || 0) - elapsed;
  }

  replayThread() {
    setTimeout(this.mainThread.bind(this), 250);
  }

  async mainThread() {
    try {
      const phase = this.room.data.phase;
      //console.log('Phase', phase);
      if (phase == 'AWAITING_OPPONENT') return;

      switch (phase) {
        case 'AWAITING_OPPONENT_DEPOSIT': await this.handleAwaitingOpponentDepositPhase(); break;
        case 'STARTING': await this.handleStartingPhase(); break;
        case 'FLIPPING': await this.handleFlippingPhase(); break;
        case 'FLIPPED': await this.handleFlippedPhase(); break;
      }

    } catch (err) {
      console.log(err)
    } finally {
      if (!this.destroyed) this.replayThread();
    }
  }

  async handleAwaitingOpponentDepositPhase() {
    if (this.remainingTime > 0) return;
    await this.room.clearOpponent();
  }

  async handleStartingPhase() {
    if (this.remainingTime > 0) return;
    await this.room.flipCoin();
    //this.room.setPhase('FLIPPING');
  }

  async handleFlippingPhase() {
    if (this.remainingTime > 0) return;
    await this.room.finalize();
    
  }

  async handleFlippedPhase() {
    if (this.remainingTime > 0) return;
    await this.room.destroy();
    this.destroyed = true;
    //destroy thread
    //remove room from main array
  }






}