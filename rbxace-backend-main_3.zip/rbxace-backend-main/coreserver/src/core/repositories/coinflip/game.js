const Room = require("./game-classes/room");

module.exports = class {

  constructor(params) {
    params.inject(this);
    this.params = params; //may be necessary

    this.defs = {
      INTERVALS: {
        AWAITING_OPPONENT_DEPOSIT: 90 * 1000,
        STARTING: 7 * 1000,
        FLIPPING: 7 * 1000,
        FLIPPED: 600 * 1000
      }
    };
    this.rooms = [];
    this.history = this.modules.cache.fileGet('coinflip-history');
    this.stats = { 'BLACK': 0, 'RED': 0, 'TOTAL': 0 };
  }

  get wrapper() {
    return this.repositories.coinflip;
  }

  get publicRoomsData() {
    let rooms = [];
    this.rooms.forEach((room) => {
      rooms.push(room.publicRoomData);
    });
    return rooms;
  }

  async init() {
    await this.initActiveRooms();
    await this.initStats();
  }

  saveHistory() {
    this.modules.cache.fileSet('coinflip-history', this.history);
  }

  async initActiveRooms() {
    const activeRoomIds = await this.wrapper.db.getActiveRoomIds();
    for (let i in activeRoomIds) {
      const activeRoomId = activeRoomIds[i];
      await this.addRoom(activeRoomId);
    }
  }

  async initStats() {
    const stats = (await this.modules.db.query("SELECT COUNT(1) as count, winnerColor FROM game_coinflip_rooms WHERE phase = 'FLIPPED' GROUP BY winnerColor"));
    for (let i in stats) {
      const stat = stats[i];
      const color = stat.winnerColor;
      this.stats[color] += stat.count;
      this.stats['TOTAL'] += stat.count;
    }
  }

  async doubledown(data) {
    const { roomId, ownerId, ownerColor } = data;

    //ownerId, ownerColor, ownerSkinsValue
    const items = await this.modules.db.query("SELECT id, id as assetid, amount, value, market_hash_name, image FROM game_coinflip_room_items WHERE roomId = ? ORDER BY id ASC", [roomId]);
    const ownerSkinsValue = items.reduce((sum, el) => { sum += (el.amount * el.value); return sum; }, 0);

    const newRoomId = await this.wrapper.db.createRoom({ ownerId, ownerColor, ownerSkinsValue })
    await this.wrapper.db.updateRoom(newRoomId, 'AWAITING_OPPONENT');
    await this.wrapper.db.addItems({roomId: newRoomId, type: 'OWNER', items});
    const newRoom = await this.addRoom(newRoomId)
    //newRoom.redirectToRoom(ownerId);
  }

  async handleTradeCompletion(data) {
    const { offer } = data;
    const roomId = offer.targetId;
    let room = this.getRoom(roomId);
    if (!room) {
      await this.wrapper.db.updateRoom(roomId, 'AWAITING_OPPONENT');
      await this.wrapper.db.addItems({roomId, type: 'OWNER', items: offer.items});
      const newRoom = await this.addRoom(roomId)
      //newRoom.redirectToRoom(offer.userId);
    }
    else {
      return await room.on_opponent_depositCompletion(offer);
    }
  }

  async handleJoin(data) {
    const { roomId, opponentId, opponentSkinsValue } = data;
    let room = this.getRoom(roomId);
    if (!room) return this.modules.logger.log(`game-coinflip-errors`, `Opponent joined on db but not on memory! -- ${roomId} -- ${opponentId}`);
    
    await room.setOpponent(opponentId, opponentSkinsValue);
  }

  async addRoom(id) {
    const roomData = await this.wrapper.db.getRoom(id);
    const newRoom = new Room({ params: this.params, id, data: roomData });
    this.rooms.push(newRoom);
    this.publishPacket('coinflip:pushRoom', roomData);   
    return newRoom;
  }


  getRoom(id) {
    return this.rooms.find(el => el.id == id);
  }

  increaseStat(color) {

    this.stats[color]++;
    this.stats['TOTAL']++;

    this.publishPacket('coinflip:updateStats', { newStats: this.stats });
  }

  pushHistory(color) {
    this.history.unshift(color);
    if (this.history.length > 30) {
      this.history = this.history.slice(0, 30);
    }

    this.publishPacket('coinflip:pushHistory', { color });

    this.saveHistory();
  }

  publishPacket(packetName, packetData) {
    this.repositories.redis.publish('workers', packetName, packetData);
    this.repositories.redis.ioPublishChannel('game:coinflip', packetName, packetData);
  }


}