const Queue = require('bee-queue');
const redisOptions = {
  redis: {
    host: '127.0.0.1',
  }
};

const thisQueue = new Queue('CORESERVER-COINFLIP', redisOptions);

module.exports = class {

  constructor(params) {
    params.inject(this);

    this.init();
  }

  init() {

    thisQueue.process(async (job, done) => {

      let params = { success: false };
      try {
        const packetHeader = job.data.header;
        const packetData = job.data.data;
        params.packetData = packetData;
        switch (packetHeader) {
          case "coinflip:createDbRoom":
            await this.on_coinflip_createDbRoom(params);
            break;
            case "coinflip:joinDbRoom":
              await this.on_coinflip_joinDbRoom(params);
              break;
            case "coinflip:noticeTradeCompleted":
              await this.on_coinflip_noticeTradeCompleted(params);
            break;
            case "coinflip:doubledown":
              await this.on_coinflip_doubledown(params);
              break;

        }
      } catch (err) {

      }
      delete params.packetData;
      return params;
      //return done(null, params);

    });
  }

  async on_coinflip_createDbRoom(params) {
    try {
      params.roomId = await this.repositories.coinflip.db.createRoom(params.packetData)
      params.success = true;
    } catch (err) {
      console.log(err);
    }
  }

  async on_coinflip_joinDbRoom(params) {
    try {
      params.success = await this.repositories.coinflip.db.joinRoom(params.packetData)
      params.roomId = params.packetData.roomId;
      if (params.success) {
        await this.repositories.coinflip.game.handleJoin(params.packetData)
      }
    } catch (err) {

    }
  }

  
  async on_coinflip_noticeTradeCompleted(params) {
    try {
      params.success = await this.repositories.coinflip.game.handleTradeCompletion(params.packetData)
      params.roomId = params.packetData.roomId;
    } catch (err) {

    }
  }

  async on_coinflip_doubledown(params) {
    try {
      await this.repositories.coinflip.game.doubledown(params.packetData)
      params.success = true;
    } catch (err) {
      console.log(err);
    }
  }


}