const sleep = require('await-sleep');
module.exports = class {

  constructor(params) {
    params.inject(this);

  }


}