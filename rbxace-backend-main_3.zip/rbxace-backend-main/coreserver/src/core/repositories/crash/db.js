const moment = require('moment');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async createNewRound() {
    const { serverSecret, randomOrgSecret, verificationLink, houseEdge, seedHash, multiplier, gameDuration, hash} = await this.repositories.crash.fairness.generateRoundVariables();
    const roundId = await this.modules.db.insert("INSERT INTO game_crash_rounds SET ?", [{
          serverSecret,
          randomOrgSecret,
          verificationLink,
          houseEdge,
          seedHash,
          multiplier,
          gameDuration,
          hash,
          createdAt: moment().utc().unix()
      }]);
      return roundId;
  }

  async getRoundData(roundId) {
    const roundData = await this.modules.db.select("game_crash_rounds", "id", roundId);
    roundData.bets = {};
    const bets = await this.modules.db.query("SELECT game_crash_round_bets.*, users.*, user_data_common.displayName, user_data_common.avatar, user_data_common.balance, user_data_common.isBanned, user_data_common.exp, user_data_settings.tradeUrl, user_data_settings.volume, user_data_settings.isAnon, user_data_settings.isPrivate FROM game_crash_round_bets INNER JOIN users ON users.id = game_crash_round_bets.userId INNER JOIN user_data_common ON user_data_common.userId = users.id INNER JOIN user_data_settings ON user_data_settings.userId = users.id WHERE roundId = ? GROUP BY game_crash_round_bets.userId", [roundId]);
    bets.forEach(bet => {
      const user = this.repositories.user.modifyUserData(bet);
      const userProfile = this.repositories.user.getUserProfile(user);
      roundData.bets[user.id] = {
        betAmount: bet.amount,
        autoCashout: bet.autoCashout,
        user: userProfile,
        cashedOut: 0
      };
    });
    roundData.state = 'PREPARATION';
    roundData.startedAt = Date.now();
    roundData.elapsed = 0;
    roundData.finalized = false;
    roundData.currentMultiplier = 1;
    return roundData;
  }

  async updateRoundState({state, roundId, closedAt}) {
    const updateSuccess = await this.modules.db.exec("UPDATE game_crash_rounds SET state = ?, closedAt = ? WHERE id = ?", [state, closedAt || 0, roundId])
    if (!updateSuccess) throw new Error("Round state couldn't be updated!");
  }

  async getLastRound() {
    const lastRoundIdSql = await this.modules.db.query("SELECT id FROM game_crash_rounds WHERE state != 'CRASHED' ORDER BY createdAt DESC LIMIT 1");
    if (lastRoundIdSql.length > 0) {
      const lastRoundId = lastRoundIdSql[0].id;
      return await this.getRoundData(lastRoundId);
    } else {
      const newRoundId = await this.createNewRound();
      return await this.getRoundData(newRoundId);
    }
  }


}