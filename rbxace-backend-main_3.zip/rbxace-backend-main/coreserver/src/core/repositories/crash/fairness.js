const crypto = require("crypto");

module.exports = class {

    constructor(params) {
        params.inject(this);

        /*
        setInterval(() => {
            console.log(this.generateRoundVariables())
        }, 1000);
        */
    }

    divisible(hash, mod) {
        var val = 0;
      
        var o = hash.length % 4;
        for (var i = o > 0 ? o - 4 : 0; i < hash.length; i += 4) {
          val = ((val << 16) + parseInt(hash.substring(i, i + 4), 16)) % mod;
        }
      
        return val === 0;
    }

    generateMultiplier(hash, houseEdge) {
      const hs = parseInt(100 / houseEdge);
      if (this.divisible(hash, hs)) {
        return 1;
      }
    
      const h = parseInt(hash.slice(0, 52 / 4), 16);
      const e = Math.pow(2, 52);
    
      return Math.floor((100 * e - h) / (e - h)) / 100.0;
    }

    async generateRoundVariables() {
        const houseEdge = 5; // %

        const serverSecret = this.repositories.random.generateRandomString(32);
        let randomOrgSecret = '', verificationLink = '';
        
        const randomOrgVariables = await this.repositories.random.generateServiceString();
        if (randomOrgVariables) {
            randomOrgSecret = randomOrgVariables.string;
            verificationLink = randomOrgVariables.verificationLink;
        }

        const seed = `${serverSecret}:${randomOrgSecret}`;
        const seedHash = crypto.createHash("sha256").update(seed).digest("hex");
        const hash = crypto.createHash("sha512").update(seed).digest("hex");
        const multiplier = this.generateMultiplier(seedHash, houseEdge);
        const gameDuration = Math.ceil(this.repositories.crash.game.inverseGrowth(multiplier));
       
        return {
            serverSecret,
            randomOrgSecret,
            verificationLink,
            houseEdge,
            seedHash,
            multiplier,
            gameDuration,
            hash
        }
    }


}
