const moment = require('moment');


module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      PREPARATION_INTERVAL: 7.5 * 1000,
      TIMER_BALANCER: 0
    }

    this.round = {

    };
    this.history = [];

    this.aliveBettingTasks = 0;
  }

  get wrapper() {
    return this.repositories.crash;
  }

  get publicRoundData() {
    let clonedRoundData = JSON.parse(JSON.stringify(this.round));
    delete clonedRoundData.serverSecret;
    delete clonedRoundData.randomOrgSecret;
    delete clonedRoundData.seedHash;
    delete clonedRoundData.multiplier;
    delete clonedRoundData.gameDuration;
    delete clonedRoundData.houseEdge;
    delete clonedRoundData.verificationLink;
    return clonedRoundData;
  }

  async init() {
    const cache = this.modules.cache.fileGet('crash');
    if (!Array.isArray(cache)) {
      this.history = cache.history;
    }
    this.round = await this.repositories.crash.db.getLastRound();
    this.repositories.crash.thread.replayThread();
  }

  saveCache() {
    this.modules.cache.fileSet('crash', {
      history: this.history
    });
  }



  calcY(ms) {
    // return (Math.E ** (0.065 * x)).toFixed(2);
    var r = 0.00006;
    return Math.floor(100 * Math.pow(Math.E, r * ms)) / 100;
  }

  inverseGrowth(result) {
    var c = 16666.666667;
    return c * Math.log(0.01 * result * 100);
  }




  draw(elapsed) {
    const packetData = {
      elapsed,
      currentMultiplier: this.round.currentMultiplier
    };
    this.repositories.redis.publish('workers', 'crash:draw', packetData);
    this.repositories.redis.ioPublishChannel('game:crash', 'crash:draw', packetData);
  }



  async handlePlayerCashout(userId) {
    let bet = this.round.bets[userId];
    const currentMultiplier = this.round.currentMultiplier;
    bet.cashedOut = currentMultiplier;
    const winnings = Math.floor(bet.amount * currentMultiplier);

    await this.repositories.user.updateBalance({ way: 'IN', userId, amount: winnings, transactionType: 'BET_CRASH_WINNINGS' });
    this.repositories.user.notify(userId, 'success', 'SOCKET_GAME_WON', [winnings, 'Crash']);

    const packetData = {
      userId,
      cashedOut: currentMultiplier,
      elapsed: this.round.elapsed
    };
    this.repositories.redis.publish('workers', 'crash:playerCashedOut', packetData);
    this.repositories.redis.ioPublishChannel('game:crash', 'crash:playerCashedOut', packetData);

  }

  async awardPlayers(multiplier) {
    const userIds = Object.keys(this.round.bets);
    for (let i in userIds) {
      const userId = userIds[i];
      const bet = this.round.bets[userId];
      if (!bet.cashedOut && bet.autoCashout && multiplier >= bet.autoCashout) await this.handlePlayerCashout(userId);
    }
  }


  async finalizeBets() {
    const userIds = Object.keys(this.round.bets);
    const currentMultiplier = this.round.currentMultiplier;
    for (let i in userIds) {
      const userId = userIds[i];
      const bet = this.round.bets[userId];
      let winnings = 0;
      let riskPayoutRate = currentMultiplier;
      let won = false;
      if (bet.cashedOut) {
        won = true;
        riskPayoutRate = bet.cashedOut;
        winnings = Math.floor(bet.amount * bet.cashedOut);
      }

      await this.repositories.user.finalizeBet({ userId, game: 'CRASH', roundId: this.round.id, betAmount: bet.amount, betTo: '', won, betWinner: currentMultiplier, multiplier: won ? bet.cashedOut : 0, winnings, riskPayoutRate });
      this.repositories.middlewares.betting.on_finalizeBet({game: 'CRASH', userId, betAmount: bet.amount, won, riskPayoutRate})
    }

    /*
    const colors = Object.keys(this.round.bets);
    colors.forEach( async (color) => {
      const userIds = Object.keys(this.round.bets[color]);
      userIds.forEach(async (userId) =>{
        const bet = this.round.bets[color][userId];
        const won = this.winningColor == color;
        const colorMultiplier = color == 'GOLD' ? 14 : 2;
        const riskPayoutRate = colorMultiplier;

        let winnings = 0;
        if (won) {
          winnings = Math.floor(bet.amount * colorMultiplier);
          await this.repositories.user.updateBalance({ way: 'IN', userId, amount: winnings, transactionType: 'BET_ROULETTE_WINNINGS' });
        }
        await this.repositories.user.finalizeBet({ userId, game: 'ROULETTE', roundId: this.round.id, betAmount: bet.amount, betTo: color.toUpperCase(), won, betWinner: this.winningColor.toUpperCase(), multiplier: colorMultiplier, winnings, riskPayoutRate });

      })
    });
    */
  }

  pushHistory() {
    const lastRound = JSON.parse(JSON.stringify(this.publicRoundData));
    lastRound.multiplier = this.round.multiplier;
    delete lastRound.bets;

    let history = this.history;
    history.unshift(lastRound);
    if (history.length > 20) {
      this.history = history.slice(0, 20);
    }
    return lastRound;
  }

  async pushNewRound(lastRound) {
    await this.wrapper.db.updateRoundState({ state: 'CRASHED', roundId: this.round.id, closedAt: moment().utc().unix() });
    const newRoundId = await this.wrapper.db.createNewRound();
    this.round = await this.wrapper.db.getRoundData(newRoundId);
    this.round.startedAt -= 50; //correction needed for ping

    const packetData = {
      lastRound: lastRound,
      newRound: this.publicRoundData
    };
    this.repositories.redis.publish('workers', 'crash:pushRound', packetData);
    this.repositories.redis.ioPublishChannel('game:crash', 'crash:pushRound', packetData);
    await this.wrapper.thread.mainThread();
  }

  async finalizeRound() {
    const lastRound = this.pushHistory();
    this.saveCache();
    await this.pushNewRound(lastRound);
  }


}