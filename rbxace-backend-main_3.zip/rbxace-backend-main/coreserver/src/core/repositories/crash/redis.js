const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  get wrapper() {
    return this.repositories.crash;
  }

  get round() {
    return this.repositories.crash.game.round;
  }


  async on_bet(data) {
    const { user, betAmount, autoCashout } = data;
    let inBettingTask = false;
    try {
      if (betAmount < global.settings.minBet) return this.repositories.user.notify(user.id, 'error', 'SOCKET_COMMON_MINBET', [betAmount]);

      inBettingTask = true;
      this.wrapper.game.aliveBettingTasks++;

      if (this.wrapper.game.round.state !== 'PREPARATION') return; //throw new Error("SOCKET_CRASH_ROUNDCLOSED")


      await this.repositories.user.updateBalance({ way: 'OUT', userId: user.id, amount: betAmount, transactionType: 'BET_CRASH', alterType: 'BET', alterName: 'CRASH' });
      const betData = {
        autoCashout,
        amount: betAmount,
        user,
        cashedOut: false,
        multiplier: 0
      };

      let bets = this.wrapper.game.round.bets;
      if (!bets[user.id])
        bets[user.id] = betData;
      else
        bets[user.id].amount += betAmount;

      this.repositories.redis.publish('workers', 'crash:pushBet', betData);
      this.repositories.redis.ioPublishChannel('game:crash', 'crash:pushBet', betData);

      //this.repositories.user.notify(user.id, 'success', 'SOCKET_CRASH_BETSUCCESS', [betAmount]);


    } catch (err) {
      this.repositories.user.notify(user.id, 'error', err.message)
    } finally {
      if (inBettingTask) this.wrapper.game.aliveBettingTasks--;
    }
  }

  async on_cashout(data) {
    const userId = data.userId;
    try {
      if (this.round.state !== 'ROLLING') return; //throw new Error("SOCKET_CRASH_ROUNDCLOSED");
      if (!this.round.bets[userId]) throw new Error("SOCKET_CRASH_NOBETINROUND");
      if (this.round.bets[userId].cashedOut) throw new Error("SOCKET_CRASH_ALREADYCASHEDOUT");
      if (this.round.currentMultiplier < 1.01) return; //throw new Error("SOCKET_CRASH_NOCASHOUTAT1");

      await this.wrapper.game.handlePlayerCashout(userId);

    } catch (err) {
      this.repositories.user.notify(userId, 'error', err.message);
    }
  }

}