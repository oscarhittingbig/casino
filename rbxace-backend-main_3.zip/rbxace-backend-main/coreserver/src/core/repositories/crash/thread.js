const sleep = require('await-sleep');

module.exports = class {

  constructor(params) {
    params.inject(this);

  }


  get defs() {
    return this.repositories.crash.game.defs;
  }

  get round() {
    return this.repositories.crash.game.round;
  }

  get wrapper() {
    return this.repositories.crash;
  }


  get remainingTime() {
    const now = Date.now();
    const elapsed = now - this.round.startedAt;

    return this.defs.PREPARATION_INTERVAL - elapsed;
  }

  replayThread() {
    setTimeout(this.mainThread.bind(this), 25);
  }


  async mainThread() {
    //console.log('Crash remaining time:', this.remainingTime)
    if (this.remainingTime > 0 || this.round.state != 'PREPARATION') return this.replayThread();
    await this.startRolling();
  }


  async startRolling() {
    this.round.state = 'ROLLING';

    while (this.wrapper.game.aliveBettingTasks > 0) await sleep(10);
    await this.wrapper.db.updateRoundState({ state: 'ROLLING', roundId: this.round.id, closedAt: 0 })

    this.round.rollingStartedAt = Date.now();
    this.callTick(0);
    const rollingData = {
      rollingStartedAt: this.round.rollingStartedAt
    };

    this.repositories.redis.publish('workers', 'crash:startRolling', rollingData);
    this.repositories.redis.ioPublishChannel('game:crash', 'crash:startRolling', rollingData);

    
  }


  callTick(elapsed) {
    const tickRate = 150;
    var left = this.round.gameDuration - elapsed;
    var nextTick = Math.max(0, Math.min(left, tickRate));
    setTimeout(async() => { await this.runTick(); }, nextTick);
  }

  tick(elapsed, y) {
    this.wrapper.game.draw(elapsed);
    this.callTick(elapsed);
  }

  async runTick() {
    const elapsed = Date.now() - this.round.rollingStartedAt;
    const y = this.wrapper.game.calcY(elapsed);

    this.round.elapsed = elapsed;
    this.round.currentMultiplier = y;

    await this.wrapper.game.awardPlayers(y);
    //console.log('Current Y:', y, 'max y', this.round.multiplier);
    


    if (y >= this.round.multiplier) {
      const multiplier = this.round.multiplier;
      this.round.state = "CRASHED";

      const packetData = {
        elapsed,
        multiplier
      };
  
      this.repositories.redis.publish('workers', 'crash:explode', packetData);
      this.repositories.redis.ioPublishChannel('game:crash', 'crash:explode', packetData);

      //process bets
      //push history
      //then init new round
      //after some timeout

      setTimeout(async () => {
        await this.wrapper.game.finalizeBets();
        await this.wrapper.game.finalizeRound();
      }, 2500)
      return;
    }

    this.tick(elapsed, y);
  }


}