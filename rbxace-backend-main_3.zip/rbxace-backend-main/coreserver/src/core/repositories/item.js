const fs = require("fs");
const axios = require('axios');


module.exports = class {

    constructor(params) {
        params.inject(this);
    }

    getPriceList() {
        const pricePath = `${global.appRoot}../steam-trader/caches/steamapis-prices-RUST.cache`;
        const priceList = JSON.parse(fs.readFileSync(pricePath, 'utf8')).prices;
        return priceList;
    }

    async getItemIcon(itemName) {
        const res = await axios.get(`https://api.steamapis.com/image/item/252490/${itemName}`);
        const resUrl = res.request.res.responseUrl;
        const urlParams = resUrl.split("/");
        const itemIcon = urlParams[urlParams.length - 1];
        return itemIcon;
    }

    async findClosestItem(price, priceList) {
        const itemNames = Object.keys(priceList);
        if (itemNames.length <= 1) throw new Error("Not possible!");
        let closestItem = { name: '', icon: '', price: 0 }
        let closestPriceGap = 99999999;
        for (let i = 0; i < itemNames.length; i++) {
            const itemName = itemNames[i];
            const itemPrice = parseInt(parseFloat(priceList[itemName].price) * 100);
            const priceGap = Math.abs(itemPrice - price);
            if (priceGap < closestPriceGap && itemPrice > 0) {
                closestPriceGap = priceGap;
                closestItem = { name: itemName, price: itemPrice }
            }
            if (closestPriceGap == 0) break;
        }
        closestItem.icon = await this.getItemIcon(closestItem.name);
        return closestItem;
    }

}