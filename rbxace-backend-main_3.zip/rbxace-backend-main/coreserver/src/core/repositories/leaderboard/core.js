const moment = require('moment');
moment.locale('en', {
    week: {
        dow: 1
    }
});

module.exports = class {

    constructor(params) {
        params.inject(this);
        this.defs = {

        }
        this.leaderboard = {
            DAILY: {},
            WEEKLY: {}
            //MONTHLY: {}
        };

        //this.testFunc();
        this.lastUpdateEmit = 0;
    }

    async testFunc() {


    }

    get types() {
        return Object.keys(this.leaderboard);
    }

    getTypeTimeStr(type) {
        switch (type) {
            case "DAILY": return "day";
            case "WEEKLY": return "week";
            case "MONTHLY": return "month";
        }
    }

    getPrizeRunnerFactor(settings, runnerPlace) {
        if (runnerPlace == 1) return 0.5;
        else if (runnerPlace <= settings.runnerFactorFirstNCount) return settings.prizeRunnerFactorFirstN;
        else return settings.prizeRunnerFactorSecondN;
    }

    async generatePrizeItems(settings) {
        let prizeItems = [];

        const priceList = this.repositories.item.getPriceList();

        const prizeCount = settings.runnerCount + 3;
        let lastPrizeAmount = 0;
        for (let prizePlace = 1; prizePlace <= prizeCount; prizePlace++) {
            
            let prizeAmount = 0;
            if (prizePlace <= 3) { 
                const dbColumnName = `prizePlace${prizePlace}`;
                prizeAmount = parseInt(settings[dbColumnName]);
            }
            else {
                const factor = parseFloat(this.getPrizeRunnerFactor(settings, prizePlace - 3));
                //console.log(`Last Prize Amount: ${lastPrizeAmount} -> Factor: ${factor}`)
                prizeAmount = lastPrizeAmount * factor;
            }
            const prizeAmountRounded = Math.ceil(prizeAmount / 100) * 100;
            let item = null;
            while (!item) item = await this.repositories.item.findClosestItem(prizeAmountRounded, priceList).catch(err => { console.log(err); return false; });    
            //console.log(`For place: ${prizePlace}: | Rounded: ${prizeAmountRounded} | ${item.name} ~ $${item.price / 100}`)
            prizeItems.push(item);
            lastPrizeAmount = prizeAmount;
        }
        return prizeItems;
    }
    async createEntry({ type }) {
        const settings = await this.modules.db.select("leaderboard_settings", "type", type);
        const prizeItems = await this.generatePrizeItems(settings);
        const endsAt = moment().utc().endOf(this.getTypeTimeStr(type)).utc().unix()
        const leaderboardId = await this.repositories.leaderboard.db.createEntry({ type, settings, prizeItems, endsAt });
        const leaderboard = await this.repositories.leaderboard.db.getEntry(leaderboardId);
        return leaderboard;
    }

    getTimeRangeStart(type, timeMoment) {
        return timeMoment.startOf(this.getTypeTimeStr(type)).unix();
    }

    getTimeRangeEnd(type, timeMoment) {
        return timeMoment.endOf(this.getTypeTimeStr(type)).unix();
    }

    async refreshUsers(type) {

        let entry = this.leaderboard[type];
        const entryOldTopUsers = JSON.stringify(entry.topUsers);
        const entryCreatedAtMoment = moment(entry.createdAt * 1000).utc();
        const timeRangeStart = this.getTimeRangeStart(type, entryCreatedAtMoment);
        const timeRangeEnd = this.getTimeRangeEnd(type, entryCreatedAtMoment);
        entry.topUsers = (await this.modules.db.query(`SELECT SUM(betAmountWithRisk) as wageredAmount, user_data_common.userId as id, user_data_common.displayName, user_data_common.avatar, user_data_common.exp FROM user_gamehistory INNER JOIN user_data_common ON user_gamehistory.userId = user_data_common.userId WHERE time >= ? AND time < ? GROUP BY user_gamehistory.userId ORDER BY wageredAmount DESC LIMIT ${entry.runnerCount + 3}`, [timeRangeStart, timeRangeEnd]))

        for (let place = 1; place <= entry.topUsers.length;place++) {
            entry.topUsers[place - 1].place = place;
        }
        const entryNewTopUsers = JSON.stringify(entry.topUsers);

        const now = moment().utc().unix();
        const UPDATE_EMIT_INTERVAL = 15;
        this.repositories.redis.publish('workers', 'leaderboard:setTopUsers', { type, entryNewTopUsers: entry.topUsers });
        this.repositories.redis.ioPublishChannel('events:leaderboard', 'leaderboard:setTopUsers', true);
        if (entryOldTopUsers !== entryNewTopUsers && now >= this.lastUpdateEmit + UPDATE_EMIT_INTERVAL) {
            this.lastUpdateEmit = now;
            //this.repositories.redis.ioPublishChannel('events:leaderboard', 'leaderboard:setTopUsers', true);
        }
        //if (entryOldTopUsers !== entryNewTopUsers) this.modules.io.to("events-leaderboards").emit("leaderboards:setTopUsers", { type, topUsers: entry.topUsers });
    }



    pickWinner(joinedUsers) {
        if (joinedUsers.length == 0) return null;
        let randomOffset = this.repositories.random.generateRandomNumber(0, joinedUsers.length - 1);
        const winner = joinedUsers[randomOffset];
        return winner;
    }

    getIndexPlaceName(index) {
        switch (index) {
            case 0: return '1st';
            case 1: return '2nd';
            case 2: return '3rd';
        }
    }

    async awardWinners(entry) {
        let announcementString = `Winners of the ${entry.type.toLowerCase()} leaderboard: `;
        const winners = entry.topUsers;
        for (let i in winners) {
            const winner = winners[i];
            const prize = entry.prizes[i];
            this.modules.logger.log("events-leaderboards-winners", `User Id #${winner.id} won ${entry.type} leaderboard with place ${(i + 1)} and prize ${prize.itemPrice / 100} coins`);
            
            const indexPlaceName = this.getIndexPlaceName(parseInt(i));
            const amount = prize.itemPrice * 10;
            if (i <= 2) announcementString += `${winner.displayName} ${indexPlaceName}, just got ${amount} coins${i < 2 ? ', ' : '.'}`;

            await this.repositories.user.updateBalance({way: 'IN', userId: winner.id, amount, transactionType: 'EVENTS_LEADERBOARDS_WINNINGS' });
            await this.modules.db.exec("INSERT INTO leaderboard_winners SET ?", [{
                leaderboardId: entry.id,
                place: (i + 1),
                winnerId: winner.id,
                amount: prize.itemPrice
            }])
        }
        this.repositories.chat.main.announceSysMessage({message: announcementString});
        //this.externalModules.chat.announceServerMessage(announcementString);
    }
    async finalize({ type }) {
        if (!this.repositories.chat || !this.repositories.user) return;


        let entry = this.leaderboard[type];
        entry.state = 'CLOSING';
        try {
            await this.refreshUsers(type);
            await this.awardWinners(entry);

            const updateSuccess = await this.modules.db.exec("UPDATE leaderboards SET state = 'CLOSED' WHERE id = ?", [entry.id]);
            if (!updateSuccess) {
                this.modules.logger.log("events-leaderboards-errors", `Leaderboard Id #${entry.id} couldn't be updated on database!`);
                //throw new Error("Leaderboard result couldn't be updated on the database!");
            }
            this.leaderboard[type] = await this.createEntry({ type });
            //this.modules.io.to("events-leaderboards").emit("leaderboards:setEntry", { type, entry: this.leaderboard[type] });
            this.repositories.redis.publishAllWithChannel('events-leaderboard', 'leaderboard:setEntry', { type, entry: this.leaderboard[type] });
        } catch (err) {
            this.modules.logger.log("events-leaderboards-core", `Something went wrong on finalizeGiveaway!`)
            this.modules.logger.log("events-leaderboards-core", err.name)
            this.modules.logger.log("events-leaderboards-core", err.stack)
        }
    }
}

