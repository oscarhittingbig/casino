const moment = require('moment');
module.exports = class {

    constructor(params) {
        params.inject(this);
    }

    async createEntry({type, settings, prizeItems, endsAt}) {
        const insertId = await this.modules.db.insert("INSERT INTO leaderboards SET ?", [{
            type,
            runnerCount: settings.runnerCount,
            createdAt: moment().utc().unix(),
            endsAt
        }]);
        if (!insertId || insertId <= 0) throw new Error(`${type} leaderboard couldn't be created!`);
        
        
        for (let prizePlace = 1; prizePlace <= prizeItems.length; prizePlace++) {
            const prizeItem = prizeItems[prizePlace - 1];
            const insertPrizeSuccess = await this.modules.db.exec("INSERT INTO leaderboard_prizes SET ?", [{
                leaderboardId: insertId,
                place: prizePlace,
                itemName: prizeItem.name,
                itemIcon: prizeItem.icon,
                itemPrice: prizeItem.price
            }]);
            if (!insertPrizeSuccess) throw new Error(`Something went wrong while inserting leaderboard prize in ${type}`);
        }

        return insertId;
    }

    async getPreviousWinner(type) {
        const lastClosedEntrySql = (await this.modules.db.query("SELECT id FROM `leaderboards` WHERE type = ? AND state = 'CLOSED' ORDER BY id DESC LIMIT 1", [type]));
        if (lastClosedEntrySql.length == 0) return {};
        const lastClosedEntryId = lastClosedEntrySql[0].id;

        const winnerIdSql = (await this.modules.db.query("SELECT winnerId FROM leaderboard_winners WHERE leaderboardId = ? AND place = 1", [lastClosedEntryId]));
        if (winnerIdSql.length == 0) return {};
        const winnerId = winnerIdSql[0].winnerId;

        const winner = (await this.modules.db.query("SELECT userId as id, displayName, avatar, exp FROM user_data_common WHERE userId = ?", [winnerId]))[0];
        return winner;
    }

    async getEntry(id) {
        let entry = await this.modules.db.select("leaderboards", "id", id);
        if (!entry) throw new Error("Leaderboard couldn't be found!");
        let prizes = await this.modules.db.query("SELECT place, itemName, itemIcon, itemPrice FROM leaderboard_prizes WHERE leaderboardId = ? ORDER BY id ASC", [id])
        entry.prizes = [];
        for (let i in prizes) {
            let prize = prizes[i];
            delete prize.place;
            entry.prizes.push(prize);
        }

        entry.previousWinner = await this.getPreviousWinner(entry.type);
  
        return entry;
    }

    async getActiveEntry(type) {
        const activeSql = await this.modules.db.query("SELECT id FROM leaderboards WHERE type = ? AND state = 'OPEN' ORDER BY id DESC LIMIT 1", [type]);
        if (activeSql.length == 0) return {};
        return await this.getEntry(activeSql[0].id);
    }

    
}

