const moment = require('moment');
moment.locale('en', {
week: {
       dow: 1 // Monday is the first day of the week.
    }
});

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.defs = {
            THREAD: {
                INTERVAL: 1000
            }
        }
        this.inited = false;
        
        //this.replayThread();
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }
    async mainThread() {
        try {
            await this.initIfNot();
            await this.iterate();
        } catch(err) {
            this.modules.logger.log("events-leaderboard-worker", err.name);
            this.modules.logger.log("events-leaderboard-worker", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async initIfNot() {
        if (this.inited) return;
        this.inited = true;
        for (let i in this.repositories.leaderboard.core.types) {
            const type = this.repositories.leaderboard.core.types[i];
            this.repositories.leaderboard.core.leaderboard[type] = await this.repositories.leaderboard.db.getActiveEntry(type);
        }
    }

    async iterate() {
        for (let i in this.repositories.leaderboard.core.types) {
            const type = this.repositories.leaderboard.core.types[i];
            await this.check(type);
        }
    }

    async refreshUsers(type, now) {
        const REFRESH_INTERVAL = 1 * 15; //minutes
        let entry = this.repositories.leaderboard.core.leaderboard[type];
        if (!entry.hasOwnProperty("lastRefreshTime") || now > (entry.lastRefreshTime + REFRESH_INTERVAL)) {
            await this.repositories.leaderboard.core.refreshUsers(type); 
            entry.lastRefreshTime = now;
        } 
    }

    async check(type) {
        let entry = this.repositories.leaderboard.core.leaderboard[type];
        if (!entry.hasOwnProperty("createdAt")) {
            this.repositories.leaderboard.core.leaderboard[type] = await this.repositories.leaderboard.core.createEntry({type});
            return;
        }

        const now = moment().utc().unix();
        if (now < entry.endsAt) return await this.refreshUsers(type, now);
        if (entry.state !== 'OPEN') return;
        await this.repositories.leaderboard.core.finalize({type});
    }
}

