const moment = require('moment');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }


  async on_bet({ userId, amount }) {
    //await this.repositories.affiliates.handleAffiliateWagerEarning(userId, amount);
    //await this.repositories.rain.core.handleBet(amount);
  }

  async on_finalizeBet({ game, userId, betAmount, won, riskPayoutRate }) {
    let realRiskRate = riskPayoutRate >= 2 ? 1 : (riskPayoutRate - 1);
    const betAmountWithRisk = Math.floor(betAmount * realRiskRate);
    if (betAmountWithRisk > 0) {
      await this.repositories.affiliates.handleAffiliateWagerEarning(userId, betAmountWithRisk);
      await this.repositories.rain.core.handleBet(betAmountWithRisk);
      await this.repositories.level.increaseExp(userId, betAmountWithRisk);
    }

    //affiliates
    //level system
    //leaderboard -> user_gamehisotry check
  }

}