module.exports = class {


    constructor(params) {
        params.inject(this);
    }

    validateUserId(userId) {
        if (isNaN(userId) || userId == undefined || userId == null || userId <= 0 || userId > 10000000) throw new Error('Geçersiz şeyler!');
    }
    validateAmount(amount) {
        if (isNaN(amount) || amount == undefined || amount == null || amount < 0 || amount > 10000000) throw new Error('Geçersiz şeyler!');
    }

    clearHTML(str) {
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }


    /* Cooldown */
    checkMemCooldown(key, value, timeInSeconds) {
        let cd = this.modules.cache.getCooldown(
            `${key}|${value}`,
            timeInSeconds
        );

        if (cd > 0)  throw new Error(`Calm down ${(cd)}s!`)
    }

    async checkRedisCooldown(key, value, errMsg) {
        let redisKey = `${key}|${value}`;
        let exists = (await this.modules.redis.get(redisKey)) !== null; //  //this.modules.cache.memGet(ipKey);
        if (exists) { //undefined
            throw new Error(errMsg);
        }
    }
}

