
const moment = require('moment');
moment.locale('en', {
    week: {
        dow: 1
    }
});

module.exports = class {

    constructor(params) {
        params.inject(this);
        this.defs = {
            WAGER_FEES: 0.01, //1%
            STARTING_PRIZE: 3 * 1000,
            INTERVALS: {
                STARTED: 28 * 60 * 1000,
                ENDING: 2 * 60 * 1000,
                ENDED: 0 * 1000
            }
        }

        this.pot = {};
        this.oldPotData = {}
    }

    get wrapper() {
        return this.repositories.rain;
    }
    async init() {
        const activePotId = await this.wrapper.db.getActiveEntry();
        if (activePotId)
        this.pot = await this.wrapper.db.getEntry(activePotId);
        else {
            await this.createNewPot();
        }
        this.oldPotData = JSON.parse(JSON.stringify(this.pot));
        setInterval(() => { this.syncPotVariables(); }, 2 * 1000);
    }

    async handleBet(betAmount) {
        const goesToPot = Math.floor(betAmount * this.defs.WAGER_FEES)
        if (goesToPot <= 0) return;
        this.increasePotPrize(goesToPot);
    }

    async increasePotPrize(amount) {
        this.pot.prize += amount;
        await this.wrapper.db.increasePotPrize({potId: this.pot.id, amount});
    }

    async createNewPot() {
        const newPotId = await this.wrapper.db.createEntry({startingPrize: this.defs.STARTING_PRIZE});
        this.pot = await this.wrapper.db.getEntry(newPotId);

        this.repositories.redis.publishAll('events:rain:setPot', { newPot: this.pot });
    }

    async setState(newState) {
        await this.wrapper.db.setState({potId: this.pot.id, newState});
        this.pot.state = newState;
        this.pot.lastUpdateMs = Date.now();

        this.repositories.redis.publishAll('events:rain:setState', { newState, lastUpdateMs: this.pot.lastUpdateMs });
    }

    async awardParticipants() {
        const participants = await this.modules.db.query("SELECT events_rain_pot_players.userId, user_data_common.exp FROM events_rain_pot_players INNER JOIN user_data_common ON user_data_common.userId = events_rain_pot_players.userId WHERE potId = ? ORDER BY id ASC", [this.pot.id]);
        participants.forEach(  (participant) => { participant.level = this.repositories.level.getLevelByExp(participant.exp); });
        const levelIndex = participants.reduce((sum, el) => { sum += el.level; return sum;}, 0);
        const totalPrize = this.pot.prize;
        participants.map( async (participant) => { 
            const classicPrize = Math.floor( (totalPrize * 0.5) *  (1 / participants.length) );
            const levelPrize = Math.floor( (totalPrize * 0.5) * (participant.level / levelIndex) );

            let totalParticipantPrize = classicPrize + levelPrize;
            if (totalParticipantPrize > 5000) totalParticipantPrize = 5000;

            await this.repositories.user.updateBalance({way: 'IN', userId: participant.userId, amount: totalParticipantPrize, transactionType: 'EVENTS_RAIN_WINNINGS' });
            this.repositories.chat.main.sendSysMessageToUser(participant.userId, `You received ${totalParticipantPrize} coins from rain!`);
        });

        this.repositories.chat.main.announceSysMessage({message: `Rain has been completed! ${participants.length} players joined and ${totalPrize} coins has been awarded in total`});
    }

    async syncPotVariables() {
        if (this.pot.state == 'ENDING') this.pot.joinedPlayersCount = (await this.modules.db.query("SELECT COUNT(1) as count FROM events_rain_pot_players WHERE potId = ?", [this.pot.id]))[0].count;
        if (this.oldPotData.prize == this.pot.prize && this.oldPotData.joinedPlayersCount == this.pot.joinedPlayersCount) return;
        this.repositories.redis.publishAll('events:rain:updatePotVariables', { newPrize: this.pot.prize, newJoinedPlayersCount: this.pot.joinedPlayersCount });
        this.oldPotData = JSON.parse(JSON.stringify(this.pot));
    }

}

