const moment = require('moment');
module.exports = class {

    constructor(params) {
        params.inject(this);
    }

    async createEntry({startingPrize}) {
        const now = moment().utc().unix();
        const insertId = await this.modules.db.insert("INSERT INTO events_rain_pots SET ?", [{
            prize: startingPrize,
            createdAt: now,
            lastUpdateMs: (now * 1000)
        }]);
        if (!insertId || insertId <= 0) throw new Error(`Rain couldn't be created!`);
        
        return insertId;
    }

    async getEntry(id) {
        let entry = await this.modules.db.select("events_rain_pots", "id", id);
        if (!entry) throw new Error("Entry couldn't be found!");

        return {
            ...entry,
            joinedPlayersCount: 0
        }
    }

    async getActiveEntry() {
        const activeSql = await this.modules.db.query("SELECT id FROM events_rain_pots WHERE state != 'ENDED' ORDER BY id DESC LIMIT 1");
        if (activeSql.length == 0) return null;
        return activeSql[0].id;
    }

    async setState({potId, newState}) {
        const updateSuccess = await this.modules.db.exec("UPDATE events_rain_pots SET state = ?, lastUpdateMs = ? WHERE id = ?", [newState, Date.now(), potId]);
    }

    async increasePotPrize({potId, amount}) {
        const updateSuccess = await this.modules.db.exec("UPDATE events_rain_pots SET prize = prize + ? WHERE id = ?", [amount, potId]);
    }

    
}

