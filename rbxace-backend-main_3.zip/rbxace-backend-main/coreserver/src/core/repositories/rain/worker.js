const moment = require('moment');
const sleep = require('await-sleep');

moment.locale('en', {
week: {
       dow: 1 // Monday is the first day of the week.
    }
});

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.defs = {
            THREAD: {
                INTERVAL: 1000
            }
        }
        this.inited = false;
        this.replayThread();
    }

    get wrapper() {
        return this.repositories.rain;
    }

    get remainingTime() {
        const now = Date.now();
        const elapsed = now - this.wrapper.core.pot.lastUpdateMs;
        return (this.wrapper.core.defs.INTERVALS[this.wrapper.core.pot.state] || 0) - elapsed;
      }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }
    async mainThread() {
        try {
            const phase = this.wrapper.core.pot.state;

            switch (phase) {
                case 'STARTED': await this.handleStartedPhase(); break;
                case 'ENDING': await this.handleEndingPhase(); break;
                case 'ENDED': await this.handleEndedPhase(); break;
            }

        } catch(err) {
            this.modules.logger.log("events-rain-worker", err.name);
            this.modules.logger.log("events-rain-worker", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async handleStartedPhase() {
        if (this.remainingTime > 0) return;
        await this.wrapper.core.setState('ENDING');
    }

    async handleEndingPhase() {
        if (this.remainingTime > 0) return;
        await this.wrapper.core.setState('ENDED');
    }

    async handleEndedPhase() {
        if (this.remainingTime > 0) return;
        await this.wrapper.core.awardParticipants();
        await sleep(5 * 1000);
        await this.wrapper.core.createNewPot();


    }

}

