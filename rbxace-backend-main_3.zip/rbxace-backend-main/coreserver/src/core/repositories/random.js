const RandomOrg = require('random-org');
const service = new RandomOrg({ apiKey: process.env.RANDOMORG_API_KEY });

module.exports = class {

    constructor(params) {
        params.inject(this);

       // this.testFunc();
    }

    async testFunc() {
        const res = await this.generateServiceString();
        console.log(res);
    }

    generateRandomString(length) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    }

    getRandomInteger(random, min, max) {
        return Math.floor(random * (max + 1 - min)) + min;
    }

    async generateServiceString() {

        let result = await service.generateSignedStrings({ n: 1, length: 32, characters: 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789' }).catch(err => { return false; });
        if (!result) return false;
        
        const string = result.random.data[0];
        const signature = result.signature;
        const jsonObj = JSON.stringify(result.random);

        const base64 = Buffer.from(jsonObj).toString('base64');
        const verificationLink = `https://api.random.org/signatures/form?format=json&random=${encodeURIComponent(base64)}&signature=${encodeURIComponent(signature)}`;
    
        return { string, verificationLink };
    }

}

