const redis = require("redis");
const client = redis.createClient();
const publisher = redis.createClient();
const subscriber = redis.createClient();

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async get(key) {
    return await new Promise(function (resolve, reject) {
      client.get(key, function (err, reply) {
        if (err) {
          reject(err);
        } else {
          resolve(reply);
        }
      });

    });
  }

  set(key, expire, val) {
    client.setex(key, expire, val);
  }


  listen() {
    subscriber.on("message", (channel, messageJson) => {

      let message = JSON.parse(messageJson);
      if (message.sender !== process.pid) {
        if (channel == 'head') {
          this.handle_headPackets(channel, message.header, message.content, message.workerChannel);
        } else if (channel.startsWith('worker')) {
          this.handle_workerPackets(channel, message.header, message.content);
        }
      }
    });

    subscriber.on("subscribe", (channel, count) => {
      if (channel == 'head') {
        this.requestInitializationFromWorkers();
      }
    });

    let numWorkers = 8;
    for (let i = 1; i <= numWorkers; i++) {
      subscriber.subscribe(`worker-${i}`);
    }
    subscriber.subscribe("head");
  }



  requestInitializationFromWorkers() {
    const loginData = {
      pid: process.pid
    };
    this.publish('workers', 'requestInitialization', loginData);
    //console.log('Initialization requested from web workers!');
  }

  handle_headPackets(channel, header, content, workerChannel) {
    //console.log(channel, header, content, workerChannel)
   
    switch (header) {
      case "initialization":
        //console.log(workerChannel, 'worker is asking init packet')
        this.publish(workerChannel, 'initialization', { 
          chat: { 
            defs: this.repositories.chat.main.defs, 
            messages: this.repositories.chat.main.messages,
            online: this.repositories.chat.main.online
          }, 
          roulette: {
            defs: this.repositories.roulette.game.defs,
            round: this.repositories.roulette.game.publicRoundData,
            history: this.repositories.roulette.game.history.slice(-10),
            counts: this.repositories.roulette.game.counts
          },
          crash: {
            defs: this.repositories.crash.game.defs,
            round: this.repositories.crash.game.publicRoundData,
            history: this.repositories.crash.game.history
          },
          blackjack: {
            defs: {
              INTERVALS: this.repositories.blackjack.game.defs.INTERVALS
            },
            tables: this.repositories.blackjack.game.publicTablesData
          },
          coinflip: {
            defs: {
              INTERVALS: this.repositories.coinflip.game.defs.INTERVALS
            },
            rooms: this.repositories.coinflip.game.publicRoomsData,
            history: this.repositories.coinflip.game.history,
            stats: this.repositories.coinflip.game.stats
          },
          upgrader: {
            defs: this.repositories.upgrader.game.defs,
            history: this.repositories.upgrader.game.history,
          },
          rain: {
            defs: {
              INTERVALS: this.repositories.rain.core.defs.INTERVALS
            },
            pot: this.repositories.rain.core.pot
          },
          leaderboard: this.repositories.leaderboard.core.leaderboard,
          workerChannel });

        break;

      case "chat:sendMessage":
        this.repositories.chat.redis.on_sendMessage(content);
        break;

      case "roulette:bet":
        this.repositories.roulette.redis.on_bet(content);
      break;

      case "crash:bet":
        this.repositories.crash.redis.on_bet(content);
      break;

      case "crash:cashout":
        this.repositories.crash.redis.on_cashout(content);
      break;



      case "blackjack:player:sit":
        this.repositories.blackjack.redis.on_player_sit(content);
      break;

      case "blackjack:player:leave":
        this.repositories.blackjack.redis.on_player_leave(content);
      break;


      case "blackjack:player:placeBet":
        this.repositories.blackjack.redis.on_player_placeBet(content);
      break;

      case "blackjack:player:setInsuranceStatus":
        this.repositories.blackjack.redis.on_player_setInsuranceStatus(content);
      break;



      case "blackjack:player:setDecision":
        this.repositories.blackjack.redis.on_player_setDecision(content);
      break;

      case "blackjack:player:stand":
        this.repositories.blackjack.redis.on_player_stand(content);
      break;
      
      case "blackjack:player:hit":
        this.repositories.blackjack.redis.on_player_hit(content);
      break;

      case "blackjack:player:doubleDown":
        this.repositories.blackjack.redis.on_player_doubleDown(content);
      break;

      case "blackjack:player:splitHand":
        this.repositories.blackjack.redis.on_player_splitHand(content);
      break;

      case "blackjack:player:commandBet":
        this.repositories.blackjack.redis.on_player_commandBet(content);
      break;

      case "upgrader:play":
        this.repositories.upgrader.redis.on_play(content);
      break;




        case "publishToOtherWorkers":
          this.publish('workers', content.header, content.data);
        break;

    }
  }

  handle_workerPackets(channel, header, content) {

  }

  publish(channel, header, obj) {
    let message = { header: header, content: obj, sender: process.pid };
    let messageJson = JSON.stringify(message);
    publisher.publish(channel, messageJson);
  }

  ioPublish(type, data) {
    this.modules.io.to("global").emit(type, data);
  }

  ioPublishChannel(channel, type, data) {
    this.modules.io.to(channel).emit(type, data);
  }

  ioPublishToUser(userId, type, data) {
    this.modules.io.to("user-" + userId).emit(type, data);
  }

  publishAll(type, data) {
    this.publish('workers', type, data);
    this.ioPublish(type, data);
  }

  publishAllWithChannel(channel, type, data) {
    this.publish('workers', type, data);
    this.ioPublish(channel, type, data);
  }

  ioSetUserSocketProperty(userId, property, value) {
    this.publish("workers", "user:setSocketProperty", { 
      userId,
      property, 
      value
    });
  }

}