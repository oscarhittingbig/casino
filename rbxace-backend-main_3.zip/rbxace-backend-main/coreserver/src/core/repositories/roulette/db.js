const moment = require('moment');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async createNewRound() {
    const { serverSecret, randomOrgSecret, verificationLink, seed, random, roll, hash, wobble} = await this.repositories.roulette.fairness.generateRoundVariables();
    const roundId = await this.modules.db.insert("INSERT INTO game_roulette_rounds SET ?", [{
          serverSecret,
          randomOrgSecret,
          verificationLink,
          seed,
          random,
          roll,
          hash,
          wobble,
          createdAt: moment().utc().unix()
      }]);
      return roundId;
  }

  async getRoundData(roundId) {
    const roundData = await this.modules.db.select("game_roulette_rounds", "id", roundId);
    roundData.bets = {
      'RED': {},
      'GOLD': {},
      'BLACK': {}
    };
    const bets = await this.modules.db.query("SELECT game_roulette_round_bets.*, users.*, user_data_common.displayName, user_data_common.avatar, user_data_common.balance, user_data_common.isBanned, user_data_common.exp, user_data_settings.tradeUrl, user_data_settings.volume, user_data_settings.isAnon, user_data_settings.isPrivate FROM game_roulette_round_bets INNER JOIN users ON users.id = game_roulette_round_bets.userId INNER JOIN user_data_common ON user_data_common.userId = users.id INNER JOIN user_data_settings ON user_data_settings.userId = users.id WHERE roundId = ? GROUP BY game_roulette_round_bets.userId, game_roulette_round_bets.color", [roundId]);
    bets.forEach(bet => {
      const user = this.repositories.user.modifyUserData(bet);
      const userProfile = this.repositories.user.getUserProfile(user);
      roundData.bets[bet.color][user.id] = {
        betAmount: bet.amount,
        color: bet.color,
        user: userProfile
      };
    });
    roundData.state = 'PREPARATION';
    roundData.startedAt = Date.now();
    roundData.finalized = false;
    return roundData;
  }

  async updateRoundState({state, roundId, closedAt}) {
    const updateSuccess = await this.modules.db.exec("UPDATE game_roulette_rounds SET state = ?, closedAt = ? WHERE id = ?", [state, closedAt || 0, roundId])
    if (!updateSuccess) throw new Error("Round state couldn't be updated!");
  }

  async getLastRound() {
    const lastRoundIdSql = await this.modules.db.query("SELECT id FROM game_roulette_rounds WHERE state != 'CLOSED' ORDER BY createdAt DESC LIMIT 1");
    if (lastRoundIdSql.length > 0) {
      const lastRoundId = lastRoundIdSql[0].id;
      return await this.getRoundData(lastRoundId);
    } else {
      const newRoundId = await this.createNewRound();
      return await this.getRoundData(newRoundId);
    }
  }


}