const crypto = require("crypto");
const Chance = require('chance');

module.exports = class {

    constructor(params) {
        params.inject(this);

    }

    async generateRoundVariables() {
        const serverSecret = this.repositories.random.generateRandomString(32);
        let randomOrgSecret = '', verificationLink = '';
        
        const randomOrgVariables = await this.repositories.random.generateServiceString();
        if (randomOrgVariables) {
            randomOrgSecret = randomOrgVariables.string;
            verificationLink = randomOrgVariables.verificationLink;
        }

        const seed = `${serverSecret}:${randomOrgSecret}`;
        const random = new Chance(seed).random();
        const roll = this.repositories.random.getRandomInteger(random, 0, 14);
        const hash = crypto.createHash("sha512").update(seed).digest("hex");
        return {
            serverSecret,
            randomOrgSecret,
            verificationLink,
            seed,
            random,
            roll,
            hash,
            wobble: Math.random()
        }
    }


}
