const sleep = require('await-sleep');
const moment = require('moment');

module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      PREPARATION_INTERVAL: 15 * 1000,
      TIMER_BALANCER: 0
    }

    this.round = {

    };
    this.history = [];
    this.counts = {
      'RED': 0,
      'GOLD': 0,
      'BLACK': 0
    };

    this.aliveBettingTasks = 0;
  }

  get wrapper() {
    return this.repositories.roulette;
  }

  get publicRoundData() {
    let clonedRoundData = JSON.parse(JSON.stringify(this.round));
    delete clonedRoundData.serverSecret;
    delete clonedRoundData.randomOrgSecret;
    delete clonedRoundData.seed;
    delete clonedRoundData.random;
    delete clonedRoundData.roll;
    delete clonedRoundData.verificationLink;
    return clonedRoundData;
  }

  get winningColor() {
    return this.rollToColor(this.round.roll);
  }


  async init() {
    const cache = this.modules.cache.fileGet('roulette');
    if (!Array.isArray(cache)) {
      this.history = cache.history;
      this.counts = cache.counts;
    }
    this.round = await this.repositories.roulette.db.getLastRound();
    this.repositories.roulette.thread.replayThread();
  }

  saveCache() {
    this.modules.cache.fileSet('roulette', {
      history: this.history,
      counts: this.counts
    });
  }

  async startRoll() {
    this.round.state = 'ROLLING';
    
    while (this.aliveBettingTasks > 0) await sleep(10);

    await this.wrapper.db.updateRoundState({ state: 'ROLLING', roundId: this.round.id, closedAt: 0 })

    const rollData = {
      state: this.round.state,
      roll: this.round.roll,
      wobble: this.round.wobble
    };

    this.repositories.redis.publish('workers', 'roulette:startRoll', rollData);
    this.repositories.redis.ioPublishChannel('game:roulette', 'roulette:startRoll', rollData);
  }

  rollToColor(roll) {
    if (roll >= 1 && roll <= 7) return 'RED';
    else if (roll >= 8 && roll <= 14) return 'BLACK';
    else return 'GOLD';
  }

  async finalizeBets() {
    
    const colors = Object.keys(this.round.bets);
    colors.forEach( async (color) => {
      const userIds = Object.keys(this.round.bets[color]);
      userIds.forEach(async (userId) =>{
        const bet = this.round.bets[color][userId];
        const won = this.winningColor == color;
        const colorMultiplier = color == 'GOLD' ? 14 : 2;
        const riskPayoutRate = colorMultiplier;

        let winnings = 0;
        if (won) {
          winnings = Math.floor(bet.amount * colorMultiplier);
          await this.repositories.user.updateBalance({ way: 'IN', userId, amount: winnings, transactionType: 'BET_ROULETTE_WINNINGS' });
          this.repositories.user.notify(userId, 'success', 'SOCKET_GAME_WON', [winnings, 'Roulette']);
          //this.repositories.user.notify(userId, 'success', 'SOCKET_ROULETE_WON', [winnings, color]);
        }
        await this.repositories.user.finalizeBet({ userId, game: 'ROULETTE', roundId: this.round.id, betAmount: bet.amount, betTo: color.toUpperCase(), won, betWinner: this.winningColor.toUpperCase(), multiplier: colorMultiplier, winnings, riskPayoutRate });
        await this.modules.db.exec("UPDATE game_roulette_round_bets SET status = 'PROCESSED' WHERE roundId = ? AND userId = ? AND color = ?", [this.round.id, userId, color.toUpperCase()]);
        this.repositories.middlewares.betting.on_finalizeBet({game: 'ROULETTE', userId, betAmount: bet.amount, won, riskPayoutRate})
      
      })
    });
  }

  pushHistory() {
    const lastRound = JSON.parse(JSON.stringify(this.publicRoundData));
    lastRound.roll = this.round.roll;
    delete lastRound.bets;

    let history = this.history;
    history.unshift(lastRound);
    if (history.length > 100) {
      this.history = history.slice(0, 100);
    }
    return lastRound;
  }

  pushCount() {
    const newCounts = {
      'RED': 0,
      'GOLD': 0,
      'BLACK': 0
    };
    this.history.forEach(entry => {
      const color = this.rollToColor(entry.roll);
      newCounts[color]++;
    });
    this.counts = newCounts;
  }

  async pushNewRound(lastRound) {
    const newRoundId = await this.wrapper.db.createNewRound();
    this.round = await this.wrapper.db.getRoundData(newRoundId);
    this.round.startedAt -= 50; //correction needed for ping

    const packetData = {
      lastRound: lastRound,
      newRound: this.publicRoundData,
      newCounts: this.counts
    };
    this.repositories.redis.publish('workers', 'roulette:pushRound', packetData);
    this.repositories.redis.ioPublishChannel('game:roulette', 'roulette:pushRound', packetData);
  }

  async finalizeRound() {
    const lastRound = this.pushHistory();
    this.pushCount();
    this.saveCache();
    await this.wrapper.db.updateRoundState({ state: 'CLOSED', roundId: lastRound.id, closedAt: moment().utc().unix() })
    await this.pushNewRound(lastRound);
  }


}