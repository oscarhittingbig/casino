const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  get wrapper() {
    return this.repositories.roulette;
  }


  async on_bet(data) {
    const { user, betAmount, color } = data;
    let inBettingTask = false;
    try {
      if (betAmount < global.settings.minBet) return this.repositories.user.notify(user.id, 'error', 'SOCKET_COMMON_MINBET', [betAmount]);

      inBettingTask = true; 
      this.wrapper.game.aliveBettingTasks++;

      if (this.wrapper.game.round.state !== 'PREPARATION') return; // throw new Error("SOCKET_ROULETTE_ROUNDCLOSED")
      
      let bets = this.wrapper.game.round.bets;
      const oppositeColor = color == 'RED' ? 'BLACK' : 'RED';
      if ( (color == 'RED' || color == 'BLACK') && bets[oppositeColor][user.id]) throw new Error("SOCKET_ROULETT_CANTBETONBOTHSIDES")


      await this.repositories.user.updateBalance({ way: 'OUT', userId: user.id, amount: betAmount, transactionType: 'BET_ROULETTE', alterType: 'BET', alterName: 'ROULETTE' });
      const betData = {
        color,
        bet: {
          amount: betAmount,
          user
        }
      };

      if (!bets[color][user.id])
        bets[color][user.id] = betData.bet;
      else
        bets[color][user.id].amount += betAmount;

      this.repositories.redis.publish('workers', 'roulette:pushBet', betData);
      this.repositories.redis.ioPublishChannel('game:roulette', 'roulette:pushBet', betData);

      //this.repositories.user.notify(user.id, 'success', 'SOCKET_ROULETE_BETSUCCESS', [betAmount, color]);

    } catch (err) {
      this.repositories.user.notify(user.id, 'error', err.message)
    } finally {
      if (inBettingTask) this.wrapper.game.aliveBettingTasks--;
    }
  }

}