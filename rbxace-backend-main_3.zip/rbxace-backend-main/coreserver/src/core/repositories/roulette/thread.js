
module.exports = class {

  constructor(params) {
    params.inject(this);

  }

  get defs() {
    return this.repositories.roulette.game.defs;
  }

  get round() {
    return this.repositories.roulette.game.round;
  }

  get wrapper() {
    return this.repositories.roulette;
  }


  get remainingTime() {
    const now = Date.now();
    const elapsed = now - this.round.startedAt;

    return this.defs.PREPARATION_INTERVAL - elapsed;
  }

  replayThread() {
    setTimeout(this.mainThread.bind(this), 25);
  }


  async mainThread() {

    try {
      if (this.remainingTime > 0 || this.round.state != 'PREPARATION') return;

      await this.wrapper.game.startRoll();

      setTimeout(async () => {
        await this.wrapper.game.finalizeBets();

        setTimeout(async () => {
          await this.wrapper.game.finalizeRound();
          //push history et.
          //init new round
        }, 2500)

      }, 7500);


    } finally {
      this.replayThread();
    }
  }


}