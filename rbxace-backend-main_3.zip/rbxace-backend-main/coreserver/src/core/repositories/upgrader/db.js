const moment = require('moment');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async getSeedData(userId) {
    const seedData = (await this.modules.db.query("SELECT upgraderClientSeed, upgraderServerSeed FROM user_data_games WHERE userId = ?", [userId]))[0];
    return {
      clientSeed: seedData.upgraderClientSeed,
      serverSeed: seedData.upgraderServerSeed
    }
  }

  async playerHasActiveItem(userId) {
    return (await this.modules.db.query("SELECT COUNT(1) as count FROM game_upgrader_user_inventory WHERE userId = ? AND state = 'ACTIVE'", [userId]))[0].count > 0;
  }

  async generateServerSeed(userId) {
    const serverSeed = this.repositories.random.generateRandomString(64);
    const updated = await this.modules.db.exec("UPDATE user_data_games SET upgraderServerSeed = ? WHERE userId = ?", [serverSeed, userId]);
    if (!updated) throw new Error("Server seed couldn't be updated!");

    return serverSeed;
}

  async insertRound({ user, seedData, roundData, rollType, inputBetAmount, outputBetAmount }) {
    const roundId = await this.modules.db.insert("INSERT INTO game_upgrader_rounds SET ?", [{
      userId: user.id,
      houseEdge: roundData.houseEdge,
      clientSeed: seedData.clientSeed,
      serverSeed: seedData.serverSeed,
      randomOrgSecret: roundData.randomOrgSecret,
      verificationLink: roundData.verificationLink,
      seed: roundData.seed,
      ticket: roundData.ticket,

      rollType,
      inputBetAmount,
      outputBetAmount,
      multiplier: roundData.multiplier,
      chance: roundData.chance,
      won: roundData.won,

      time: moment().utc().unix()
    }]);
    return roundId;
  }

  async insertRoundItem({ roundId, type, item }) {
    const itemData = {
      roundId,
      type,
      app: item.app,
      market_hash_name: item.market_hash_name,
      image: item.image,
      price: item.price
    };
    const insertSucces = await this.modules.db.exec("INSERT INTO game_upgrader_round_items SET ?", [itemData])
    if (!insertSucces) {
      this.modules.logger.log("gamemodes-upgrader-errors", `Round Item couldn't be inserted!`);
      this.modules.logger.log("gamemodes-upgrader-errors", itemData);
    }
  }
  async insertRoundItems({ roundId, outputItems }) {
    /* DEPRECATED */
    /*
    for (let i in inputItems) {
      const inputItem = inputItems[i];
      await this.insertRoundItem({ roundId, type: 'INPUT', item: inputItem });
    }
    */

    for (let i in outputItems) {
      const outputItem = outputItems[i];
      await this.insertRoundItem({ roundId, type: 'OUTPUT', item: outputItem });
    }
  }

  async insertNewItemsToUserInventory({userId, items}) {
    let newItems = [];
    for (let i in items) {
      const item = items[i];
      const newItemId = await this.modules.db.insert("INSERT INTO game_upgrader_user_inventory SET ?", [{
        userId,
        app: item.app,
        market_hash_name: item.market_hash_name,
        image: item.image,
        price: item.price,
        createdAt: moment().utc().unix()
      }]);
      if (!newItemId) {
        this.modules.logger.log("gamemodes-upgrader-errors", `Item couldn't be inserted to user ${userId} -- ${JSON.stringify(item)}`);
      } else {
        item.id = newItemId;
        newItems.push(item);
      }
    }
    return newItems;
  }


}