const crypto = require("crypto");
const Chance = require("chance");

module.exports = class {

    constructor(params) {
        params.inject(this);

   
    }



    async generateRoundVariables({seedData, rollType, inputBetAmount, outputBetAmount}) {

      let randomOrgSecret = '', verificationLink = '';
      const randomOrgVariables = await this.repositories.random.generateServiceString();
      if (randomOrgVariables) {
          randomOrgSecret = randomOrgVariables.string;
          verificationLink = randomOrgVariables.verificationLink;
      }

      const seed = `${seedData.clientSeed}:${seedData.serverSeed}:${randomOrgSecret}`;
      const ticket = new Chance(seed).floating({min: 0, max: 1, fixed: 15});

      const multiplier = Math.ceil(outputBetAmount / inputBetAmount * 100) / 100;
      const chance = 1 / multiplier;
      const chanceWithHouseEdge = parseFloat((chance * (1 - this.repositories.upgrader.game.defs.HOUSE_EDGE)).toFixed(4));

      let won = false;
      if ( (rollType == 'UNDER' && ticket < chanceWithHouseEdge)
        || (rollType == 'OVER' && ticket >= (1 - chanceWithHouseEdge))) 
        won = true;
      
      const resultRegion = won ? 
      (rollType == 'UNDER' ? `< ${chanceWithHouseEdge.toFixed(4)}` : `>= ${(1 - chanceWithHouseEdge.toFixed(4))}`)
       : (rollType == 'UNDER' ? `>= ${chanceWithHouseEdge.toFixed(4)}` : `< ${(1 - chanceWithHouseEdge.toFixed(4))}`)

      return {
        seed,
        rollType,
        ticket,
        randomOrgSecret,
        verificationLink,
        multiplier,
        chance,
        chanceWithHouseEdge,
        resultRegion,
        won,
        houseEdge: this.repositories.upgrader.game.defs.HOUSE_EDGE
      }
    }


}
