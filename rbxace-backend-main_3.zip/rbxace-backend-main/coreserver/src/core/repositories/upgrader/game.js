const moment = require('moment');
const { v1: uuidv1 } = require('uuid');
const Mutex = require('async-mutex').Mutex;

module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      HOUSE_EDGE: 0.1
    }
    this.history = this.modules.cache.fileGet('upgrader-history')
    this.mutexes = {};
  }

  get wrapper() {
    return this.repositories.upgrader;
  }

  getUserMutex(userId) {
    if (this.mutexes.hasOwnProperty(userId)) return this.mutexes[userId];
    else {
      this.mutexes[userId] = new Mutex();
      return this.mutexes[userId];
    }
  }

  saveHistory() {
    this.modules.cache.fileSet('upgrader-history', this.history);
  }

 pushHistory(history) {
    this.history.unshift(history);
    if (this.history.length > 15) {
      this.history = this.history.slice(0, 15);
    }

    this.saveHistory();

    const packetName = 'upgrader:pushHistory';
    const packetData = { history };
    this.repositories.redis.publish('workers', packetName, packetData);
    this.repositories.redis.ioPublishChannel('game:upgrader', packetName, packetData);

    
  }


  async play({user, rollType, fastAnimation, inputBetAmount, outputItems, outputBetAmount }) {

    const release = await this.getUserMutex(user.id).acquire();
    try {
      const seedData = await this.wrapper.db.getSeedData(user.id);
      if (!seedData.serverSeed) throw new Error("Seed is null!");

      const userHasItem = await this.wrapper.db.playerHasActiveItem(user.id);
      if (userHasItem) throw new Error("SOCKET_UPGRADER_HAVEACTIVEITEM");

      await this.repositories.user.updateBalance({ way: 'OUT', userId: user.id, amount: inputBetAmount, transactionType: 'BET_UPGRADER', alterType: 'BET', alterName: 'UPGRADER' });

      /* Deprecated */
      /*
      const inventoryItemIds = inputItems.join(',');
      const updateItemStatesSql = await this.modules.db.call("upgrader_setItemStates(?,?)", [inventoryItemIds, 'PLAYED']);
      if (!updateItemStatesSql.success) throw new Error("SOCKET_UPGRADER_PLAY_INPUTITEMSNOTAVAILABLE");
      */

      const newServerSeed = await this.wrapper.db.generateServerSeed(user.id);
      const roundData = await this.wrapper.fairness.generateRoundVariables({ seedData, rollType, inputBetAmount,outputBetAmount });

      const roundId = await this.wrapper.db.insertRound({ user, seedData, roundData, rollType, inputBetAmount, outputBetAmount});
      await this.wrapper.db.insertRoundItems({ roundId, outputItems })

      
      let newItems = [];
      if (roundData.won) {
        newItems = await this.wrapper.db.insertNewItemsToUserInventory({ userId: user.id, items: outputItems })
      }
      //finalize bet maybe, game history
      const winnings = roundData.won ? outputBetAmount : 0;
      await this.repositories.user.finalizeBet({ userId: user.id, game: 'UPGRADER', roundId, betAmount: inputBetAmount, betTo: '', won: roundData.won, betWinner: roundData.resultRegion, multiplier: roundData.multiplier, winnings, riskPayoutRate: roundData.multiplier });
      this.repositories.middlewares.betting.on_finalizeBet({game: 'UPGRADER', userId: user.id, betAmount: inputBetAmount, won: roundData.won, riskPayoutRate: roundData.multiplier})
      const gameData = {
       roundData: {
         ...roundData, fastAnimation
        }
      };

      this.repositories.redis.ioPublishToUser(user.id, 'upgrader:game', gameData);

      //const delay = fastAnimation ? 1000 : 7500;
      const lastOutputItem = (outputItems.sort((a, b) => { return b.price - a.price }))[0];
      const delay = fastAnimation ? 3000 : 10000;
      setTimeout(() => {
       
        this.pushHistory({
          id: uuidv1(),
          user,
          won: roundData.won,
          multiplier: roundData.multiplier,
          inputBetAmount,
          outputBetAmount,
          outputItem: { 
            market_hash_name: lastOutputItem.market_hash_name, 
            image: lastOutputItem.image
          }
        });

      }, delay);

    } catch(err) {
      this.modules.logger.log("gamemodes-upgrader-errors", `User Id ${user.id} -- ERROR!`);
      this.modules.logger.log("gamemodes-upgrader-errors", err.name);
      this.modules.logger.log("gamemodes-upgrader-errors", err.stack);
      this.repositories.user.notify(user.id, 'error', err.message)
    } finally {
      release();
    }
  }


}