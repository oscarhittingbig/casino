const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);

   
  }


  async on_play(data) {
    try {
      await this.repositories.upgrader.game.play({ ...data })
    } catch (err) {

    } finally {

    }
  }


}