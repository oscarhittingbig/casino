module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  modifyUserData(userData) {
    return {
      id: userData.id,
      accountId: userData.accountId,
      displayName: userData.displayName,
      avatar: userData.avatar,
      balance: userData.balance,
      role: userData.role,
      exp: userData.exp,
      settings: {
        tradeUrl: userData.tradeUrl,
        volume: userData.volume,
        isAnon: userData.isAnon,
        isPrivate: userData.isPrivate
      }
    }
  }
  
  getUserProfile(user) {
    return {
      id: user.id,
      accountId: (!user.settings.isAnon && !user.settings.isPrivate) ? user.accountId : 0,
      displayName: !user.settings.isAnon ? user.displayName : 'Anonymous',
      avatar: !user.settings.isAnon ? user.avatar : 'https://steamuserimages-a.akamaihd.net/ugc/885384897182110030/F095539864AC9E94AE5236E04C8CA7C2725BCEFF/',
      role: user.role,
      exp: user.exp
    }
  }

  
  async getBalance(userId) {
    return (await this.modules.db.query("SELECT balance FROM user_data_common WHERE userId = ?", [userId]))[0].balance;
}
async updateBalance({way, userId, amount, transactionType, alterType, alterName}) {
    const sql = await this.modules.db.call(`${way == 'IN' ? "user_increaseBalance" : "user_decreaseBalance"}(?, ?, ?, ?, ?)`, [userId, amount, transactionType, alterType || '', alterName || '']);
    if (!sql.success) {
        if (way == 'IN') return false;
        else throw new Error("PAGE_GENERAL_INSUFFICIENTBALANCE");
    }
    if (way == 'OUT' && alterType == 'BET') {
      this.repositories.middlewares.betting.on_bet({userId, amount})
      //if (sql.params.newExp) this.repositories.redis.ioSetUserSocketProperty(userId, 'exp', sql.params.newExp);
    }
    this.repositories.redis.ioPublishToUser(userId, 'user:updateBalance', { value: sql.params.newBalance, time: Date.now() });
    return true;
}

async finalizeBet({ userId, game, roundId, betAmount, betTo, won, betWinner, multiplier, winnings, riskPayoutRate}) {
    const sql = await this.modules.db.call(`user_finalizeBet(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [userId, game, roundId, betAmount, betTo || '', won, betWinner || '', multiplier || 0, winnings || 0, riskPayoutRate]);
    if (!sql.success) this.modules.logger.log("user-gamehistory", `Game history of user id #${userId} couldn't be saved! Game: ${game}, bet amount ${(betAmount / 100).toFixed(2)} coins, won ${won}, multiplier ${multiplier}, winnings ${winnings}`)

}

  async notify(userId, type = 'info', message, messageParams) {
    this.repositories.redis.ioPublishToUser(userId, 'user:notify', { message, type, messageParams });
  }

}