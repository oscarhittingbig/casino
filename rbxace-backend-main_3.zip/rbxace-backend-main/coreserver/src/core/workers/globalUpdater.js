const moment = require('moment');

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.defs = {
            THREAD: {
                INTERVAL: 30 * 1000
            }
        }
        this.mainThread();
    }
    async init() {
        
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            await this.sync();
        } catch (err) {
            this.modules.logger.log("worker-globalUpdater-mainThread", err.name);
            this.modules.logger.log("worker-globalUpdater-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async sync() {
        global.settings = (await this.modules.db.query("SELECT * FROM global_settings"))[0];
        global.affiliates_levelTable = await this.modules.db.query("SELECT * FROM affiliate_level_table ORDER BY level ASC");
    }

}