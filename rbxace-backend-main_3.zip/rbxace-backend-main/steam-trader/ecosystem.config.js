module.exports = {
  apps : [{
    name       : "steam-trader",
    script     : "./src/boot/init.js",
    exec_mode  : "fork",
	error_file: 'logs/app-err.log',
    out_file: 'logs/app-out.log',
    log_file: 'logs/app-combined.log',
  }],

};
