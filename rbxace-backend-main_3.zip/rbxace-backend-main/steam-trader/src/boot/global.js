
require("dotenv").config();
require('console-stamp')(console, '[ddd mmm dd yyyy HH:MM:ss]');
const path = require('path');
const fs = require('fs');

process.setMaxListeners(0);

global.devMode = process.env.debug == 'true';
global.appRoot = path.dirname(require.main.filename) + `/../../`;
global.srcRoot = global.appRoot + 'src/';
global.tmpRoot = global.appRoot + 'tmp/';
global.getSrcPath = function(path) { return global.srcRoot + path; };
global.getTmpPath = function(path) { return global.tmpRoot + path; };
global.getFilesInDirectory = function(directory) { 
   let fileObjs = [];
   const fileNames = fs.readdirSync(directory);
   fileNames.forEach(fileName => {
    const filePath = directory + '/' + fileName;
    fileName = fileName.replace('.js', '');
    fileObjs.push({ name: fileName, path: filePath });
    });
    return fileObjs;
};
global.loadFromPath = function({args, path, obj, recursive, isModule}) {
    const files = global.getFilesInDirectory(path).sort((a, b) => { 
        const isADirectory = !(a.path.endsWith('.js'));
        const isBDirectory = !(b.path.endsWith('.js'));
        return (isADirectory === isBDirectory)? 0 : isADirectory? 1 : -1 
    });
   
    for (let i in files) {
        const file = files[i];
        const isDirectory = file.path.endsWith('.js') == false;      
        const excluded = file.path.endsWith("classes");
        if (isDirectory && excluded) continue;  
        if (isDirectory && recursive) { global.loadFromPath({args, path: file.path, obj: obj[file.name], recursive, isModule}); continue;}
        else if (isDirectory && recursive == false) continue;
        obj[file.name] = isModule ? require(file.path) : new (require(file.path))(args)
    }
}
global.capitalizeFirstLetter = function(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}
global.getBetween = function(str, first, second) {
    let firstIndex = str.indexOf(first) + first.length;
    let strWithoutFirst = str.substring(firstIndex);
    let lastIndex = strWithoutFirst.indexOf(second);
    return str.substring(
        firstIndex,
        firstIndex + lastIndex
    );
}
global.WORKER = parseInt(process.env.NODE_APP_INSTANCE) + 1;
global.MAIN = (process.env.NODE_APP_INSTANCE == 0) ? true : false;

console.log(`Application has been started ~ PID ${process.pid}`);


/*
if (global.devMode) global.appDir = path.dirname(require.main.filename) + `/../../`;
else global.appDir = path.dirname(require.main.filename) + `/../../`;
*/
