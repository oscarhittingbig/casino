require('./global');
const loader = require('./loader');


const args = loader.generateArgs();

async function main() {
    await args.repositories.proxies.init();
    await args.repositories.bots.init();
}

main();