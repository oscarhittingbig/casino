const NodeCache = require("node-cache");
const memManager = new NodeCache({ stdTTL: 5, checkperiod: 120 });

const fs = require("fs");

module.exports = {


  memSet(key, val, expire) {
    let success = memManager.set(key, val, expire);
  },

  memGet(key) {
    let value = memManager.get(key);

    return value;
  },

  fileSet(key, obj) {
    try {
      fs.writeFileSync(global.appRoot + "caches/" + key + ".cache", JSON.stringify(obj));
    } catch (err) {
      console.log('Problem on fileSet');
      console.log(err);
    }

  },

  fileGet(key) {
    try {
      let fileName = global.appRoot + "caches/" + key + ".cache";
      if (!fs.existsSync(fileName)) {
        return [];
      }
      let data = fs.readFileSync(fileName, "utf-8");

      return JSON.parse(data);
    } catch (err) {
      console.log("Key: " + key + " " + err);
      return [];
    }
  },

  getCooldown(key, cooldown) {
    let end = this.memGet(key);
    if (end == undefined) {
      let endDate = new Date().getTime() + (cooldown * 1000);
      this.memSet(key, endDate, cooldown);
      return 0;
    } else {
      let diff = end - new Date().getTime();
      return (diff / 1000).toFixed(2);
    }
  }
}
