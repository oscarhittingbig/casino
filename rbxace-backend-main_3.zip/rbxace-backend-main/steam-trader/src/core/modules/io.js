var io;
try {
  io = require('socket.io-emitter')({ host: '127.0.0.1', port: 6379 });
  /*
io = require('socket.io')(9003);
const redisAdapter = require('socket.io-redis');
io.adapter(redisAdapter({ host: 'localhost', port: 6379 }));
*/
} catch (err) {
  console.log('Already in use?? stopping')
  console.log(err);
  throw new Error("Socket.io adapter is already in use!");
}


module.exports = io;
