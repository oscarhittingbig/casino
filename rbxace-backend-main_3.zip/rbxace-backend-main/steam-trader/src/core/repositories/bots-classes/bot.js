const SteamCommunity = require('steamcommunity');
const SteamTradeOffers = require('steam-tradeoffers');
const SteamTOTP = require('steam-totp');

const moment = require('moment');
const request = require("request");

const BotOffers = require("./bot/offers");
const BotSessionWorker = require("./bot/sessionWorker");
const BotOfferQueueWorker = require("./bot/offerQueueWorker");
const BotOfferCheckerWorker = require("./bot/offerCheckerWorker");
const BotInventoryWorker = require("./bot/inventoryWorker");
const BotClientWorker = require("./bot/clientWorker");
const BotItemBusinessChecker = require("./bot/itemBusinessChecker");
const BotTransferWorker = require('./bot/transferWorker');

const Mutex = require('async-mutex').Mutex;

module.exports = class {

    constructor({ params, accountData }) {
        params.inject(this);

        this.proxy = this.repositories.proxies.getProxy(this.isVault);
        this.steamCommunity = new SteamCommunity({ request: request.defaults({ proxy: this.proxy }) });
        this.steamTradeOffers = new SteamTradeOffers();
        /*
  let community = new SteamCommunity({"request": Request.defaults({"proxy": "http://1.2.3.4"})});
  */
        this.muleMutex = new Mutex();
        this.accountData = accountData;
        this.isVault = this.accountData.type == 'VAULT';
        this.id = 0;
        this.sessionData = {};
        this.loggingIn = false;
        this.loggedIn = false;
        this.init(params);
    }


    async init(params) {
    
        await this.syncDbBot();
        await this.setDbIsOnline(0);
       
        this.loadSessionData();
        if (!this.sessionData) await this.login();
        else await this.checkSessionHealth();
        while (!this.loggedIn) await this.login();
        await this.setDbIsOnline(true);
    
        this.steamCommunity.stopConfirmationChecker();
        this.steamCommunity.startConfirmationChecker(30 * 1000, this.accountData.identity_secret);


        
        this.accountData.apiKey = await this.getWebApiKey();
        this.modules.logger.log("bot-apikeys", `${this.accountData.accountName} [${this.accountData.steamid} - #${this.id}] -> Api Key ${this.accountData.apiKey}`)
        if (!this.accountData.apiKey) process.exit(0);
        

        this.setupSteamTradeOffers();
        this.offers = new BotOffers({ bot: this, params })
        this.sessionWorker = new BotSessionWorker({ bot: this, params })
        this.offerQueueWorker = new BotOfferQueueWorker({ bot: this, params })
        this.offerCheckerWorker = new BotOfferCheckerWorker({ bot: this, params })
        this.clientWorker = new BotClientWorker({ bot: this, params, proxy: this.proxy })
        this.inventoryWorker = new BotInventoryWorker({ bot: this, params });
        if (this.accountData.type == 'VAULT') {
            this.itemBusinessWorker = new BotItemBusinessChecker({ bot: this, params });
        }
        if (this.accountData.type == 'MULE') {
            this.transferWorker = new BotTransferWorker({ bot: this, params })
        }
    }

    async syncDbBot() {
        await this.modules.db.exec("INSERT IGNORE INTO steam_trade_bots SET ?", [{
            steamId: this.accountData.steamid,
            type: this.accountData.type,
            tradeUrl: this.accountData.tradeUrl,
            createdAt: moment().utc().unix()
        }]);
        this.id = (await this.modules.db.select("steam_trade_bots", "steamId", this.accountData.steamid)).id;
    }

    async setDbIsOnline(isOnline) {
        await this.modules.db.exec("UPDATE steam_trade_bots SET isOnline = ?, type = ?, tradeUrl = ?, lastPing = ? WHERE id = ?", [isOnline, this.accountData.type, this.accountData.tradeUrl || '', moment().utc().unix(), this.id]);
    }

    loadSessionData() {
        this.sessionData = this.modules.cache.fileGet(`bot-session-${this.accountData.steamid}`);
        if (Array.isArray(this.sessionData) || !this.sessionData) {
            this.sessionData = null;
            return this.modules.logger.log("bot-logins", `${this.accountData.accountName} [${this.accountData.steamid} - #${this.id}] -> Doesn't have a session, needs login`);
        }
        this.modules.logger.log("bot-logins", `${this.accountData.accountName} [${this.accountData.steamid} - #${this.id}] -> Has session, no need login`)
        this.injectSessionData();
    }
    injectSessionData() {
        this.steamCommunity.setCookies(this.sessionData.cookies);
    }
    saveSessionData() {
        this.modules.cache.fileSet(`bot-session-${this.accountData.steamid}`, this.sessionData);
    }

    async getWebApiKey() {
        return await new Promise(async (resolve, reject) => {
            this.steamCommunity.getWebApiKey('localhost', (err, key) => {
                if (err) {
                    this.modules.logger.log("bot-apikeys", `${this.accountData.accountName} [${this.accountData.steamid} - #${this.id}] -> Couldn't get bot apikey!`)
                    return resolve(false);
                }
                return resolve(key);
            });
        });
    }

    generateFaCode() {
        return SteamTOTP.generateAuthCode(this.accountData.shared_secret);
    }

    async login() {
        this.proxy = this.repositories.proxies.getProxy(this.isVault);
        this.loggingIn = true;
        this.accountData.twoFactorCode = this.generateFaCode();
        this.modules.logger.log("bot-logins", `${this.accountData.accountName} [${this.accountData.steamid} - #${this.id}] -> Logging in`)
        return await new Promise(async (resolve, reject) => {
            this.steamCommunity.login(this.accountData, (err, sessionID, cookies, steamguard) => {
                if (err) {
                    this.modules.logger.log("bot-logins", `${this.accountData.accountName} [${this.accountData.steamid} - #${this.id}] -> ERROR | ${err}`)
                    this.loggingIn = false;
                    return resolve(false);
                }
                this.modules.logger.log("bot-logins", `${this.accountData.accountName} [${this.accountData.steamid} - #${this.id}] -> Logged in`);

                this.sessionData = { sessionID, cookies };
                this.saveSessionData();
                this.injectSessionData();
                this.loggedIn = true;
                this.setupSteamTradeOffers();
                this.loggingIn = false;
                this.steamCommunity.stopConfirmationChecker();
                this.steamCommunity.startConfirmationChecker(30 * 1000, this.accountData.identity_secret);
                return resolve(true);
                /*
              account.cookies = cookies;
              community.getWebApiKey('', webApiKey);
              community.startConfirmationChecker(10000, account.identity_secret);
              */
            });
        });
    }
    async checkSessionHealth() {
        return await new Promise((resolve, reject) => {
            this.steamCommunity.loggedIn((err, loggedIn, familyView) => {
                if (err || !loggedIn) {
                    this.modules.logger.log("bot-logins", `${this.accountData.accountName} [${this.accountData.steamid} - #${this.id}] -> Session expired, needs new login`)
                    this.loggedIn = false;
                    this.sessionData = null;
                    this.saveSessionData();
                    return resolve(false);
                }
                this.modules.logger.log("bot-logins", `${this.accountData.accountName} [${this.accountData.steamid} - #${this.id}] -> Session health cool`)
                this.loggedIn = true;
                return resolve(true);
            });
        });
    }

    async setupSteamTradeOffers() {
        this.steamTradeOffers.setup({
            sessionID: this.sessionData.sessionID,
            webCookie: this.sessionData.cookies,
            APIKey: this.accountData.apiKey,
            requestOptions: request.defaults({ proxy: this.proxy })
        });
    }

}