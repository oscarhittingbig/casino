const SteamUser = require('steam-user');

module.exports = class {

    constructor({ bot, params, proxy }) {
        params.inject(this);
        this.bot = bot;
        this.proxy = proxy;

        this.client = new SteamUser({
            httpProxy: this.proxy
        });

        this.init();
    }

    init() {
        
        this.client.on('webSession', (sessionId, cookies) => {

        })

        this.client.setOption("promptSteamGuardCode", false);

        this.client.on('steamGuard', (domain, callback) => {
            setTimeout(() => {
                const code = this.bot.generateFaCode();
                callback(code);
            }, 10000)
        });

        this.client.on('error', (e) => {
            console.log("ERROR OCCURED");
            console.log(e);
        });

        this.client.on('friendsList', () => {
  
            const steamIds = Object.keys(this.client.myFriends);
            if (steamIds.length == 0) return;
            const targetSteamId = steamIds[Math.floor(Math.random() * steamIds.length)];

            const messages = ['hi', 'hello', 'sup', 'how r u', 'trade time bruh', 'yo', 'bruh', 'broski?', 'hey'];
            const randomMessage = messages[Math.floor(Math.random() * messages.length)];
            this.client.chatMessage(targetSteamId, randomMessage);
        })

        this.client.on('loggedOn', () => {
            //console.log("Successfully logged in!");
            this.client.setPersona(1);
            //this.client.addFriend('76561198281139834')
        })

        this.client.logOn({
            accountName: this.bot.accountData.accountName,
            password: this.bot.accountData.password,
            twoFactorCode: this.bot.generateFaCode()
        });
    }



}