const moment = require('moment');
const axios = require('axios');

module.exports = class {

    constructor({ bot, params }) {
        params.inject(this);
        this.bot = bot;

        this.defs = {
            THREAD: {
                INTERVAL: 1 * 10 * 1000
            }
        }
        this.previousItems = { 'RUST':[], 'CSGO': [], 'DOTA2': [] };
        this.init();
    }
    async init() {
        const dbInventory = await this.modules.db.query("SELECT steam_bot_items.* FROM steam_bot_items WHERE botId = ?", [this.bot.id]);
        let items = await dbInventory.reduce((obj, el) => { if (!obj[el.app]) obj[el.app] = {}; obj[el.app][el.assetid] = el; return obj;}, {});
        const apps = Object.keys(this.repositories.steam.apps);
        for (let i in apps) {
            const app = apps[i];
            if (!items[app]) items[app] = [];
        }
        this.previousItems = items;
        this.mainThread();
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            const apps = Object.keys(this.repositories.steam.apps);
            for (let i in apps) {
                const app = apps[i];
                await this.syncDbShopWithInventory(app);
            }
            
        } catch (err) {
            this.modules.logger.log("repositories-bot-inventoryWorker-mainThread", err.name);
            this.modules.logger.log("repositories-bot-inventoryWorker-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async syncDbShopWithInventory(app) {
        let itemsToBeAdded = [];
        let itemsToBeRemoved = [];
        const currentItems = (await this.repositories.inventory.get({app, steamId: this.bot.accountData.steamid, isBot: true})).reduce((obj, el) => { obj[el.assetid] = el; return obj;}, {});
        const currentItemsKeys = Object.keys(currentItems)
        currentItemsKeys.forEach(assetId => { if (!this.previousItems[app][assetId]) itemsToBeAdded.push(currentItems[assetId])});
        Object.keys(this.previousItems[app]).forEach(assetId => { if (!currentItems[assetId]) itemsToBeRemoved.push(this.previousItems[app][assetId])});

        for (let i in itemsToBeAdded) {
            const item = itemsToBeAdded[i];
            const insertSuccess = await this.modules.db.exec("INSERT IGNORE INTO steam_bot_items SET ?", [{
                app,
                botId: this.bot.id,
                assetid: item.assetid,
                amount: item.amount,
                market_hash_name: item.market_hash_name,
                image: item.image,
                price: item.price,
                available: item.available,
                createdAt: moment().utc().unix(),
                lastUpdate: moment().utc().unix()
            }]);
            this.modules.logger.log("bot-shop", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> New Item ${item.market_hash_name } - ${item.assetid} ${insertSuccess ? 'has been added to the database' : "couldn't be added to the database!"}`);
        }
        if (this.bot.isVault)
        if (itemsToBeAdded.length > 0) this.repositories.redis.ioPublishChannel("steamtrader:shop", "steamtrader:shop:addItems", itemsToBeAdded)

        for (let i in itemsToBeRemoved) {
            const item = itemsToBeRemoved[i];
            const deleteSuccess = await this.modules.db.exec("DELETE FROM steam_bot_items WHERE botId = ? AND app = ? AND assetid = ?", [this.bot.id, app, item.assetid]);
            this.modules.logger.log("bot-shop", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> ${item.market_hash_name } - ${item.assetid} ${deleteSuccess ? 'has been deleted from the database' : "couldn't be deleted from the database!"}`);
        }
        if (this.bot.isVault)
        if (itemsToBeRemoved.length > 0) this.repositories.redis.ioPublishChannel("steamtrader:shop", "steamtrader:shop:removeItems", itemsToBeRemoved)

        for (let i in currentItemsKeys){
            const assetId = currentItemsKeys[i];
            const currentItem = currentItems[assetId];
            const previousItem = this.previousItems[app][assetId];
            //console.log(currentItem.market_hash_name, 'curr amo', currentItem.amount, 'prev amo', previousItem.amount);
            if (previousItem && currentItem.amount !== previousItem.amount)
            await this.modules.db.exec("UPDATE steam_bot_items SET price = ?, amount = ? WHERE assetid = ?", [currentItem.price, currentItem.amount, currentItem.assetid]);
            else if (previousItem && currentItem.price !== previousItem.price)
            await this.modules.db.exec("UPDATE steam_bot_items SET price = ? WHERE assetid = ?", [currentItem.price, currentItem.assetid]);
        }

        await this.modules.db.exec(`UPDATE steam_trade_bots SET inventorySize_${app} = ?, lastInventoryRefresh_${app} = ? WHERE id = ?`, [currentItemsKeys.length, moment().utc().unix(), this.bot.id]);


        this.previousItems[app] = currentItems;
    }

}