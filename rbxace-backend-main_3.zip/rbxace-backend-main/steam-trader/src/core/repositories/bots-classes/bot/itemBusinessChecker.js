const moment = require('moment');

module.exports = class {

    constructor({ bot, params }) {
        params.inject(this);
        this.bot = bot;

        this.defs = {
            THREAD: {
                INTERVAL: 10 * 1000
            }
        }
        this.mainThread();
    }
    async init() {
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            const apps = Object.keys(this.repositories.steam.apps);
            for (let i in apps) {
                const app = apps[i];
                await this.handle(app);
            }
        } catch (err) {
            this.modules.logger.log("worker-itemBusinessChecker-mainThread", err.name);
            this.modules.logger.log("worker-itemBusinessChecker-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async handle(app) {
        const lastInventoryRefresh = (await this.modules.db.query(`SELECT lastInventoryRefresh_${app} FROM steam_trade_bots WHERE id = ?`, [this.bot.id]))[0][`lastInventoryRefresh_${app}`];
        const expirationAfter = lastInventoryRefresh - (60 * 5);


        const dbOffers = await this.modules.db.query("SELECT * FROM steam_trade_offers WHERE type = 'WITHDRAW' AND steamState = 'ACCEPTED' AND itemBusinessHandled = 0 AND lastUpdate < ?", [expirationAfter]);
        for (let i in dbOffers) {
            const dbOffer = dbOffers[i];

            let setItemsBusinessData = [];
            const dbOfferItems = await this.modules.db.query("SELECT * FROM steam_trade_offer_items WHERE offerId = ? ORDER BY id ASC", [dbOffer.id]);
            for (let i in dbOfferItems) {
                const dbOfferItem = dbOfferItems[i];
                await this.modules.db.exec("UPDATE steam_shop_items SET busy = 0 WHERE botId = ? AND app = ? AND assetid = ?", [dbOffer.botId, dbOfferItem.app, dbOfferItem.assetid]);
                
                try {
                const newAmount = (await this.modules.db.query("SELECT amount FROM steam_shop_items WHERE botId = ? AND app = ? AND assetid = ?", [dbOffer.botId, dbOfferItem.app, dbOfferItem.assetid]))[0].amount;
                setItemsBusinessData.push({ assetid: dbOfferItem.assetid, amount: newAmount, busy: false });
                } catch {

                }
            }
            this.repositories.redis.ioPublishChannel("steamtrader:shop", "steamtrader:shop:setItemsBusiness", setItemsBusinessData);


            const updateSuccess = await this.modules.db.exec("UPDATE steam_trade_offers SET itemBusinessHandled = 1 WHERE id = ?", [dbOffer.id]);
            if (!updateSuccess) throw new Error("Something went wrong while updating db offer!");
        }

    }

}