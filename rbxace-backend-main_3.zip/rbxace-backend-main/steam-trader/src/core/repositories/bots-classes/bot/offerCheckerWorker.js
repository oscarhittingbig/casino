const moment = require('moment');
const TRADE_STATES = {
    1: 'INVALID',
    2: 'ACTIVE',
    3: 'ACCEPTED',
    4: 'COUNTERED',
    5: 'EXPIRED',
    6: 'CANCELED',
    7: 'DECLINED',
    8: 'INVALID_ITEMS',
    9: 'CREATED_NEEDS_CONFIRMATION',
    10: 'CANCELED_BY_SECOND_FACTOR',
    11: 'IN_ESCROW',
}
module.exports = class {

    constructor({ bot, params }) {
        params.inject(this);
        this.bot = bot;

        this.defs = {
            THREAD: {
                INTERVAL: (this.bot.accountData.type == 'BALANCE' ? 15 : 13) * 1000
            },
            TRADE: {
                EXPIRATION_TIME: 10 * 60 //seconds
            }
        }

        this.previousOfferStates = {};
        this.mainThread();
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            if (this.bot.loggingIn || !this.bot.loggedIn) return;
            if (this.bot.isVault) {
                await this.handleVaultAcceptions();
            } else {
                await this.handleOffers();
                ////await this.handleCounterTrades();
                await this.handleExpirations();
            }
        } catch (err) {
            this.modules.logger.log("repositories-bot-offerCheckerWorker-mainThread", err.name);
            this.modules.logger.log("repositories-bot-offerCheckerWorker-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async getOffers(options) {
        return await new Promise(async (resolve, reject) => {
            this.bot.steamTradeOffers.getOffers(options, function (err, body) {
                if (err) return resolve(false);
                if (body && body.response && (body.response.trade_offers_sent || body.response.trade_offers_received)) resolve(body.response.trade_offers_sent || body.response.trade_offers_received)
                else resolve(false);

            });
        });
    }

    async acceptOffer(options) {
        return await new Promise(async (resolve, reject) => {
            this.bot.steamTradeOffers.acceptOffer(options, function (err, body) {
                if (err) return resolve(false);
                if (body && body.response) resolve(true)
                else resolve(false);

            });
        });
    }

    async declineOffer(options) {

        return await new Promise(async (resolve, reject) => {
            this.bot.steamTradeOffers.declineOffer(options, function (err, body) {
                if (err) return resolve(false);
                if (body && body.response) resolve(true)
                else resolve(false);

            });
        });
    }

    async cancelOffer(options) {

        return await new Promise(async (resolve, reject) => {
            this.bot.steamTradeOffers.cancelOffer(options, function (err, body) {
                if (err) return resolve(false);
                if (body && body.response) resolve(true)
                else resolve(false);

            });
        });
    }

    async handleOffers() {
        const timeCut = moment().utc().unix() - (86400 * 4);
        const offers = await this.getOffers({
            get_sent_offers: 1,
            active_only: 0,
            time_historical_cutoff: timeCut
        });

        this.modules.logger.log("bot-offers", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> Processing ${offers.length} offers!`);
        if (!offers) return;
        for (let i in offers) {
            const offer = offers[i];
            await this.handleOffer(offer);
        }
    }

    async completeBalanceDeposit(dbOffer, trackingId) {
        const updateSuccess = await this.repositories.user.updateBalance({ way: 'IN', userId: dbOffer.userId, amount: dbOffer.overall, transactionType: 'DEPOSIT_STEAM_SKINS', alterType: 'DEPOSIT', alterName: 'STEAM_SKINS' });
        if (!updateSuccess) return this.modules.logger.log("bot-offers", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> [Tracking Id #${trackingId}] deposit couldn't be credited, error on sql`);
        else this.modules.logger.log("bot-offers", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> [Tracking Id #${trackingId}] user successfully credited ${(dbOffer.overall / 100).toFixed(2)} coins`);

        this.repositories.redis.sendMessageToUser(dbOffer.userId, "steamtrader:depositCompleted", {
            amount: dbOffer.overall
        });
    }

    async completeBalanceWithdraw(dbOffer, trackingId) {
        const updateSuccess = await this.modules.db.exec("INSERT INTO user_trades SET ?", [{
            userId: dbOffer.userId,
            way: 'WITHDRAW',
            type: 'STEAM_SKINS',
            amount: dbOffer.overall,
            time: moment().utc().unix()
        }]);
        if (!updateSuccess) return this.modules.logger.log("bot-offers", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> [Tracking Id #${trackingId}] withdraw couldn't be inserted to db (user_trades)`);
        else this.modules.logger.log("bot-offers", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> [Tracking Id #${trackingId}] withdraw has been inserted to db`);
        await this.modules.db.exec("UPDATE user_stats SET totalWithdrawn = totalWithdrawn + ? WHERE userId = ?", [dbOffer.overall, dbOffer.userId]);

    }

    async handleUpgraderOffer(dbOffer, currentOfferState) {
        let updateSuccess = false;
        if (currentOfferState !== 'ACCEPTED') {
            await this.repositories.upgrader.refundFailedOffer(dbOffer);
        } else {
            if (dbOffer.muleState == 'MULE') {
                const sourceTransaction = await this.modules.db.select("steam_trade_vault_mule_transactions", "finalOfferId", dbOffer.id);
                updateSuccess = await this.modules.db.exec("UPDATE game_upgrader_user_inventory SET state = 'WITHDRAWN' WHERE state = 'IN_OFFER' AND linkedTransactionId = ?", [sourceTransaction.id]);
                const insertTradeSuccess = await this.modules.db.exec("INSERT INTO user_trades SET ?", [{
                    userId: dbOffer.userId,
                    way: 'WITHDRAW',
                    type: 'UPGRADER',
                    amount: dbOffer.overall,
                    time: moment().utc().unix()
                }]);
                await this.modules.db.exec("UPDATE user_stats SET totalWithdrawn = totalWithdrawn + ? WHERE userId = ?", [dbOffer.overall, dbOffer.userId]);
            }
        }
        if (!updateSuccess) this.modules.logger.log("bot-upgrader-offer-errors", `${dbOffer.id} -- linked offer id couldnt be updated`);
    }

    async handleOffer(offer) {

        //gelen offerları iptal etmeli, (counter offerlar) ve expiration için ayrı bir tane olmalı
        //if (!offer.is_our_offer || !offer.message.includes("tracking id #")) return;
        if (!offer.is_our_offer) return;

        const trackingId = offer.message; //offer.message.split('#')[1];
        const previousOfferState = this.previousOfferStates[trackingId];
        const currentOfferState = TRADE_STATES[offer.trade_offer_state];

        const now = moment().utc().unix();

        let syncOfferState = false;
        try {
            if (currentOfferState == previousOfferState) return;

            const dbSteamStateSql = (await this.modules.db.query("SELECT steamState FROM steam_trade_offers WHERE trackingId = ?", [trackingId]));
            if (dbSteamStateSql.length == 0) return;
            const dbSteamState = dbSteamStateSql[0].steamState;
            if (dbSteamState == 'ACCEPTED' || dbSteamState == currentOfferState) { syncOfferState = true; return; }

            const dbOffer = await this.modules.db.select("steam_trade_offers", "trackingId", trackingId);
            dbOffer.items = await this.repositories.offer.getItems(dbOffer.id);

            this.modules.logger.log("bot-offers", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> [Tracking Id #${trackingId}] new state: ${currentOfferState}`);

            const updateOfferSuccess = await this.modules.db.exec("UPDATE steam_trade_offers SET steamState = ?, lastUpdate = ? WHERE trackingId = ?", [currentOfferState, now, trackingId]);
            //NO NEED, MAY RESULT WITH BUGS// if (!updateOfferSuccess) throw new Error("Offer couldn't be updated!");

            if (dbOffer.type == 'DEPOSIT' && currentOfferState == 'ACCEPTED') {

                if (dbOffer.target == 'BALANCE') {
                    await this.completeBalanceDeposit(dbOffer, trackingId);
                } else if (dbOffer.target == 'COINFLIP') {
                    await this.repositories.coinflip.queue.noticeTradeCompleted({
                        offer: dbOffer
                    });
                }

            } else if (dbOffer.type == 'WITHDRAW' && currentOfferState == 'ACCEPTED') {

                if (dbOffer.muleState == 'VAULT') {
                    try {
                        await this.bot.inventoryWorker.syncDbShopWithInventory('BOT');
                    } catch(err) { }
                    const updateSuccess = await this.modules.db.exec("UPDATE steam_trade_vault_mule_transaction_links SET state = 'COMPLETED' WHERE offerId = ?", [dbOffer.id]);
                    //
                } else {
                    if (dbOffer.target == 'BALANCE') {
                        await this.completeBalanceWithdraw(dbOffer, trackingId);
                    }
                }
        
            } else if (dbOffer.type == 'WITHDRAW' && currentOfferState == "ACTIVE" && dbOffer.target !== 'COINFLIP') {

                if (dbOffer.muleState == 'MULE') {
                    const sourceTransaction = await this.modules.db.select("steam_trade_vault_mule_transactions", "finalOfferId", dbOffer.id);
                    this.repositories.redis.ioPublishToUser(dbOffer.userId, "steamtrader:syncWithdraw", { transactionId: sourceTransaction.id });
                    /*
                    // get finalOfferId transaciton id asdasdasd
                    //  this.repositories.redis.ioPublishToUser(finalizedMuleTransaction.userId, "steamtrader:syncWithdraw", { transactionId: finalizedMuleTransaction.id });
                    /*
                    this.repositories.redis.ioPublishToUser(dbOffer.userId, "steamtrader:offerCallback", {
                        offerId: dbOffer.id
                    });
                    */
                }
                try {
                    //const items = await this.modules.db.query("SELECT * FROM steam_trade_offer_items WHERE offerId = ? ORDER BY id ASC", [dbOffer.id]);
                    /*
    
                    */
                } catch { }

            }

            if (dbOffer.type == 'WITHDRAW' && dbOffer.target == 'UPGRADER' && currentOfferState !== 'ACTIVE' && currentOfferState !== 'CREATED_NEEDS_CONFIRMATION') {
                await this.handleUpgraderOffer(dbOffer, currentOfferState);
            }

            if (dbOffer.muleState == 'MULE' && currentOfferState !== 'ACTIVE' && currentOfferState !== 'CREATED_NEEDS_CONFIRMATION') {
                this.repositories.redis.ioPublishToUser(dbOffer.userId, "steamtrader:completeOffer", { offerId: dbOffer.id });
            }

            if (dbOffer.muleState == 'VAULT' && currentOfferState !== 'ACTIVE' && currentOfferState !== 'ACCEPTED' && currentOfferState !== 'CREATED_NEEDS_CONFIRMATION') {
                const updateSuccess = await this.modules.db.exec("UPDATE steam_trade_vault_mule_transaction_links SET state = 'FAILED' WHERE offerId = ?", [dbOffer.id]);
            }


            syncOfferState = true;
        } catch (err) {
            this.modules.logger.log("bot-offers", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> [Tracking Id #${trackingId}] something went wrong while processing offer`);
            this.modules.logger.log("bot-offers", err.name);
            this.modules.logger.log("bot-offers", err.stack);
        } finally {
            if (syncOfferState) this.previousOfferStates[trackingId] = currentOfferState;
        }

    }


    async handleCounterTrades() {
        const offers = await this.getOffers({
            get_received_offers: 1,
            active_only: 1,
            time_historical_cutoff: Math.round(Date.now() / 1000)
        });
        if (!offers) return;
        for (let i in offers) {
            const offer = offers[i];
            await this.declineOffer({ tradeOfferId: offer.tradeofferid })
        }
    }

    async handleExpirations() {
        const offers = await this.getOffers({
            get_sent_offers: 1,
            active_only: 1,
            time_historical_cutoff: Math.round(Date.now() / 1000)
        });
        if (!offers) return;
        for (let i in offers) {
            const offer = offers[i];
            const now = moment().utc().unix();
            const tradeCreatedAt = offer.time_created;
            const diff = now - tradeCreatedAt;
            if (diff > this.defs.TRADE.EXPIRATION_TIME) {
                await this.cancelOffer({ tradeOfferId: offer.tradeofferid })
            }
        }
    }

    async handleVaultAcceptions() {
        const offers = await this.getOffers({
            get_received_offers: 1,
            active_only: 1,
            time_historical_cutoff: Math.round(Date.now() / 1000)
        });
     
        if (!offers) return;
        for (let i in offers) {
            const offer = offers[i];
            const targetBot = this.repositories.bots.list.find(bot => bot.accountData.steamid == offer.steamid_other);
          
            if (targetBot)
                await this.acceptOffer({ tradeOfferId: offer.tradeofferid })
            else
                await this.declineOffer({ tradeOfferId: offer.tradeofferid })
        }
    }

}