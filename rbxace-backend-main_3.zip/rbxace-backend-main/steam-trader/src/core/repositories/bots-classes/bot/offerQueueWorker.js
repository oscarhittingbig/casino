const axios = require('axios');
const sleep = require('await-sleep');

module.exports = class {

    constructor({ bot, params }) {
        params.inject(this);
        this.bot = bot;

        this.defs = {
            THREAD: {
                INTERVAL: 300
            }
        }
        this.lastSessionCheck = Date.now();
        this.replayThread();
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            if (this.bot.loggingIn || !this.bot.loggedIn) return;
            await this.handleQueue();
        } catch (err) {
            this.modules.logger.log("repositories-bot-offerQueueWorker-mainThread", err.name);
            this.modules.logger.log("repositories-bot-offerQueueWorker-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }


    async acceptConfirmationForTrade(tradeOfferId) {
        return await new Promise(async (resolve, reject) => {
            this.bot.steamCommunity.acceptConfirmationForObject(this.bot.accountData.identity_secret, tradeOfferId, function (err, result) {
                if (err) {
                    return resolve(false);
                }
                return resolve(true);
            });
        });
    }

    async handleQueue() {
        const awaitingOfferSql = await this.modules.db.query("SELECT * FROM steam_trade_offers WHERE botId = ? AND requestState = 'IN_QUEUE' ORDER BY createdAt ASC LIMIT 1", [this.bot.id]);
        if (awaitingOfferSql.length == 0) return;
        let dbAwaitingOffer = awaitingOfferSql[0];
        dbAwaitingOffer.items = await this.modules.db.query("SELECT * FROM steam_trade_offer_items WHERE offerId = ? ORDER BY id ASC", [dbAwaitingOffer.id]);
        this.modules.logger.log("bot-offer-queue", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> [DB Offer Id #${dbAwaitingOffer.id}] creating offer...`);

        let tradeUrl = dbAwaitingOffer.tradeUrl;
        let targetVaultBot = null;
        if (dbAwaitingOffer.muleState == 'VAULT') {
            targetVaultBot = this.repositories.bots.list.find(bot => bot.id == dbAwaitingOffer.targetBotId);
            if (!targetVaultBot) tradeUrl = null;
            else tradeUrl = targetVaultBot.accountData.tradeUrl;
        }
        //const assets = await dbAwaitingOffer.items.reduce((newArr, el) => { newArr.push(el.assetid); return newArr; }, [])

        let offerData = {
            app: dbAwaitingOffer.app,
            trackingId: dbAwaitingOffer.trackingId,
            tradeUrl,
            assetIdsToReceive: [],
            assetIdsToSend: []
        };

        let offerWay = dbAwaitingOffer.type == 'DEPOSIT' ? 'assetIdsToReceive' : 'assetIdsToSend';
        if (dbAwaitingOffer.muleState == 'VAULT') offerWay = 'assetIdsToReceive';
        offerData[offerWay] = dbAwaitingOffer.items;

        const steamOfferId = (await this.bot.offers.makeOffer(offerData) || null);

        this.modules.logger.log("bot-offer-queue", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid}] -> [DB Offer Id #${dbAwaitingOffer.id}] offer ${steamOfferId ? `has been created successfully with steam offer id #${steamOfferId}.` : `couldn't be created!`}`);
        const updateAwaitingOfferSuccess = await this.modules.db.exec(`UPDATE steam_trade_offers SET steamOfferId = ?, requestState = '${steamOfferId ? 'CREATED' : 'FAILED'}' WHERE id = ?`, [steamOfferId, dbAwaitingOffer.id])
        this.modules.logger.log("bot-offer-queue", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid}] -> [DB Offer Id #${dbAwaitingOffer.id}] offer ${updateAwaitingOfferSuccess ? 'db update success.' : 'db update failed.'}`);

        this.modules.logger.log("bot-offer-queue", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid}] -> [DB Offer Id #${dbAwaitingOffer.id}] offer creation completed.`);


        if (steamOfferId) {
            const isWithdraw = dbAwaitingOffer.type == 'WITHDRAW';

            if (dbAwaitingOffer.muleState == 'VAULT' && isWithdraw) {
                await targetVaultBot.offerCheckerWorker.acceptOffer({ tradeOfferId: steamOfferId });
                await sleep(2000);
                await targetVaultBot.offerQueueWorker.acceptConfirmationForTrade(steamOfferId);
            } else if (dbAwaitingOffer.muleState == 'MULE' && isWithdraw) {
                await this.acceptConfirmationForTrade(steamOfferId);
            }

            if (isWithdraw) {
              //  await this.acceptConfirmationForTrade(steamOfferId);
            }
            /*
            if (isWithdraw) {
                let tries = 0;
                let confirmed = false;
                //while (!confirmed && tries <= 3) {
                    confirmed = await this.acceptConfirmationForTrade(steamOfferId);
                    console.log('conf', confirmed);
                    tries++;
                    //await sleep(3000);
                }
            }
            console.log(confirmed)
            */

            
            if (!isWithdraw)
                this.repositories.redis.ioPublishToUser(dbAwaitingOffer.userId, "steamtrader:offerCallback", {
                    offerId: dbAwaitingOffer.id
                });
            

            /*
            else 
                this.repositories.redis.sendMessageToUser(dbAwaitingOffer.userId, "message", {
                type: "error",
                msg: `Your trade offer couldn't be confirmed, please wait a few minutes for refund!`
            });
            */

        } else {
            if (dbAwaitingOffer.type == 'WITHDRAW' && dbAwaitingOffer.target == 'UPGRADER') {
                await this.repositories.upgrader.refundFailedOffer(dbAwaitingOffer);
            }

            this.repositories.redis.sendMessageToUser(dbAwaitingOffer.userId, "message", {
                type: "error",
                msg: `Trade offer couldn't be sent!`
            });
        }
    }

}