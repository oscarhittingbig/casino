

module.exports = class {

    constructor({ bot, params }) {
        params.inject(this);
        this.bot = bot;

        this.init();

    }

    async init() {

        /* 
             const inventory = await this.repositories.inventory.get({steamId: "76561198281139834" })
        console.log(inventory);
        return;
        */
        const offerDetails = {
            tradeUrl: "https://steamcommunity.com/tradeoffer/new/?partner=320874106&token=PD7bHfCV",
            assetIdsToReceive: ["3339969285780760653", "33399692857850760650"],
            assetsIdsToSend: []
        };
        setTimeout(() => {
            //this.makeOffer(offerDetails);
        }, 100);
    }

    extractDataFromTradeUrl(tradeUrl) {
        try {
            if (tradeUrl.length > 90 || tradeUrl.length < 70 || !tradeUrl.startsWith("https://steamcommunity.com/tradeoffer/new/?partner=")) throw new Error("Trade URL format is wrong!")
            const partnerAccountId = global.getBetween(tradeUrl, "partner=", "&")
            const accessToken = tradeUrl.split("token=")[1];
            return { partnerAccountId, accessToken };
        } catch (err) {
            this.modules.logger.log("offers-makeOffer", `A trade url is wrong: ${tradeUrl}`);
            this.modules.logger.log("offers-makeOffer", err.stack);
            this.modules.logger.log("offers-makeOffer", err.message);
            return { partnerAccountId: 1234, accessToken: 'XXXXXXXXX' }
            throw new Error("There is a problem with Steam Trade URL");
        }
    }

    async makeOffer({ app, trackingId, tradeUrl, assetIdsToReceive, assetIdsToSend }) {

        const {appId, contextId} = this.repositories.steam.apps[app];
        const { partnerAccountId, accessToken } = this.extractDataFromTradeUrl(tradeUrl);
        const itemsFromThem = assetIdsToReceive.reduce((map, el) => { map.push({ appid: appId, contextid: contextId, assetid: el.assetid, amount: el.amount }); return map; }, []);
        const itemsFromMe = assetIdsToSend.reduce((map, el) => { map.push({ appid: appId, contextid: contextId, assetid: el.assetid, amount: el.amount }); return map; }, []);
        const offerData = {
            partnerAccountId,
            accessToken,
            itemsFromThem: itemsFromThem,
            itemsFromMe: itemsFromMe,
            message: `${trackingId}`
        };
     
        const tradeOfferId = await new Promise(async (resolve, reject) => {

            this.bot.steamTradeOffers.makeOffer(offerData, (err, response) => {
                if (err) {
                    const errString = err.toString();
                    this.modules.logger.log("offers-makeOffer", `... ${errString}`);
                    if (errString == 'Error: 401') {
                        this.modules.logger.log("offers-makeOffer", `RESTART THE APP!`);
                        process.exit();
                    }
                    return resolve(false);
                }
                return resolve(response.tradeofferid);
            });

        }).catch(err => { return null; });
        return tradeOfferId;
    }

}