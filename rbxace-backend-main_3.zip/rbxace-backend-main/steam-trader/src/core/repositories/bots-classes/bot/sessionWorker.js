const axios = require('axios');

module.exports = class {

    constructor({ bot, params }) {
        params.inject(this);
        this.bot = bot;

        this.defs = {
            THREAD: {
                INTERVAL: 1000
            },
            SESSION_CHECK: {
                INTERVAL: 1 * 60 * 1000
            }
        }
        this.lastSessionCheck = Date.now();
        this.replayThread();
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            await this.handleSessionCheck();
            await this.handleSessionLogin();
        } catch (err) {
            this.modules.logger.log("repositories-bot-sessionWorker-mainThread", err.name);
            this.modules.logger.log("repositories-bot-sessionWorker-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async handleSessionCheck() {
        const now = Date.now();
        if (now < this.lastSessionCheck + this.defs.SESSION_CHECK.INTERVAL) return;
        const isOnline = await this.bot.checkSessionHealth();
        await this.bot.setDbIsOnline(isOnline);
        this.lastSessionCheck = now;
    }

    async handleSessionLogin() {
        if (this.bot.loggingIn) return;
        if (!this.bot.loggedIn) await this.bot.login();
    }


}