const moment = require('moment');
const axios = require('axios');

module.exports = class {

    constructor({ bot, params }) {
        params.inject(this);
        this.bot = bot;

        this.defs = {
            TRANSFER_INTERVAL: 60 * 60, //SECONDS
            THREAD: {
                INTERVAL: 1 * 5 * 1000
            }
        }

        this.mainThread();
    }


    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            const lastTransfer = (await this.modules.db.query("SELECT lastTransfer FROM steam_trade_bots WHERE id = ?", [this.bot.id]))[0].lastTransfer;
            const diff = moment().utc().unix() - lastTransfer;
     
            if (diff < this.defs.TRANSFER_INTERVAL) return;
            await this.transferItems();  
            await this.updateLastTransfer();
        } catch (err) {
            this.modules.logger.log("repositories-bot-transferWorker-mainThread", err.name);
            this.modules.logger.log("repositories-bot-transferWorker-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async pickRandomBot() {
        const botOnlineCutOff = moment().utc().unix() - (60 * 10);
        const assignedBotSql = (await this.modules.db.query("SELECT id, steamId FROM steam_trade_bots WHERE isOnline = 1 AND type = 'VAULT' AND lastPing >= ? ORDER BY RAND() LIMIT 1", [botOnlineCutOff]));
        if (assignedBotSql.length == 0) throw new Error("No online bots to transfer!");
        const randomVaultBotId = assignedBotSql[0].id;
        const randomVaultBot = this.repositories.bots.list.find(bot => bot.id == randomVaultBotId);
        if (!randomVaultBot) throw new Error("Vault bot couldn't be found in app!");
        return randomVaultBot;
    }

    async getFreeItems(botId) {
        const timeCutoff = moment().utc().unix() - (60 * 60);
        const items = await this.modules.db.query("SELECT steam_bot_items.* FROM steam_bot_items WHERE botId = ? AND lastUpdate <= ?", [this.bot.id, timeCutoff]);
        return items;
    }

    async transferItems() {
        const randomVaultBot = await this.pickRandomBot();

        const release = await this.bot.muleMutex.acquire();
        try {
            const items = await this.getFreeItems();
            if (items.length == 0) return  this.modules.logger.log("bot-transfers", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> No items, no transfer!`);
            let offerData = {
                app: 'RUST',
                trackingId: '',
                tradeUrl: randomVaultBot.accountData.tradeUrl,
                assetIdsToReceive: [],
                assetIdsToSend: items
            };
            const steamOfferId = (await this.bot.offers.makeOffer(offerData) || null);
            this.modules.logger.log("bot-transfers", `${this.bot.accountData.accountName} [${this.bot.accountData.steamid} - #${this.bot.id}] -> Transfer to vault ${randomVaultBot.accountData.accountName} [${randomVaultBot.accountData.steamid}] -- Offer Id ${steamOfferId}`);
        } catch(err) {

        } finally {
            release();
        }
    }

    async updateLastTransfer() {
        const updateSuccess = await this.modules.db.exec("UPDATE steam_trade_bots SET lastTransfer = ? WHERE id = ?", [moment().utc().unix(), this.bot.id]);
    }


}