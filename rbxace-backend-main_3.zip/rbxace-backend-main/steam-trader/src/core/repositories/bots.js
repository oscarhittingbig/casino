const Bot = require("./bots-classes/bot.js");

module.exports = class {

    constructor(params) {
        this.params = params;
        params.inject(this);
    }

    async init() {
        const accounts = this.modules.cache.fileGet('accounts');
        this.list = [];
        for (let i in accounts) {
            const accountData = accounts[i];
            this.list.push(new Bot({ params: this.params, accountData }));
        }
    }

    getBot(id) {
        return this.list.find(bot => bot.id == id);
    }
}