const shortid = require('shortid32');
const moment = require('moment');
const Mutex = require('async-mutex').Mutex;
const withdrawMutex = new Mutex();
const coinflipWithdrawMutex = new Mutex();

module.exports = class {

    constructor(params) {
        params.inject(this);


    }



    async createDbOffer({ app, botId, targetBotId, muleState, type, target, targetId, pricingType, trackingId, userId, tradeUrl, items, totalItemsValue, bonusRatio, bonusAmount, overall }) {
        const now = moment().utc().unix();

        const offerId = await this.modules.db.insert("INSERT INTO steam_trade_offers SET ?", [{
            botId,
            type,
            targetBotId: targetBotId || 0,
            muleState: muleState || 'MULE',
            target: target || 'BALANCE',
            targetId: targetId || 0,
            app,
            trackingId,
            userId,
            tradeUrl,
            pricingType: pricingType || 'COINS',
            amount: totalItemsValue,
            bonusRatio: bonusRatio || 0,
            bonusAmount: bonusAmount || 0,
            overall,
            createdAt: now,
            lastUpdate: now,
            itemBusinessHandled: 0
        }]);
        if (!offerId) throw new Error("Something went wrong while inserting trade to the database!");

        for (let i in items) {
            const item = items[i];
            const insertOfferItemSuccess = await this.modules.db.exec("INSERT INTO steam_trade_offer_items SET ?", [{
                offerId,
                app,
                assetid: item.assetid,
                amount: item.amount,
                market_hash_name: item.market_hash_name,
                image: item.image,
                value: item.price
            }]);
            if (!insertOfferItemSuccess) throw new Error("Something went wrong while inserting items to the database!");
        }

        const updateOfferSuccess = await this.modules.db.exec("UPDATE steam_trade_offers SET requestState = 'IN_QUEUE' WHERE id = ?", [offerId]);
        if (!updateOfferSuccess) throw new Error("Something went wrong while updating trade offer on database!");
        return offerId;
    }

    async on_requestDeposit(content) {
        let success = false;
        try {
            if (content.app == 'DOTA2' || content.app == 'CSGO') throw new Error("Temporarily disabled.");
            const inventoryData = await this.repositories.inventory.getUserInventoryData({ app: content.app, userId: content.userId, steamId: content.steamId });
            let totalItemsValue = 0;
            let items = [];
            for (let i in content.assets) {
                const asset = content.assets[i];
                const item = inventoryData.items.find(el => el.assetid == asset.assetid);
                if (!item) throw new Error("Some of the items doesn't exist in your inventory anymore!");
                if (!item.available) throw new Error("Some of the items in your deposit are unavailable! Please refresh your inventory");
                if (item.amount < asset.amount) throw new Error("Some of the items are missing in your inventory! Please refresh your inventory");

                totalItemsValue += item.price * asset.amount;

                let depositItem = JSON.parse(JSON.stringify(item));
                depositItem.amount = asset.amount;
                items.push(depositItem);
            }

            if (totalItemsValue != content.totalItemsValue) throw new Error("Prices are updated, please refresh your inventory!");

            let targetId = 0;
            if (content.target == 'COINFLIP') {
                let queueResult = { success: false };
                if (content.coinflip.isCreation) {
                    queueResult = await this.repositories.coinflip.queue.createDbRoom({
                        ownerId: content.userId,
                        ownerSkinsValue: totalItemsValue,
                        ownerColor: content.coinflip.color
                    });
                    if (!queueResult.success) throw new Error("SOCKET_COINFLIP_CREATIONERROR");
                } else {
                    queueResult = await this.repositories.coinflip.queue.joinDbRoom({
                        roomId: content.coinflip.roomId,
                        opponentId: content.userId,
                        opponentSkinsValue: totalItemsValue
                    });
                    if (!queueResult.success) throw new Error("SOCKET_COINFLIP_ALREADYJOINED");
                }

                targetId = queueResult.roomId;
            }
            //target, targetId


            const pricingType = content.target == 'COINFLIP' ? 'USD' : 'COINS';
            if (pricingType == 'COINS') totalItemsValue *= 10;

            const trackingId = shortid.generate();

            const bonusRatio = inventoryData.bonusRatio || 0;
            const bonusAmount = Math.floor(totalItemsValue * bonusRatio);
            const overall = totalItemsValue + bonusAmount;

            const offerData = {
                app: content.app,
                botId: content.botId,
                muleState: 'MULE',
                type: 'DEPOSIT',
                target: content.target,
                targetId,
                trackingId,
                userId: content.userId,
                tradeUrl: content.tradeUrl,
                pricingType,
                items,
                totalItemsValue,
                bonusRatio,
                bonusAmount,
                overall
            };

            const offerId = await this.createDbOffer(offerData);
            success = true;

            if (content.target == 'COINFLIP') {
                if (!content.coinflip.isCreation) {
                    await this.modules.db.exec("UPDATE game_coinflip_rooms SET lastOpponentOfferId = ? WHERE id = ?", [offerId, targetId]);
                    //await this.repositories.coinflip.trading.updateTotalSkinsValue(targetId);
                } else {
                    await this.modules.db.exec("UPDATE game_coinflip_rooms SET ownerOfferId = ? WHERE id = ?", [offerId, targetId]);
                }
            }

            /*
            return this.repositories.redis.sendMessageToUser(content.userId, "message", {
                type: "info",
                msg: `Your request has been placed in a queue, please wait for a while!`
            });
            */

        } catch (err) {
            console.log(err)
            return this.repositories.redis.ioNotifyUser(content.userId, "error", `${err.message}`);
        } finally {
            this.repositories.redis.ioPublishToUser(content.userId, "steamtrader:requestResponse", success);
        }
    }

    async on_requestWithdraw(content) {
        let success = false;
        const release = await withdrawMutex.acquire();
        try {

            let totalItemsValue = 0;
            let itemsBots = {};
            const shopItems = await this.modules.db.query("SELECT steam_bot_items.* FROM steam_bot_items INNER JOIN steam_trade_bots ON steam_trade_bots.id = steam_bot_items.botId WHERE app = 'RUST' AND steam_trade_bots.type = 'VAULT' ");

            for (let i in content.assets) {
                const asset = content.assets[i];
                const item = shopItems.find((item) => item.assetid == asset.assetid); //await this.modules.db.select("steam_shop_items", "assetid", asset.assetid);
                if (!item) throw new Error("Some of the items doesn't exist anymore!");
                if (!item.available || item.busy) throw new Error("You are trying to withdraw unavailable items!");
                if (item.amount < asset.amount) throw new Error("Some of the items you are trying to withdraw doesn't exist anymore!");

                totalItemsValue += item.price * asset.amount;

                if (!itemsBots[item.botId]) itemsBots[item.botId] = [];

                let withdrawItem = JSON.parse(JSON.stringify(item));
                withdrawItem.amount = asset.amount;
                itemsBots[item.botId].push(withdrawItem);
            }

            if (totalItemsValue != content.totalItemsValue) throw new Error("Prices are updated, please refresh your inventory!");


            const botIds = Object.keys(itemsBots);
            for (let i in botIds) {
                const botId = botIds[i];
                const bot = this.repositories.bots.list.find(el => el.id == botId);
                if (!bot || !bot.loggedIn) throw new Error("Some of the bots are offline now!");
            }


            totalItemsValue *= 10;
            await this.repositories.user.updateBalance({ way: 'OUT', userId: content.userId, amount: totalItemsValue, transactionType: 'WITHDRAW_STEAM_SKINS' });
            this.modules.logger.log("shop-market-withdrawals", `User Id #${content.userId} - balance deducted ${(totalItemsValue / 100).toFixed(2)} coins`);

            const now = moment().utc().unix();
            const transactionId = await this.modules.db.insert("INSERT INTO steam_trade_vault_mule_transactions SET ?", [{
                userId: content.userId,
                muleBotId: content.sourceMuleBot.id,
                createdAt: now,
                lastUpdate: now
            }]);
            if (!transactionId) this.modules.logger.log("shop-market-withdrawal-errors", `Transaction couldn't be created!`);

            for (let i in botIds) {
                const botId = botIds[i];
                let items = [];
                let botItemsValue = 0;
                let setItemsBusinessData = [];
                for (let j in itemsBots[botId]) {
                    const item = itemsBots[botId][j];
                    botItemsValue += (item.price * item.amount * 10);

                    const updateDbShopItemSuccess = await this.modules.db.exec("UPDATE steam_shop_items SET busy = 1 WHERE id = ?", [item.id]);
                    if (!updateDbShopItemSuccess) this.modules.logger.log("shop-market-items", `Item business couldn't be set to 1 -- Id: #${item.id}`);
                    items.push(item);
                    setItemsBusinessData.push({ assetid: item.assetid, amount: item.amount, busy: true });
                }
                this.repositories.redis.ioPublishChannel("steamtrader:shop", "steamtrader:shop:setItemsBusiness", setItemsBusinessData)

                const trackingId = shortid.generate();
                const offerData = {
                    botId: content.sourceMuleBot.id,
                    type: 'WITHDRAW',
                    targetBotId: botId,
                    muleState: 'VAULT',
                    app: content.app,
                    trackingId,
                    userId: content.userId,
                    tradeUrl: content.tradeUrl,
                    items,
                    totalItemsValue: botItemsValue,
                    bonusRatio: 0,
                    bonusAmount: 0,
                    overall: botItemsValue
                };
                const offerId = await this.createDbOffer(offerData);
                await this.modules.db.insert("INSERT INTO steam_trade_vault_mule_transaction_links SET ?", [{
                    transactionId,
                    offerId,
                    createdAt: now
                }])
                this.modules.logger.log("shop-market-withdrawals", `User Id #${content.userId} - trade has been created!`);

            }

            const updateTransactionSuccess = await this.modules.db.exec("UPDATE steam_trade_vault_mule_transactions SET state = 'ACTIVE' WHERE id = ?", [transactionId]);
            if (!updateTransactionSuccess) this.modules.logger.log("shop-market-withdrawal-errors", `Transaction ${transactionId} couldn't be updated!`);

            //send transaction id to user
            this.repositories.redis.ioPublishToUser(content.userId, "steamtrader:withdrawCallback", { transactionId });

            success = true;

            /*
            return this.repositories.redis.sendMessageToUser(content.userId, "message", {
                type: "info",
                msg: `Your trade request(s) has been placed in a queue! Please allow up to a few seconds to minute`
            });
            */

        } catch (err) {
            this.modules.logger.log("shop-market-withdrawals", `User Id #${content.userId} - trade couldn't be created!`);
            return this.repositories.redis.ioNotifyUser(content.userId, "error", `${err.message}`);
        } finally {
            release();
            this.repositories.redis.ioPublishToUser(content.userId, "steamtrader:requestResponse", success);
        }
    }

    async on_claimCoinflipWinnings(content) {
        const { roomId, botId, botSteamId, userId, steamId, tradeUrl } = content;

        let success = false;
        const release = await coinflipWithdrawMutex.acquire();
        try {
            const room = await this.modules.db.select("game_coinflip_rooms", "id", roomId);
            if (room.endPhase == 'DOUBLEDOWN') throw new Error("SOCKET_TRADING_COINFLIP_ALREADYDOUBLEDDOWN");
            if (room.winningsOfferId !== 0) {
                const lastWinningOffer = (await this.modules.db.query("SELECT requestState, steamState, lastUpdate FROM steam_trade_offers WHERE id = ?", [room.winningsOfferId]))[0];
                if (lastWinningOffer.steamState == 'ACTIVE') throw new Error("SOCKET_TRADING_COINFLIP_ALREADYACTIVE");
                if (lastWinningOffer.steamState == 'ACCEPTED') throw new Error("SOCKET_TRADING_COINFLIP_ALREADYACCEPTED");
                const timeElapsedFromLastOffer = moment().utc().unix() - lastWinningOffer.lastUpdate;
                const MIN_ELAPSION_TIME = 10 * 60;
                if (timeElapsedFromLastOffer < MIN_ELAPSION_TIME) throw new Error("SOCKET_TRADING_COINFLIP_WAITELAPSION");

            }
            const winnerItems = await this.repositories.coinflip.trading.getWinnersItems(roomId);
            const assets = await this.repositories.inventory.generateAssetsList({ targetSteamId: botSteamId, targetItems: winnerItems });
            const totalItemsValue = assets.reduce((sum, obj) => { sum += (obj.price * obj.amount); return sum; }, 0);

            const trackingId = shortid.generate();

            const offerData = {
                app: 'RUST',
                botId,
                type: 'WITHDRAW',
                target: 'COINFLIP',
                targetId: roomId,
                trackingId,
                userId,
                tradeUrl,
                pricingType: 'USD',
                items: assets,
                totalItemsValue,
                bonusRatio: 0,
                bonusAmount: 0,
                overall: totalItemsValue
            };

            const offerId = await this.createDbOffer(offerData);
            this.modules.logger.log("coinflip-withdrawals", `User Id #${content.userId} - trade has been created for room id ${roomId}!`);

            success = true;

            const updateSuccess = await this.modules.db.exec("UPDATE game_coinflip_rooms SET winningsOfferId = ?, endPhase = 'CLAIM' WHERE id = ?", [offerId, roomId]);
            //update it at end
        } catch (err) {
            this.modules.logger.log("coinflip-withdrawals", `User Id #${userId} - trade couldn't be created!`);
            return this.repositories.redis.ioNotifyUser(userId, "error", `${err.message}`);
        } finally {
            release();
            this.repositories.redis.ioPublishToUser(content.userId, "steamtrader:requestResponse", success);
        }
    }


    async on_doubledownCoinflip(content) {
        const { roomId, userId, color } = content;

        let success = false;
        const release = await coinflipWithdrawMutex.acquire();
        try {
            const room = await this.modules.db.select("game_coinflip_rooms", "id", roomId);
            if (room.endPhase !== 'AWAITING_CLAIM') throw new Error("SOCKET_TRADING_COINFLIP_ALREADYTRADEDONCE");

            let queueResult = { success: false };
            queueResult = await this.repositories.coinflip.queue.doubledown({
                roomId,
                ownerId: userId,
                ownerColor: color
            });
            if (!queueResult.success) throw new Error("SOCKET_COINFLIP_CREATIONERROR");



            this.modules.logger.log("coinflip-doubledowns", `User Id #${content.userId} - doubledown room has been created for room id ${roomId}!`);

            success = true;

            const updateSuccess = await this.modules.db.exec("UPDATE game_coinflip_rooms SET endPhase = 'DOUBLEDOWN' WHERE id = ?", [roomId]);
            //update it at end
        } catch (err) {
            this.modules.logger.log("coinflip-doubledown-errors", `User Id #${userId} - no doubledown`);
            return this.repositories.redis.ioNotifyUser(userId, "error", `${err.message}`);
        } finally {
            this.repositories.redis.ioPublishToUser(content.userId, "coinflip:doubledownResponse", success);
            release();
        }
    }



    async on_upgraderWithdrawItems(content) {
        
        const { userId, steamId, tradeUrl, assets, itemIds, botId, sourceMuleBot } = content;

        let success = false;
        const release = await withdrawMutex.acquire();
        try {


            const bot = this.repositories.bots.list.find(el => el.id == botId);
            if (!bot || !bot.loggedIn) throw new Error("SOCKET_TRADING_WITHDRAW_BOTOFFLINE");

            const shopItems = await this.modules.db.query("SELECT steam_bot_items.* FROM steam_bot_items INNER JOIN steam_trade_bots ON steam_trade_bots.id = steam_bot_items.botId WHERE app = 'RUST' AND steam_trade_bots.type = 'VAULT' ");
            
            let totalItemsValue = 0;
            let setItemsBusinessData = [];
            for (let i in assets) {
                const asset = content.assets[i];
                const item = shopItems.find((item) => item.assetid == asset.assetid);
                if (!item) throw new Error("Some of the items doesn't exist anymore!");
                if (!item.available || item.busy) throw new Error("You are trying to withdraw unavailable items!");
                if (item.amount < asset.amount) throw new Error("Some of the items you are trying to withdraw doesn't exist anymore!");
                totalItemsValue += (item.price * asset.amount * 10);
                setItemsBusinessData.push({ assetid: item.assetid, amount: asset.amount, busy: true });
            }
            totalItemsValue = Math.floor(totalItemsValue * 1.035);

            const updateItemStatesSql = await this.modules.db.call("upgrader_setItemStates(?,?)", [itemIds.join(','), 'IN_OFFER']);
            if (!updateItemStatesSql.success) throw new Error("API_GAME_UPGRADER_ITEMSNOTAVAILABLE");

            for (let i in assets) {
                const asset = content.assets[i];
                const updateDbShopItemSuccess = await this.modules.db.exec("UPDATE steam_shop_items SET busy = 1 WHERE id = ?", [asset.id]);
                if (!updateDbShopItemSuccess) this.modules.logger.log("upgrader-withdrawals-errors", `Item business couldn't be set to 1 -- Id: #${asset.id}`);
            }

            this.repositories.redis.ioPublishChannel("steamtrader:shop", "steamtrader:shop:setItemsBusiness", setItemsBusinessData)


            const now = moment().utc().unix();
            const transactionId = await this.modules.db.insert("INSERT INTO steam_trade_vault_mule_transactions SET ?", [{
                userId,
                muleBotId: sourceMuleBot.id,
                createdAt: now,
                lastUpdate: now
            }]);
            if (!transactionId) this.modules.logger.log("shop-market-withdrawal-errors", `Transaction couldn't be created!`);



            const trackingId = shortid.generate();
            const offerData = {
                botId: sourceMuleBot.id,
                type: 'WITHDRAW',
                targetBotId: botId,
                muleState: 'VAULT',
                app: 'RUST',
                target: 'UPGRADER',
                trackingId,
                userId,
                tradeUrl,
                items: assets,
                totalItemsValue,
                bonusRatio: 0,
                bonusAmount: 0,
                overall: totalItemsValue
            };
            const offerId = await this.createDbOffer(offerData);
            await this.modules.db.insert("INSERT INTO steam_trade_vault_mule_transaction_links SET ?", [{
                transactionId,
                offerId,
                createdAt: now
            }])
            this.modules.logger.log("upgrader-withdrawals", `User Id #${content.userId} - trade has been created!`);

            for (let i in itemIds) {
                const inventoryItemId = itemIds[i];
                const updateInventoryItemSuccess = await this.modules.db.exec("UPDATE game_upgrader_user_inventory SET linkedTransactionId = ? WHERE id = ?", [transactionId, inventoryItemId]);
                if (!updateInventoryItemSuccess) this.modules.logger.log("upgrader-withdrawals-errors", `Inventory item couldn't be linked to offer id ${offerId}-- Item id: #${inventoryItemId}`);
            }

            const updateTransactionSuccess = await this.modules.db.exec("UPDATE steam_trade_vault_mule_transactions SET state = 'ACTIVE' WHERE id = ?", [transactionId]);
            if (!updateTransactionSuccess) this.modules.logger.log("shop-market-withdrawal-errors", `Transaction ${transactionId} couldn't be updated!`);

            this.repositories.redis.ioPublishToUser(userId, "steamtrader:withdrawCallback", { transactionId });
            success = true;

        } catch (err) {
            console.log(err.name)
            console.log(err.stack)
            this.modules.logger.log("upgrader-withdrawal-errors", `User Id #${content.userId} - trade couldn't be created! `);
            return this.repositories.redis.ioNotifyUser(userId, "error", `${err.message}`);
        } finally {
            release();
            this.repositories.redis.ioPublishToUser(userId, "steamtrader:requestResponse", success);
        }
    }


}