const Queue = require('bee-queue');
const redisOptions = {
    redis: {
        host: '127.0.0.1',
    }
};

const backendQueue = new Queue('CORESERVER-COINFLIP', redisOptions);

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async emit(header, data) {
    try {
    const job = await backendQueue.createJob({ header, data }).timeout(15 * 1000).save();
    return await new Promise(function (resolve, reject) {
      job.on('succeeded', (result) => resolve(result));
      job.on('error', (err) => resolve({success: false}));
    });

    } catch(err) {

    }
}
async createDbRoom(params) {
  const res = await this.emit('coinflip:createDbRoom', params);
  return res;
}
async joinDbRoom(params) {
  return await this.emit('coinflip:joinDbRoom', params);
}

async doubledown(params) {
  return await this.emit('coinflip:doubledown', params);
}

  async noticeTradeCompleted(params) {
    return await this.emit('coinflip:noticeTradeCompleted', params);
  }


}