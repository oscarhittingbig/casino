module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      TAX_RATIO: 0.05, //7.5%
      TAX_RATIO_WITH_NAME: 0.00
    }

    this.testFunc();
  }

  async testFunc() {
   //await this.updateTotalSkinsValue(10);
  }

  async getItemsInRoom(roomId) {
    const items = await this.modules.db.query("SELECT * FROM game_coinflip_room_items WHERE roomId = ? ORDER BY id ASC", [roomId]);
    return items;
  }

  tax(items, userHasTag) {
    const totalValue = items.reduce((sum, obj) => { sum += (obj.value * obj.amount); return sum;}, 0);
    const expectedTaxAmount = Math.floor(totalValue *  (userHasTag ? this.defs.TAX_RATIO_WITH_NAME : this.defs.TAX_RATIO ));
    //console.log('Total skins value:', totalValue / 100, 'Expected tax value:', expectedTaxAmount / 100)
    let collectedTaxAmount = 0;
    let taxItems = {};
    items.sort((a, b) => { return b.value - a.value; }).map(item => {
      const itemKey = item.market_hash_name;
      const itemValue = item.value;
      const itemAmount = item.amount;
      for (let i = 0;i < itemAmount;i++) {
          if (collectedTaxAmount + itemValue > expectedTaxAmount) continue;

          if (taxItems[itemKey]) taxItems[itemKey].amount++;
          else taxItems[itemKey] = { ...item, amount: 1 };
          item.amount--;
          
          collectedTaxAmount += itemValue;
      }
    });
    const itemsAfterTaxObj = items.filter(el => el.amount > 0).reduce((obj, el) => { if (obj[el.market_hash_name]) obj[el.market_hash_name].amount += el.amount; else obj[el.market_hash_name] = el; return obj; }, {});
    const itemsAfterTax = Object.keys(itemsAfterTaxObj).reduce((arr, key) => { arr.push(itemsAfterTaxObj[key]); return arr; }, []);
    
    //console.log('collected tax', collectedTax / 100)
    taxItems = Object.keys(taxItems).reduce((arr, key) => { arr.push(taxItems[key]); return arr;}, []);
    return {  taxItems, itemsAfterTax, collectedTaxAmount, totalSkinsValueWithTax: (totalValue - collectedTaxAmount) };
  }

  async getWinnersItems(roomId) {
    const items = await this.getItemsInRoom(roomId);
    const { itemsAfterTax } = this.tax(items);
    return itemsAfterTax;
  }

  async updateTotalSkinsValue(roomId) {
    /*
    const items = [ 
      { market_hash_name: 'Multicam Jacket', value: 5, amount: 10 },
      { market_hash_name: 'Antique Metal Door', value: 100, amount: 3 },
      { market_hash_name: 'Spacesuit', value: 2506, amount: 2 },
     ];
     */
    const items = await this.getItemsInRoom(roomId);
    const { taxItems, itemsAfterTax, collectedTaxAmount, totalSkinsValueWithTax } = this.tax(items);
    //console.log('All items:', items);
    //console.log('Tax Items (taken):', taxItems, 'Remaining items after tax:', itemsAfterTax, 'Collected tax amount:', collectedTaxAmount, 'Total skins value:', totalSkinsValueWithTax)
    
    //taxlanmış ve taxlanmmaış itemler burada ayılrsın
    //databasede taxlanmış itemları etiketle, belki itemler için özel state yapılabilir
    //taxlanacak eşyalar awaiting veya zaten alınmış itemlar taxed olabilir
    //itemsların her biri güncellensin o zaman, kullanıcıda olan etikete göre de olabilir
    //ama eğer room doubledown değilse tabi alınacak
    await this.modules.db.exec("UPDATE game_coinflip_rooms SET collectedTaxAmount = ?, totalSkinsValueWithTax = ? WHERE id = ?", [collectedTaxAmount, totalSkinsValueWithTax, roomId]);
  }


}