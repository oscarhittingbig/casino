const axios = require('axios');

module.exports = class {
    
    constructor(params) {
        params.inject(this);

        this.defs = {
            MIN_DEPOSIT: {
                'RUST': 5, //0.05
                'CSGO': 10, //0.1
                'DOTA2': 10
            }
        }
        

        /*
        setTimeout(() => {
           this.get({app: 'DOTA2', steamId: "76561198881065094", isBot: false})
        }, 2500)
        */
        /*
        setTimeout(() => {
            this.generateAssetsList({ targetSteamId: '76561198212734111', targetItems: [
                { market_hash_name: 'Multicam Jacket', amount: 3 }
            ]});
        }, 1000);
        */
    }

    async generateAssetsList({app = 'RUST', targetSteamId, targetItems}) {
        let assets = [];
        let currentAssetsAmount = {};
        const botInventoryItems = await this.get({app, steamId: targetSteamId, isBot: false});
        for (let i in targetItems) {
            const item = targetItems[i];
            const expectedAmount = item.amount;
            const targetAssets = botInventoryItems.filter(el => el.market_hash_name == item.market_hash_name && el.available);
           
            for (let j in targetAssets) {
                const currentAssetAmount = currentAssetsAmount[item.market_hash_name] || 0;
                const requiredAmount = expectedAmount - currentAssetAmount;
                if (requiredAmount <= 0) break;
                const targetAsset = targetAssets[j];
                let takenAmount = targetAsset.amount;
                if (takenAmount > requiredAmount) takenAmount = requiredAmount;
                if (currentAssetsAmount[item.market_hash_name]) currentAssetsAmount[item.market_hash_name] += takenAmount;
                else currentAssetsAmount[item.market_hash_name] = takenAmount;
                assets.push({ ...targetAsset, amount: takenAmount });
            }

            const takenAmount = currentAssetsAmount[item.market_hash_name] || 0;
            if (expectedAmount !== takenAmount) throw new Error("SOCKET_TRADING_COINFLIP_ASSETAMOUNTSARENOTEQUAL");
        }
        return assets;
    }

    checkItemAvailability({app, item, totalItemAmounts, overstockedItems, price, isBot}) {
        let available = true;
        let denialReason = '';
        if (!item.tradable) {
            available = false;
            denialReason = 'Not Tradable';
        }
        if (this.repositories.pricing.blacklistedItems[app] && this.repositories.pricing.blacklistedItems[app][item.market_hash_name]) {
            available = false;
            denialReason = 'Blacklisted';
        }
        if ( price <= 0 || (price < this.defs.MIN_DEPOSIT[app] && !isBot)) {
            available = false;
            denialReason = 'Low Price';
        }
        if (overstockedItems[item.market_hash_name]) {
            available = false;
            denialReason = 'Overstocked';
        }
        else if (!isBot) {
            const maxItemCount = (this.repositories.pricing.overstocks[app] && this.repositories.pricing.overstocks[app][item.market_hash_name]) || 15;

            const itemCountInMarket = (this.repositories.pricing.marketItems[app] && this.repositories.pricing.marketItems[app][item.market_hash_name]) || 0;
            const remainingCount = maxItemCount - itemCountInMarket;
          
            if (remainingCount <= 0) {
                available = false;
                denialReason = 'Overstocked';
                overstockedItems[item.market_hash_name] = true;
            } else if (totalItemAmounts[item.market_hash_name] >= remainingCount) {
                available = false;
                denialReason = 'Overstocked';
                overstockedItems[item.market_hash_name] = true;
            } else if (item.amount > remainingCount) {
                item.amount = remainingCount;
                overstockedItems[item.market_hash_name] = true;
            }
            totalItemAmounts[item.market_hash_name] = parseInt(totalItemAmounts[item.market_hash_name]) + parseInt(item.amount);
        }
        return { available, denialReason };
    }

    async get({app, steamId, isBot}) {
        const { appId, contextId } = this.repositories.steam.apps[app];
        if (!this.repositories.pricing.isAvailable(app)) throw new Error("Price list is not available at the moment! Please try again later.");
        const response = await axios.get(`https://api.steamapis.com/steam/inventory/${steamId}/${appId}/${contextId}?api_key=${process.env.STEAMAPIS_API_KEY}`, {timeout: 15000}).catch(err => {
        throw new Error("User inventory couldn't be fetched!");
        });
     
        let items = [];
        if (response.data.total_inventory_count == 0) return items;

        const descriptions = response.data.descriptions.reduce((map, obj) => {
            map[obj.classid] = obj;
            return map;
        }, {});
        let assets = response.data.assets;
 
        let totalItemAmounts = {};
        let overstockedItems = {};
        for (let i in assets) {
            const asset = assets[i];
            const item = descriptions[asset.classid];
            if (!isBot && !item.tradable) continue;
            item.amount = asset.amount;
            const price = this.repositories.pricing.getPrice({app, market_hash_name: item.market_hash_name, isOurItem: isBot});
            if (!totalItemAmounts.hasOwnProperty(item.market_hash_name)) totalItemAmounts[item.market_hash_name] = 0;

            const {available, denialReason} = this.checkItemAvailability({app, item, totalItemAmounts, overstockedItems, price, isBot});

            items.push({
                assetid: asset.assetid,
                amount: parseInt(item.amount),
                market_hash_name: item.market_hash_name,
                image: item.icon_url,
                name_color: item.name_color.replace("#", ''),
                price,
                available,
                denialReason
            });
        }
        return items;
    
    }

    async getUserInventoryData({app, userId, steamId}) {
        const cachedData = await this.repositories.redis.get(`STEAM_USER_INVENTORY_${app}_${userId}`);
        if (cachedData) return JSON.parse(cachedData);

        const items = await this.get({app, steamId, isBot:false });
        //const hasUserDomain = await this.repositories.steam.hasUserDomain(steamId);
        const inventoryData = {
            items,
            //bonusRatio: hasUserDomain ? this.repositories.pricing.defs.BONUS.RATIO : 0
        };
        await this.repositories.redis.set(`STEAM_USER_INVENTORY_${app}_${userId}`, 10, JSON.stringify(inventoryData));
        return inventoryData;
    }
   
}