const axios = require("axios");

module.exports = class {

    constructor(params) {
        params.inject(this);
    }

    async on_requestInventory(content) {
        try {
            const inventoryData = await this.repositories.inventory.getUserInventoryData({app: content.app, userId: content.userId, steamId: content.steamId});
            this.repositories.redis.ioPublishToUser(content.userId, "trading:steam:requestInventoryResponse", inventoryData);
        } catch (err) {
            this.repositories.redis.ioNotifyUser(content.userId, "error", "SOCKET_TRADING_STEAM_REQUSETINVENTORYRESPONSE_ERROR");
        }
    }
}