const axios = require("axios");

module.exports = class {

    constructor(params) {
        params.inject(this);
    }

    async getItems(offerId) {
       return await this.modules.db.query("SELECT * FROM steam_trade_offer_items WHERE offerId = ? ORDER BY id ASC", [offerId]);
    }
}