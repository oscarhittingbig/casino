const axios = require('axios');

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.defs = {
            THREAD: {
                INTERVAL: 1000
            },
            FETCH: {
                INTERVAL: 4 * 60 * 60 * 1000,
            },
            BONUS: {
                RATIO: 0.05 //percentage
            }
        }
        this.prices = null;
        this.blacklistedItems = {};
        this.manualPrices = {};
        this.marketItems = {};
        this.overstocks = {};
        this.latestFetch = {};
        this.init();
    }

    isAvailable(app) {
        return this.prices[app];
    }
    async getBlacklisted() {
        const appsItems = (await this.modules.db.query("SELECT app, market_hash_name FROM steam_trade_blacklisted")).reduce((obj, el) => { if (!obj[el.app]) obj[el.app] = {}; obj[el.app][el.market_hash_name] = true; return obj; }, {})
        this.blacklistedItems = appsItems;
    }
    async getManualPrices() {
        const appsItems = (await this.modules.db.query("SELECT app, market_hash_name, price FROM steam_manual_prices")).reduce((obj, el) => { if (!obj[el.app]) obj[el.app] = {}; obj[el.app][el.market_hash_name] = el.price; return obj; }, {})
        this.manualPrices = appsItems;
    }
    async getMarketItems() {
        const appsItems = (await this.modules.db.query("SELECT SUM(amount) as amount, market_hash_name, app FROM `steam_bot_items` INNER JOIN steam_trade_bots ON steam_trade_bots.id = steam_bot_items.botId WHERE steam_trade_bots.type != 'COINFLIP' ")).reduce((obj, el) => { 
            if (!obj[el.app]) obj[el.app] = {}; 
            if (!obj[el.app][el.market_hash_name]) obj[el.app][el.market_hash_name] = el.amount;
            else obj[el.app][el.market_hash_name] += el.amount;
            return obj;
         }, {})
        this.marketItems = appsItems;
    }
    async getOverstocks() {
        const appsItems = (await this.modules.db.query("SELECT app, market_hash_name, maxCount FROM steam_trade_overstocks")).reduce((obj, el) => { if (!obj[el.app]) obj[el.app] = {}; obj[el.app][el.market_hash_name] = el.maxCount; return obj; }, {})
        this.overstocks = appsItems;
    }
    async init() {
        this.prices = {};
        await this.getBlacklisted();
        await this.getManualPrices();
        await this.getMarketItems();
        await this.getOverstocks();



        const apps = Object.keys(this.repositories.steam.apps);
        for (let i in apps) {
            const app = apps[i];
            this.loadCache(app);
            if (!this.prices[app]) await this.fetch(app);
        }
    }

    loadCache(app) {
        const cache = this.modules.cache.fileGet(`steamapis-prices-${app}`);
        if (Array.isArray(cache)) return;
        this.prices[app] = cache.prices;
        this.latestFetch[app] = cache.latestFetch;
    }
    saveCache(app) {
        this.latestFetch[app] = Date.now();
        this.modules.cache.fileSet(`steamapis-prices-${app}`, { prices: this.prices[app], latestFetch: this.latestFetch[app] });
    }

    async fetch(app) {
        const { appId, contextId } = this.repositories.steam.apps[app];
        const response = await axios.get(`https://api.steamapis.com/market/items/${appId}?api_key=${process.env.STEAMAPIS_API_KEY}`).catch(err => { console.log(err); return null; });
        if (!response || !response.data || !Array.isArray(response.data.data) || response.data.data.length == 0) return;

        const items = response.data.data;
        let prices = {};
        items.forEach(item => {
            prices[item.market_hash_name] = {
                price: Number(item.prices.safe_ts.last_7d) == 0 ? (Number(item.prices.safe_ts.last_30d)).toFixed(2) : (Number(item.prices.safe_ts.last_7d)).toFixed(2),
                name_color: item.border_color
            }
        });
        this.prices[app] = prices;
        this.saveCache(app);
    }

    getPrice({app, market_hash_name, isOurItem }) {
        if (!this.prices[app][market_hash_name]) return 0;

        let price = parseInt(this.prices[app][market_hash_name].price * 100);

        if (this.manualPrices[app] && this.manualPrices[app][market_hash_name]) price = this.manualPrices[app][market_hash_name];

        if (isOurItem) {
            if (price < 500) price *= 1.15;
            else price *= 1.10;
        }
        else {
            switch (app) {
                case 'RUST': price *= 1; break;
                case 'CSGO': price *= 0.8625; break;
                case 'DOTA2': price *= 0.8625; break;
            }
            price = price < 100 ? price * 0.5 : price;
        }

        return Math.floor(price);
    }

}