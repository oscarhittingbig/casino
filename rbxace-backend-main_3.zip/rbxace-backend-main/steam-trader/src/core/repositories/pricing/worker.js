const axios = require('axios');

module.exports = class {
    
    constructor(params) {
        params.inject(this);

        this.defs = {
            THREAD: {
                INTERVAL: 1000
            },
            FETCH: {
                INTERVAL: 4 * 60 * 60 * 1000,
            }
        }
        this.replayThread();     
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            const apps = Object.keys(this.repositories.steam.apps);
            for (let i in apps) {
                const app = apps[i];
                const now = Date.now();
                if (now < this.repositories.pricing.latestFetch[app] + this.defs.FETCH.INTERVAL) continue;
                await this.repositories.pricing.fetch(app);
            }
     
        } catch(err) {
            this.modules.logger.log("repositories-prices-worker-mainThread", err.name);
            this.modules.logger.log("repositories-prices-worker-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }
   
}