const axios = require('axios');

module.exports = class {

    constructor(params) {
        params.inject(this);
        this.proxyListUnique = [];
        this.vaultProxies = [];
        this.muleProxies = [];
        
    }
    async init() {
        await this.storeProxyList();
    }

    async retrieveProxyList() {
        const response = await axios.get("https://proxy.webshare.io/api/proxy/list", { 'headers': { 'Authorization': "Token " + process.env.WEBSHARE_API_KEY } });
        return response.data.results;
    }

    async storeProxyList() {
        const proxies = await this.retrieveProxyList();
        let temp = [];
        proxies.map((proxy) => {
            if (proxy.valid) {
                temp.push(`http://${proxy.username}:${proxy.password}@${proxy.proxy_address}:${proxy.ports.http}`);
            }
        })
        this.proxyList = temp;
        this.proxyListUnique = JSON.parse(JSON.stringify(this.proxyList));
        const halfOffset = Math.floor(this.proxyListUnique.length) - 1;
        for (let i = 0;i < this.proxyListUnique.length;i++) {
            const proxy = this.proxyListUnique[i]
            if (i <= halfOffset) this.vaultProxies.push(proxy)
            else this.muleProxies.push(proxy)
        }
    }

    getProxy(isVault) {
        if (this.proxyListUnique.length > 0) {
            const randomProxyOffset = Math.floor(Math.random() * (isVault ? this.vaultProxies.length : this.muleProxies.length) );
            const proxy = isVault ? this.vaultProxies[randomProxyOffset] : this.muleProxies[randomProxyOffset];
            return proxy;
        } else {
            return false;
        }
    }

}