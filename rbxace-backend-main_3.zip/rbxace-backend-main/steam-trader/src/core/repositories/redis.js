const redis = require("redis");
const client = redis.createClient();
const publisher = redis.createClient();
const subscriber = redis.createClient();

async function get(key) {
    return await new Promise(function (resolve, reject) {

        client.get(key, function (err, reply) {
            if (err) {
                reject(err);
            } else {
                resolve(reply);
            }
        });

    });
}

async function setex(key, expire, val) {
    return await new Promise(function (resolve, reject) {

        client.setex(key, expire, val, function (err, reply) {
            if (err) {
                reject(err);
            } else {
                resolve(reply);
            }
        });

    });
}

module.exports = class {
    constructor(params) {
        params.inject(this);
        this.init();
    }

    init() {
        subscriber.on("message", (channel, messageJson) => {
            let message = JSON.parse(messageJson);
            this.messageHandler(channel, message.header, message.content);
        });

        subscriber.subscribe("steam-trader");
    }


    get client() {
        return client;
    }
    async get(key) {
        try {
            return await get(key);
        } catch (err) {
            return null;
        }
    }
    async set(key, expire, val) {

        let res = await setex(key, expire, val);
        if (res == 'OK') return true;
        else throw new Error(`Redis setex failed! - ${res}`)

        //client.setex(key, expire, val);
    }


    messageHandler(channel, header, content) {

        switch (header) {

            case "requestInventory":
                this.repositories.inventory.redis.on_requestInventory(content);
                break;

            case "requestDeposit":
                this.repositories.bots.redis.on_requestDeposit(content);
                break;

            case "requestWithdraw":
                this.repositories.bots.redis.on_requestWithdraw(content);
                break;

            case "claimCoinflipWinnings":
                this.repositories.bots.redis.on_claimCoinflipWinnings(content);
                break;


            case "doubledownCoinflip":
                this.repositories.bots.redis.on_doubledownCoinflip(content);
                break;

            case "upgraderWithdrawItems":
                this.repositories.bots.redis.on_upgraderWithdrawItems(content);
                break;
        }
    }

    publish(channel, header, obj) {
        let message = { header: header, content: obj, sender: process.pid };
        let messageJson = JSON.stringify(message);
        publisher.publish(channel, messageJson);
    }

    sendMessageToUser(userId, type, data) {
        this.publish("web-workers", "sendMessageToUser", { userId, type, data });
    }
    sendMessageToChannel(channel, type, data) {
        this.publish("web-workers", "sendMessageToChannel", { channel, type, data });
    }

    ioPublish(type, data) {
        this.modules.io.to("global").emit(type, data);
    }

    ioPublishChannel(channel, type, data) {
        this.modules.io.to(channel).emit(type, data);
    }

    ioPublishToUser(userId, type, data) {
        this.modules.io.to("user-" + userId).emit(type, data);
    }

    async ioNotifyUser(userId, type = 'info', message, messageParameters) {
        this.ioPublishToUser(userId, 'user:notify', { message, type, messageParameters });
    }
}