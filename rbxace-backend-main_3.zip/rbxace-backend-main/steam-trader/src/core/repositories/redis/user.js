module.exports = class {

    constructor(params) {
        params.inject(this);
    }

    async updateBalance(userId, value) {
        this.repositories.redis.ioPublishToUser(userId, 'user:updateBalance', { value, time: Date.now() });
    }
}