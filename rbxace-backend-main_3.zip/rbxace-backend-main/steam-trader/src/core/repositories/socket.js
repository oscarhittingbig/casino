module.exports = class {

    constructor(params) {
        params.inject(this);
    }

    async updateBalance({way, userId, amount, transactionType, alterType, alterName}) {
        const sql = await this.modules.db.call(`${way == 'IN' ? "user_increaseBalance" : "user_decreaseBalance"}(?, ?, ?, ?, ?)`, [userId, amount, transactionType, alterType || '', alterName || '']);
        if (!sql.success) {
            if (way == 'IN') return false;
            else throw new Error("Insufficient balance!");
        }
        this.repositories.redis.user.updateBalance(userId, sql.params.newBalance);
        return true;
    }

}