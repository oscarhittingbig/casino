const axios = require("axios");

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.apps = {
            'RUST': {
                appId: 252490,
                contextId: 2
            },
            /*
            'CSGO': {
                appId: 730,
                contextId: 2
            },
            'DOTA2': {
                appId: 570,
                contextId: 2
            }
            */
        }
        //this.hasUserDomainAndFavorited("76561198166185720")
    }
    cloneApps() {
        const apps = Object.keys(this.apps);
        let obj = {};
        apps.forEach(app => obj[app] = {} );
        return obj;
    }
    async hasUserDomain(steamId) {
        const res = await axios.get(`https://api.steamapis.com/steam/profile/${steamId}?api_key=${process.env.STEAMAPIS_API_KEY}`).catch(err => {
            throw new Error("Couldn't connect to steamapis!");
        })
        if (!res || !res.data || !res.data.name) throw new Error("Something went wrong while checking your profile!");
        const username = res.data.name;
        return String(username).toUpperCase().includes("#RUSTYSALOON");
    }
}