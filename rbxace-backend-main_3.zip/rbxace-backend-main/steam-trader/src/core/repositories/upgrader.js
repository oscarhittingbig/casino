const moment = require('moment');
module.exports = class {

    constructor(params) {
        params.inject(this);
    }

    async addItemsToUserInventory(userId, items) {
        let newItems = [];
        for (let i in items) {
            const item = items[i];
            for (let j = 0; j < item.amount; j++) {
                const itemData = {
                    userId,
                    app: item.app,
                    market_hash_name: item.market_hash_name,
                    image: item.image,
                    price: item.price,
                    createdAt: moment().utc().unix()
                };

                const insertSuccess = await this.modules.db.exec("INSERT INTO game_upgrader_user_inventory SET ?", [itemData])
                if (!insertSuccess) this.modules.logger.log("upgrader-inventory-errors", `${userId} -- Item couldn't be added!`);
                else newItems.push(itemData);
            }
        }
        this.repositories.redis.ioPublishToUser(userId, 'upgrader:pushItems', newItems);



    }

    async refundFailedOffer(dbOffer) {
       // const updateSuccess = await this.modules.db.exec("UPDATE game_upgrader_user_inventory SET state = 'SOLD_FORCE' WHERE state = 'IN_OFFER' AND linkedTransactionId = ?", [dbOffer.id]);
       // if (updateSuccess) {
            const updateBalanceSuccess = await this.repositories.user.updateBalance({ way: 'IN', userId: dbOffer.userId, amount: dbOffer.overall, transactionType: 'UPGRADER_SELL_ITEMS_FORCE' });
            if (!updateBalanceSuccess) this.modules.logger.log("bot-upgrader-offer-errors", `${dbOffer.id} -- user's balance couldn't be increased`);
        // }

        for (let i in dbOffer.items) {
            const item = dbOffer.items[i];
            const itemUpdateBusinessSuccess = await this.modules.db.exec("UPDATE steam_bot_items SET busy = 0 WHERE assetid = ?", [item.assetid]);
            if (!itemUpdateBusinessSuccess) this.modules.logger.log("bot-item-business-errors", `${item.assetid} -- couldnt set to 0`);
        }
    }

}