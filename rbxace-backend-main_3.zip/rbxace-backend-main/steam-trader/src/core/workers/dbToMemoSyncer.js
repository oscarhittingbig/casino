const moment = require('moment');

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.defs = {
            THREAD: {
                INTERVAL: 30 * 1000
            }
        }
        this.replayThread();
    }
    async init() {
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            await this.sync();
        } catch (err) {
            this.modules.logger.log("worker-dbToMemoSyncer-mainThread", err.name);
            this.modules.logger.log("worker-dbToMemoSyncer-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async sync() {
        await this.repositories.pricing.getBlacklisted();
        await this.repositories.pricing.getManualPrices();
        await this.repositories.pricing.getMarketItems();
        await this.repositories.pricing.getOverstocks();
    }

}