const moment = require('moment');

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.defs = {
            THREAD: {
                INTERVAL: 10 * 1000
            }
        }
        this.mainThread();
    }
    async init() {
    }

    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            await this.handleRefunds();
        } catch (err) {
            this.modules.logger.log("worker-refunder-mainThread", err.name);
            this.modules.logger.log("worker-refunder-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async handleRefunds() {
        const expirationAfter = moment().utc().unix() - (1 * 1);
        const dbOffers = await this.modules.db.query("SELECT * FROM steam_trade_offers WHERE type = 'WITHDRAW' AND target = 'BALANCE' AND (requestState = 'FAILED' OR requestState = 'CREATED') AND ( (requestState = 'FAILED' AND steamState IS NULL) OR (steamState != 'ACTIVE' AND steamState != 'IN_ESCROW' AND steamState != 'CREATED_NEEDS_CONFIRMATION' AND steamState != 'ACCEPTED' AND steamState != 'COUNTERED')) AND refunded = 0 AND lastUpdate <= ?", [expirationAfter]);
        for (let i in dbOffers) {
            const dbOffer = dbOffers[i];
            const updateSuccess = await this.modules.db.exec("UPDATE steam_trade_offers SET refunded = 1 WHERE id = ?", [dbOffer.id]);
            if (!updateSuccess) throw new Error("Something went wrong while updating db offer!");

            //update item business
            const dbOfferItems = await this.modules.db.query("SELECT * FROM steam_trade_offer_items WHERE offerId = ?", [dbOffer.id]);
            let setItemsBusinessData = []; 
            for (let j in dbOfferItems) {
                const dbOfferItem = dbOfferItems[j];
                const updateOfferItemSuccess = await this.modules.db.exec("UPDATE steam_shop_items SET busy = 0 WHERE assetid = ?", [dbOfferItem.assetid]);
                if(!updateOfferItemSuccess) this.modules.logger.log("bot-item-business", `${dbOfferItem.assetid} -> couldn't set busy 0`)
                else setItemsBusinessData.push({assetid: dbOfferItem.assetid, amount: dbOfferItem.amount, busy: false});
            }
            this.repositories.redis.ioPublishChannel("steamtrader:shop", "steamtrader:shop:setItemsBusiness", setItemsBusinessData)

            const increaseBalanceSuccess = await this.repositories.user.updateBalance({way: 'IN', userId: dbOffer.userId, amount: dbOffer.overall, transactionType: 'REFUND_WITHDRAW_STEAM_SKINS' });
            if (increaseBalanceSuccess) {
                this.modules.logger.log("offers-refunds", `Offer Id #${dbOffer.id} -- successfully refunded to user id #${dbOffer.userId} with amount ${(dbOffer.overall / 100).toFixed(2)} coins!`)
                this.repositories.redis.ioPublishToUser(dbOffer.userId, "steamtrader:refunded", {amount:dbOffer.overall});
            }
            else this.modules.logger.log("offers-refunds", `Offer Id #${dbOffer.id} -- couldn't be refunded to user id #${dbOffer.userId}!`);
        }
    }

}