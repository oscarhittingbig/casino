const moment = require('moment');
const axios = require('axios');
const shortid = require('shortid32');

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.defs = {
            THREAD: {
                INTERVAL: 1 * 2 * 1000
            }
        }

        this.mainThread();
    }


    replayThread() {
        setTimeout(this.mainThread.bind(this), this.defs.THREAD.INTERVAL)
    }

    async mainThread() {
        try {
            await this.handleActiveWithdrawTransactions();
        } catch (err) {
            this.modules.logger.log("repositories-bot-transferWorker-mainThread", err.name);
            this.modules.logger.log("repositories-bot-transferWorker-mainThread", err.stack);
        } finally {
            this.replayThread();
        }
    }

    async setTransactionState(id, newState) {
        const updateTransactionStateSuccess = await this.modules.db.exec("UPDATE steam_trade_vault_mule_transactions SET state = ? WHERE id = ?", [newState, id]);
        if (!updateTransactionStateSuccess) this.modules.logger.log("withdraw-transaction-worker-errors", `Transaction state couldn't be set! ${id} - ${newState}`);
    }


    async generateAssetsList(sourceItems, targetItems) {
        let assets = [];
        let currentAssetsAmount = {};

        for (let i in targetItems) {
            const item = targetItems[i];
            const expectedAmount = item.amount;
            const targetAssets = sourceItems.filter(el => el.market_hash_name == item.market_hash_name);
            for (let j in targetAssets) {
                const currentAssetAmount = currentAssetsAmount[item.market_hash_name] || 0;
                const requiredAmount = expectedAmount - currentAssetAmount;
                if (requiredAmount <= 0) break;
                const targetAsset = targetAssets[j];
                let takenAmount = targetAsset.amount;
                if (takenAmount > requiredAmount) takenAmount = requiredAmount;
                if (currentAssetsAmount[item.market_hash_name]) currentAssetsAmount[item.market_hash_name] += takenAmount;
                else currentAssetsAmount[item.market_hash_name] = takenAmount;
                assets.push({ ...targetAsset, amount: takenAmount });
            }

            const takenAmount = currentAssetsAmount[item.market_hash_name] || 0;

            if (expectedAmount !== takenAmount) throw new Error("ASSETAMOUNTSARENOTEQUAL");
        }
        return assets;
    }

    async getFinalizedMuleTransactions(activeTransactions) {
        let finalizedMuleTransactions = {};
        for (let j in activeTransactions) {
            const activeTransaction = activeTransactions[j];
            activeTransaction.links = await this.modules.db.query("SELECT offerId, state FROM steam_trade_vault_mule_transaction_links WHERE transactionId = ? ORDER BY id ASC", [activeTransaction.id]);
            activeTransaction.finalized = activeTransaction.links.filter(link => link.state == 'ACTIVE').length == 0;
            activeTransaction.success = activeTransaction.links.filter(link => link.state == 'COMPLETED').length == activeTransaction.links.length;

            if (activeTransaction.finalized) {
                if (activeTransaction.success) {
                    const targetObj = finalizedMuleTransactions[activeTransaction.muleBotId];
                    if (targetObj) targetObj.push(activeTransaction);
                    else finalizedMuleTransactions[activeTransaction.muleBotId] = [activeTransaction];
                } else {
                    for (let k in activeTransaction.links) {
                        const transactionLink = activeTransaction.links[k];
                        if (transactionLink.state == 'FAILED') continue;
                        const dbOffer = await this.modules.db.select("steam_trade_offers", "id", transactionLink.offerId);
                        if (dbOffer.target == 'BALANCE') {
                            const updateOffer = await this.modules.db.exec("UPDATE steam_trade_offers SET requestState = 'FAILED', steamState = 'FAILED' WHERE id = ?", [dbOffer.id]);
                        } else if (dbOffer.target == 'UPGRADER') {
                            await this.repositories.upgrader.refundFailedOffer(dbOffer);
                        }
                    }
                    await this.setTransactionState(activeTransaction.id, 'FAILED');
                }
                this.repositories.redis.ioPublishToUser(activeTransaction.userId, "steamtrader:syncWithdraw", { transactionId: activeTransaction.id });
            }
        }
        return finalizedMuleTransactions;
    }

    async getTransactionItems(finalizedMuleTransaction) {
        let items = [];
        for (let k in finalizedMuleTransaction.links) {
            const transactionLink = finalizedMuleTransaction.links[k];
            const linkedOfferItems = await this.modules.db.query("SELECT * FROM steam_trade_offer_items WHERE offerId = ?", [transactionLink.offerId]);
            items = items.concat(linkedOfferItems);
        }
        return items;
    }

    async getTargetAssets(targetItems, muleBotId) {
        const botInventory = await this.modules.db.query("SELECT steam_bot_items.* FROM steam_bot_items WHERE botId = ? AND available = 1 AND assignedOfferId IS NULL", [muleBotId]);
        const targetItemsObj = targetItems.reduce((obj, el) => { if (obj[el.market_hash_name]) obj[el.market_hash_name].amount += el.amount; else obj[el.market_hash_name] = el; return obj; }, {});
        const targetItemsMerged = Object.keys(targetItemsObj).reduce((arr, key) => { arr.push(targetItemsObj[key]); return arr; }, []);
        return this.generateAssetsList(botInventory, targetItemsMerged);
    }

    async mergeTransactionOffers({ finalizedMuleTransaction, items, botId }) {
        const offerData = {
            botId,
            type: 'WITHDRAW',
            targetBotId: 0,
            muleState: 'MULE',
            app: 'RUST',
            trackingId: shortid.generate(),
            userId: 0,
            tradeUrl: '',
            items,
            totalItemsValue: 0,
            bonusRatio: 0,
            bonusAmount: 0,
            overall: 0
        };


        for (let i in finalizedMuleTransaction.links) {
            const transactionLink = finalizedMuleTransaction.links[i];
            const linkedOffer = await this.modules.db.select("steam_trade_offers", "id", transactionLink.offerId);
            offerData.userId = linkedOffer.userId;
            offerData.tradeUrl = linkedOffer.tradeUrl;
            offerData.totalItemsValue += linkedOffer.amount;
            offerData.overall += linkedOffer.overall;
            offerData.target = linkedOffer.target;
        }



        const offerId = await this.repositories.bots.redis.createDbOffer(offerData);
        return offerId;
    }

    async assignOfferIdToBotItems(items, offerId) {
        for (let i in items) {
            const item = items[i];
            const updateSuccess = await this.modules.db.exec("UPDATE steam_bot_items SET assignedOfferId = ? WHERE id = ?", [offerId, item.id]);
        }
    }



    async handleActiveWithdrawTransactions() {
        const activeTransactions = await this.modules.db.query("SELECT * FROM steam_trade_vault_mule_transactions WHERE state = 'ACTIVE' ORDER BY id ASC");

        if (activeTransactions.length == 0) return;
        let finalizedMuleTransactions = await this.getFinalizedMuleTransactions(activeTransactions);

        const muleBotIds = Object.keys(finalizedMuleTransactions);
        if (muleBotIds.length == 0) return;


        for (let i in muleBotIds) {
            const muleBotId = muleBotIds[i];
            const muleBot = this.repositories.bots.list.find(bot => bot.id == muleBotId);
            if (!muleBot) {
                this.modules.logger.log("withdraw-transaction-worker-errors", "Mule bot couldn't be found in app!");
                continue;
            }

            const release = await muleBot.muleMutex.acquire();
            try {
                for (let i in finalizedMuleTransactions[muleBotId]) {
                    try {
                       
                        const finalizedMuleTransaction = finalizedMuleTransactions[muleBotId][i];
                        const transactionItems = await this.getTransactionItems(finalizedMuleTransaction);
                        const targetAssets = await this.getTargetAssets(transactionItems, muleBotId);
                        const finalOfferId = await this.mergeTransactionOffers({ finalizedMuleTransaction, items: targetAssets, botId: muleBotId });

                        await this.assignOfferIdToBotItems(targetAssets, finalOfferId);
                        await this.setTransactionState(finalizedMuleTransaction.id, 'COMPLETED');
                        await this.modules.db.exec("UPDATE steam_trade_vault_mule_transactions SET finalOfferId = ? WHERE id = ?", [finalOfferId, finalizedMuleTransaction.id])
                        this.repositories.redis.ioPublishToUser(finalizedMuleTransaction.userId, "steamtrader:syncWithdraw", { transactionId: finalizedMuleTransaction.id });
                    } catch (err) {
                        this.modules.logger.log("withdraw-transaction-worker-errors", err.name);
                        this.modules.logger.log("withdraw-transaction-worker-errors", err.stack);
                    }
                }

                //finalize transaction

            } catch (err) {
                this.modules.logger.log("withdraw-transaction-worker-errors", err.name);
                this.modules.logger.log("withdraw-transaction-worker-errors", err.stack);
            } finally {
                release();
            }
            //

            const muleTransactions = finalizedMuleTransactions[muleBotId];
            for (let j in muleTransactions) {
                const muleTransaction = muleTransactions[j];
            }
        }

    }




}