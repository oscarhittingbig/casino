module.exports = {
  apps : [{
    name       : "web-worker",
    script     : "./src/boot/init.js",
    instances  : 2,
    exec_mode  : "cluster",
    increment_var : 'PORT',
    env: {
            "PORT": 9000,
    },
	  error_file: 'logs/app-err.log',
    out_file: 'logs/app-out.log',
    log_file: 'logs/app-combined.log',
  }],

};
