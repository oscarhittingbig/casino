require("dotenv").config();
const db = require('./src/core/modules/db');
const fs = require('fs');
const moment = require('moment');


async function calculateDepositDataByGroup(timeRangeStart, timeRangeEnd) {
        const depositData = { amounts: [], totalAmount: 0 };
        depositData.amounts = await db.query(`SELECT type, SUM(amount) as totalAmount FROM user_trades WHERE way = 'DEPOSIT' AND time > ? AND time <= ? GROUP BY type`, [timeRangeStart, timeRangeEnd]);
        

        depositData.amounts.forEach(el => {
            switch (el.type) {
                case "STEAM_SKINS": el.totalAmount *= 0.65; break;
                case "COINPAYMENTS": el.totalAmount /= 1.40; break;
                case "GIFTCARD": el.totalAmount /= 1.8; break;
                case "SKINSBACK": el.totalAmount /= 1; break;
                case "PAYDASH": el.totalAmount /= 1.4; break;
            }
            el.totalAmount /= 1000;
            depositData.totalAmount += el.totalAmount;
        });

        return depositData;
}

async function mainFunc() {

        const now = moment().utc().unix();
        const timeRanges = [];
        for (let i = -1;i <= 60;i++) {
            const startMoment =  moment(now * 1000).subtract(i, 'days').startOf('day');
            const start = startMoment.utc().unix();
            const end = moment(start * 1000).endOf('day').utc().unix();
            const date = startMoment.format("YYYY-MM-DD");
            timeRanges.push({start, end, date});
        }
    
        let txtData = "";
        for (let i in timeRanges) {
            const timeRange = timeRanges[i];
            const depositData = await calculateDepositDataByGroup(timeRange.start, timeRange.end);
            const coinpaymentsData = (depositData.amounts.find(el => el.type == 'COINPAYMENTS'));
            const coinpaymentsAmount = coinpaymentsData ? coinpaymentsData.totalAmount.toFixed(2) : 0;
            txtData += `${timeRange.date} - $${coinpaymentsAmount}` +  '\n'
        }
        fs.appendFileSync(`./Coinpayment-logs.txt`, txtData);

}

mainFunc();