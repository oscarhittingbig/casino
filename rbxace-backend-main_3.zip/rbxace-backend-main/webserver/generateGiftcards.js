require("dotenv").config();
const db = require('./src/core/modules/db');
const logger = require('./src/core/modules/logger');
const fs = require('fs');


function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateCode(length) {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let str = "";

    for (let i = 0; i < chars.length; i++) {
        str += chars[generateRandomNumber(0, chars.length - 1)];
        if ((i != chars.length - 1) && ((i + 1) % 8 == 0)) str += '-';
    }
    return str;
}

async function mainFunc() {

    console.log("Generating giftcards...");
    logger.log("giftcard-generation", "Generating giftcards...");

    const amountEls = [
    {
            amount: 5000,
            number: 1000
        },

/*
        {
            amount: 5000,
            number: 1000
        },
        {
            amount: 25000,
            number: 1000
        },
        {
            amount: 50000,
            number: 1000
        },
        {
            amount: 100000,
            number: 500
        },
        {
            amount: 250000,
            number: 250
        },
        {
            amount: 500000,
            number: 100
        }
*/
    ];
    for (let i in amountEls) {
        let created = 0;
        let codes = [];
        const amountEl = amountEls[i];
        const amount = amountEl.amount;
        const number = amountEl.number;
        
        const now = new Date().toISOString();
        for (let j = 0; j < number; j++) {
            const code = generateCode(32);

            const insertSuccess = await db.exec("INSERT INTO giftcards SET ?", [{
                code,
                amount,
                createdAt: Math.floor(Date.now() / 1000)
            }]);
            if (insertSuccess) {
                codes.push(code);
                created++;
            }
        }

        logger.log("giftcard-generation", `Generated ${created} giftcards for $${amount / 100}`);
        

        let txtData = "";
        codes.forEach((code) => { txtData += code +  '\n' });
        fs.appendFileSync(`./Giftcards-${amount / 1000}-${Math.floor(Date.now() / 1000)}.txt`, txtData);
        console.log(`Generated ${created} giftcards for $${amount / 1000}`);
    }

}

mainFunc();