require("dotenv").config();
const db = require('./src/core/modules/db');
const logger = require('./src/core/modules/logger');
const fs = require('fs');


function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateCode(codeLength) {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let str = "";

    for (let i = 0; i < codeLength; i++) {
        str += chars[generateRandomNumber(0, chars.length - 1)];
    }
    return str;
}

async function mainFunc() {

    console.log("Generating promocodes...");
    logger.log("promocodes-generation", "Generating promo codes...");

 
        const generationAmount = 1000;
        const prize = 5000;
		
		let codes = [];
		let created = 0;
        const now = new Date().toISOString();
        for (let j = 0; j < generationAmount; j++) {
            const code = generateCode(8);

            const insertSuccess = await db.exec("INSERT INTO promocodes SET ?", [{
                code,
                prize,
				maxUses: 1,
                createdAt: Math.floor(Date.now() / 1000)
            }]);
            if (insertSuccess) {
                codes.push(code);
                created++;
            }
        }

        logger.log("promocodes-generation", `Generated ${created} promocodes for $${prize / 1000}`);
        

        let txtData = "";
        codes.forEach((code) => { txtData += code +  '\n' });
        fs.appendFileSync(`./Promocodes-${prize / 1000}-${Math.floor(Date.now() / 1000)}.txt`, txtData);
        console.log(`Generated ${created} Promocodes for $${prize / 1000}`);
    

}

mainFunc();