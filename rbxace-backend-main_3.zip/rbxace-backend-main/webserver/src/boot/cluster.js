require("dotenv").config();


if (true) {

    const cluster = require("cluster");
    var numCPUs = require("os").cpus().length;

    if (cluster.isMaster) {
      //console.log(`Master ${process.pid} is running`);
  
      if (process.env.debug == 'true') {
        numCPUs = 1;
      }
  
      for (let i = 0; i <= numCPUs - 1; i++) {
  
        //let isHeadWorker = 0;
        //if (i == 0) isHeadWorker = '1'
  
        var new_worker_env = {};
        new_worker_env["NODE_APP_INSTANCE"] = (i);
  
        cluster.fork(new_worker_env);
      }
  
    } else {
     require("./init.js");
    }
  
 }




module.exports = {};
