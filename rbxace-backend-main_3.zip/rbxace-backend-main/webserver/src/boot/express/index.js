const express = require("express");
const http = require("http");
const https = require("https");
const fs = require("fs");
const history = require("connect-history-api-fallback");

const app = express();
app.use(express.json({ extended: true }));
app.use(express.urlencoded({ extended: true }));

module.exports = {
    injectMiddlewares() {
        const middlewares = global.getFilesInDirectory(global.getSrcPath('boot/express/middlewares'));
        middlewares.forEach(file => {
            const middleware = require(file.path);
            if (middleware.hasOwnProperty('inject')) middleware.inject(app);
        });
    },

    listen() {
        const port = global.devMode ? 1337 : 3000;
        const sslOptions = global.devMode ? {} : {
            key: fs.readFileSync(global.getDataPath('certificates/cert.key')),
            cert: fs.readFileSync(global.getDataPath('certificates/cert.pem'))
        };
        const listenCallback = (err) => {
            if (err) console.log(err);
            else console.info(">>> 🌎  -- http://0.0.0.0:%s/ is ready.", port);
        }

        let server = null;
        if (global.devMode) return http.createServer(app).listen(port, "0.0.0.0", listenCallback);
        else return https.createServer(sslOptions, app).listen(port, "0.0.0.0", listenCallback);
    },

    init(api) {
        this.injectMiddlewares();
        const server = this.listen();
        this.setupRoutes(api)
        return server;
    },

    setupRoutes(api) {

   
        
        app.get("/api/*", function (req, res) {
            api.router(req, res);
        });

        app.post("/api/*", function (req, res) {
            api.router(req, res);
        });

        app.get("/tests/for-kinguin", function (req, res) {
            res.write('For Kinguin');
            res.send();
        });


        app.get("/auth/discord/callback", function (req, res) {
            api.repositories.discord.handleCallback(req, res);
        });

        app.post("/coinpayments/callback", function (req, res) {
            api.services.coinpayments.ipn.handleCallback(req, res);
        });

        app.get("/coinpayments/callback", function (req, res) {
            api.services.coinpayments.ipn.handleCallback(req, res);
        });

 

        app.use(
            history({
                verbose: false
            })
        );
        

        const frontendBuildPath = `${global.appRoot}../frontend/dist`;
        app.use("/", express.static(frontendBuildPath));

    
    }
}