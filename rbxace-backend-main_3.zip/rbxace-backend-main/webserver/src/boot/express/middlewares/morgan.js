const morgan = require("morgan");
const fs = require("fs");
const path = require("path");

module.exports = {
  inject(app) {
    app.use(
      morgan(
        ':req[cf-connecting-ip] - :remote-user [:date[clf]] :method ":url" :status :response-time ms - Response Length :res[content-length] bytes - Request :req[content-length] bytes ":user-agent"',
        {
          stream: fs.createWriteStream(path.join(global.appRoot, "logs/access.log"), {
            flags: "a"
          })
        }
      )
    );
  }
};
