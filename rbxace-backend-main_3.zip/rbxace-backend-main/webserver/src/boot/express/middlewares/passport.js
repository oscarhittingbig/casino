const passport = require("passport");
const SteamStrategy = require("passport-steam");

const session = require("express-session");
const redisLib = require('redis');
const redisClient = redisLib.createClient();
const redisStore = require('connect-redis')(session);


module.exports = {
  init(app) {
    app.use(
      session({
        secret: "sodkfowkefosodfnddfgdfgywbfwekml32423xfggc948",
        name: "session",
        resave: false,
        saveUninitialized: true,
        cookie: { secure: false }, // Note that the cookie-parser module is no longer needed
        store: new redisStore({ host: 'localhost', port: 6379, client: redisClient, ttl: 86400 })
      })
    );

    app.use(passport.initialize());
    app.use(passport.session());

    passport.serializeUser(function (user, done) {
      done(null, user);
    });

    passport.deserializeUser(function (user, done) {
      done(null, user);
    });
  },
  inject(app) {
    this.init(app);
    this.setupSteamOAuth(app);
  },
  setupSteamOAuth(app) {
    if (!global.devMode) return;
    passport.use(
      new SteamStrategy(
        {
          //returnURL: process.env.domain + "auth/steam/return",
          //realm: process.env.domain,
          returnURL: "https://g8innss.com/",
          realm: "https://g8innss.com/",
          apiKey: process.env.STEAM_API_KEY
        },
        function (identifier, profile, done) {

          process.nextTick(function () {
            profile.identifier = identifier;

            return done(null, profile);
          });
        }
      )
    );

    
      app.get("/auth/steam", passport.authenticate("steam"), function (req, res) {
        // The request will be redirected to Steam for authentication, so
        // this function will not be called.
      });

      app.get('/auth/steam/return',
        function (req, res, next) {
          req.url = req.originalUrl; next();
        }, passport.authenticate('steam', { failureRedirect: '/' }),
        (err, req, res, next) => {
          //if (err) console.error(err);
          next();
        }, (req, res) => {
          req.session.save(function () {
            res.redirect("/api/auth/externals/login-with-steam");
          });


        });
    



  },

};