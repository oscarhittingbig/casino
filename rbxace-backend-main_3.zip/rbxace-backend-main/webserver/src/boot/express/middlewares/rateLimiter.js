const redis = require("redis");
const { RateLimiterRedis } = require("rate-limiter-flexible");

const redisClient = redis.createClient({
  host: "localhost",
  port: 6379,
  enable_offline_queue: false
});

const rateLimiter = new RateLimiterRedis({
  redis: redisClient,
  keyPrefix: "middleware",
  points: 60,
  duration: 1 // per 1 second by IP
});

const rateLimiterMiddleware = (req, res, next) => {
  if (req.path.startsWith("/api")) {
    let ipAddr =
    req.headers["cf-connecting-ip"] ||
    req.headers["x-forwarded-for"] ||
    req.connection.remoteAddress;
  rateLimiter
    .consume(ipAddr)
    .then(() => {
      next();
    })
    .catch(() => {
      res.status(429).send("Too Many Requests");
    });
  } else {
    next();
  }
  
};

module.exports = {
    inject(app) {
        app.use(rateLimiterMiddleware);
    }
};
