require('./global');
const express = require('./express');
const loader = require('./loader');


async function main() {
    const args = loader.generateArgs();
    const api = new (require(global.getSrcPath('core/api')))(args);

    await args.repositories.proxies.init();

    await args.repositories.dailycases.core.init();

    
    loader.startWorkers(args);
    await args.workers.globalUpdater.sync();

    const server = express.init(api);
    args.repositories.socket.init(server);
    args.repositories.socket.listen();
}

main();