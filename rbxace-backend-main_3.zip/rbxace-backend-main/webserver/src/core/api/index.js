module.exports = class {

    constructor(params) {
        params.inject(this);

        this.routes = {};

        global.loadFromPath({ args: params, path: global.getSrcPath('core/api/routes'), obj: this, recursive: true, isModule: false });

        /* User */
        //this.createRoute('user/info', 'POST', false, 0);

        /* Auth */
        this.createRoute('auth/externals/login-with-steam', 'GET', false, 0);

        /* User */
        this.createRoute('user/settings/info', 'POST', true, 0);
        this.createRoute('user/settings/alter', 'POST', true, 0);
        this.createRoute('user/settings/set-trade-url', 'POST', true, 0);
        this.createRoute('user/settings/authorize-discord', 'POST', true, 0);

        this.createRoute('user/profile/get-daily-cases', 'POST', true, 0);
        this.createRoute('user/profile/open-case', 'POST', true, 0);
        this.createRoute('user/profile/get-stats', 'POST', true, 0);
        this.createRoute('user/profile/get-transactions', 'POST', true, 0);
        this.createRoute('user/profile/get-game-history', 'POST', true, 0);

        /* Affiliates */
        this.createRoute('affiliates/info', 'POST', true, 0);
        this.createRoute('affiliates/set-code', 'POST', true, 0);
        this.createRoute('affiliates/claim-earnings', 'POST', true, 0);
        this.createRoute('affiliates/redeem-code', 'POST', true, 0);

        /* Trading */

        /* --> Steam */
        this.createRoute('trading/steam/request-inventory', 'POST', true, 0);
        this.createRoute('trading/steam/request-deposit', 'POST', true, 0);
        this.createRoute('trading/steam/request-withdraw', 'POST', true, 0);

        this.createRoute('trading/steam/get-steam-offer', 'POST', true, 0);
        this.createRoute('trading/steam/get-withdraw-transaction', 'POST', true, 0);

        /* --> Giftcards */
        this.createRoute('trading/giftcard/redeem', 'POST', true, 0);

        /* --> Cryptos */
        this.createRoute('trading/crypto/get-wallet', 'POST', true, 0);
        this.createRoute('trading/crypto/get-prices', 'POST', false, 0);

        /* Coinflip */
        this.createRoute('game/coinflip/get-winning-info', 'POST', true, 0);
        this.createRoute('game/coinflip/claim-winnings', 'POST', true, 0);
        this.createRoute('game/coinflip/doubledown', 'POST', true, 0);

        /* Upgrader */
        this.createRoute('game/upgrader/get-user-inventory', 'POST', true, 0);
        this.createRoute('game/upgrader/sell-items', 'POST', true, 0);
        this.createRoute('game/upgrader/withdraw-items', 'POST', true, 0);

        /* Events */
        this.createRoute('events/rain/join', 'POST', true, 0);
        this.createRoute('events/promocode/redeem', 'POST', true, 0);

        /* Player */
        this.createRoute('player/claim-faucet', 'POST', true, 0);

        /* Fairness */
        this.createRoute('fairness/get-results', 'POST', true, 0);

        /* Admin */

        /* --> Dashboard */
        this.createRoute('admin/dashboard/info', 'POST', true, 100);

        /* --> Promo codes */
        this.createRoute('admin/promocode/info', 'POST', true, 100);
        this.createRoute('admin/promocode/generate', 'POST', true, 100);

        /* --> User */
        this.createRoute('admin/user/search', 'POST', true, 100);
        this.createRoute('admin/user/get-user-trades', 'POST', true, 100);
        this.createRoute('admin/user/get-user-transactions', 'POST', true, 100);

    }

    roleToLevel(role) {
        switch (role) {
            case 'BANNED': return 0;
            case 'USER': return 0;
            case 'MEMBER': return 1;
            case 'ADMIN': return 100;
            default: return 0;
        }
    }

    getFunctionName(str) {
        let functionName = 'handle';
        const words = str.split('-');
        for (let i in words) {
            let word = words[i];
            word = global.capitalizeFirstLetter(word);
            functionName += word;
        }
        return functionName;
    }
    getCallbackFunction(path) {
        const routes = path.split('/');

        let functionObj = {};
        let beforeLastElement = {};
        for (let i in routes) {
            let route = routes[i];
            const firstElement = i == 0;
            const lastElement = i == routes.length - 1;
            if (firstElement) { functionObj = this[route]; continue; }
            if (lastElement) { route = this.getFunctionName(route); }
            beforeLastElement = functionObj;
            functionObj = functionObj[route];

        }
        return functionObj.bind(beforeLastElement);
    }

    createRoute(path, method, loginRequired, minRoleLevel) {

        const url = '/api/' + path;
        this.routes[url] = {
            path: url,
            method,
            callbackFunction: this.getCallbackFunction(path),
            loginRequired,
            minRoleLevel
        };
    }

    async findRouteAndGetReply(req, res, path, method, headers, query) {

        let startTime = new Date();

        let user = await this.repositories.user.getByAuthToken(headers.authorization);
        if (user.id > 0) user.isLoggedIn = true;

        let reply = { success: false, message: 'Something went wrong!' };

        let route = this.routes[path];

        const userAgent = req.headers['user-agent'];
        const ipAddress = (req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || req.connection.remoteAddress).toString().substring(0, 128);

        if (route == undefined) {
            reply.message = "URL doesn't exist!";
            return reply;
        }

        if (route.method !== method) {
            reply.message = 'Method is not correct!';
            return reply;
        }

        if (route.minRoleLevel > user.roleLevel) {
            reply.message = 'No permission!';
            return reply;
        }

        if (route.loginRequired && !user.isLoggedIn) {
            reply.message = 'You need to log in to do this!';
            return reply;
        }

        if (route.path !== '/api/user/info' && user.isBanned) {
            reply.message = 'You have been banned!';
            return reply;
        }



        await route.callbackFunction({
            req,
            res,
            reply,
            query,
            user,
            userAgent,
            ipAddress
        }).catch(e => {
            reply.message = e.message;

            //if (global.devMode) throw e;
        });

        let endTime = new Date();

        reply.elapsed = endTime - startTime;

        return reply;
    }

    finalizeRequest(res, reply) {
        if (reply.redirected || reply.replied) return;
        const status = reply.error ? 501 : 200;
        res.status(status);
        res.send(reply);
    }

    async router(req, res) {
        let path = req.path;
        let method = req.method;
        let headers = req.headers;
        let query = req.body;

        let reply = await this.findRouteAndGetReply(req, res, path, method, headers, query);

        this.finalizeRequest(res, reply);
    }
};