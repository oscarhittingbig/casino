
module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async handleInfo(params) {
    let { reply, query } = params;

    reply.dashboardData = await this.repositories.admin.stats.getDashboardData();
    reply.success = true;
  }

}
