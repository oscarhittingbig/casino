const { v1: uuidv1 } = require('uuid');
const moment = require('moment');
module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async handleInfo(params) {
    let { reply, query } = params;
    delete reply.message;

    reply.entries = await this.modules.db.query("SELECT * FROM promocodes ORDER BY id DESC LIMIT 50");
    reply.success = true;
  }

  async handleGenerate(params) {
    let { reply, query } = params;

    if (!query.input) return;

    if (!query.input.code || typeof query.input.code !== 'string' || query.input.code.length < 3 || query.input.code.length > 16 || !this.repositories.protection.isAlphaNumeric(query.input.code) )
    throw new Error("Code must be between 3 - 16 characters and alphanumerical!");

    const code = query.input.code.toLocaleUpperCase().replaceAll('İ', 'I');

    const maxUses = parseInt(query.input.maxUses);
    if (isNaN(maxUses) || maxUses <= 0 || maxUses >= 1000) return;

    const prize = parseInt(query.input.prize);
    if (isNaN(prize) || prize <= 0 || prize >= 1000000) return;


    const deleteOldCode = await this.modules.db.exec("DELETE FROM promocodes WHERE code = ?", [code]);
    
    const insertId = await this.modules.db.insert('INSERT INTO promocodes SET ?', [{
      code,
      prize,
      maxUses,
      createdAt: moment().utc().unix()
    }]);

    reply.newPromocode = await this.modules.db.select("promocodes", "id", insertId);
    reply.success = true;
  }

}
