const { v1: uuidv1 } = require('uuid');
const moment = require('moment');
module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async handleSearch(params) {
    let { reply, query } = params;
    delete reply.message;

    if (!query.input) return;
    if (!query.input.searchParam || typeof query.input.searchParam !== 'string' || query.input.searchParam.length < 1 || query.input.searchParam.length > 32 )
    return;

    let searchType = 'DISPLAYNAME';
    let searchParam = query.input.searchParam.toLowerCase();
    if (searchParam.startsWith('765')) searchType = 'ACCOUNTID';

    let searchArr = [];
    let sqlQuery = 'SELECT user_data_common.*, users.accountId FROM user_data_common INNER JOIN users ON users.id = user_data_common.userId WHERE LOWER(user_data_common.displayName) LIKE ? OR user_data_common.userId = ? LIMIT 25';
    if (searchType == 'ACCOUNTID') {
      sqlQuery = 'SELECT user_data_common.*, users.accountId FROM users INNER JOIN user_data_common ON user_data_common.userId = users.id WHERE users.accountId = ? LIMIT 25';
      searchArr = [searchParam];
    } else {
      searchArr = [`%${searchParam}%`, searchParam];
    }
    reply.entries = await this.modules.db.query(sqlQuery, searchArr);
    reply.success = true;
  }

  async handleGetUserTrades(params) {
    let { reply, query } = params;
    delete reply.message;

    const userId = parseInt(query.userId);
    if (isNaN(userId) || userId <= 0) return;
    let page = parseInt(query.page);
    if (isNaN(page) || page < 0 || page > 10000) throw new Error('...');

    let maxEntries = 10;
    let startOffset = page * maxEntries;

    reply.currentPage = page + 1;
    reply.pageCount = Math.ceil( ( (await this.modules.db.query("SELECT COUNT(1) as count FROM user_trades WHERE userId = ?", [userId]))[0].count || 0) / maxEntries);

    const entries = await this.modules.db.query(`SELECT * FROM user_trades WHERE userId = ? ORDER BY time DESC LIMIT ${startOffset},${maxEntries}`, [userId]);
    reply.success = true;
    reply.entries = entries;
  }

  async handleGetUserTransactions(params) {
    let { reply, query } = params;
    delete reply.message;

    const userId = parseInt(query.userId);
    if (isNaN(userId) || userId <= 0) return;
    let page = parseInt(query.page);
    if (isNaN(page) || page < 0 || page > 10000) throw new Error('...');

    let maxEntries = 10;
    let startOffset = page * maxEntries;

    reply.currentPage = page + 1;
    reply.pageCount = Math.ceil( ( (await this.modules.db.query("SELECT COUNT(1) as count FROM user_transactions WHERE userId = ?", [userId]))[0].count || 0) / maxEntries);

    const entries = await this.modules.db.query(`SELECT * FROM user_transactions WHERE userId = ? ORDER BY time DESC LIMIT ${startOffset},${maxEntries}`, [userId]);
    reply.success = true;
    reply.entries = entries;
  }



}
