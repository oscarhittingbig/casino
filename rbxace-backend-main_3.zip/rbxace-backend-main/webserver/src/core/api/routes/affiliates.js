module.exports = class {
  constructor(params) {
    params.inject(this);
  }

  async handleInfo(params) {
    let { reply } = params;

    const codeData = await this.modules.db.select("affiliates", "ownerId", params.user.id);
    if (codeData) codeData.levelData = await this.repositories.affiliates.getLevelData(codeData.totalWagered);
    
    //affiliateData.earnings maybe?

    reply.success = true;
    reply.codeData = codeData;
    reply.charts = codeData ? await this.repositories.affiliates.getStatsCharts(codeData.id) : null;
    delete reply.message;    
  }

  async handleSetCode(params) {
    let { reply, query } = params;
    if (!query.code || typeof query.code !== 'string') return;

    const code = query.code.toLocaleUpperCase().replaceAll('İ', 'I');
    if (code.length < 3 || code.length > 16) {
      reply.messageParams = [3, 16];
      throw new Error("API_AFFILIATES_SETCODE_INVALIDLENGTH")
    }
    const bannedCodes = [ 'MONEY', 'GAINS', 'GAIN', 'RUST', 'ADMIN', 'FREE', 'LOL', 'XD', 'COINS', 'CHAMPION', 'RAIN', 'GAINER'];
    if (bannedCodes.includes(code))  throw new Error("API_AFFILIATES_SETCODE_BANNEDCODE")

    if (!this.repositories.protection.isAlphaNumeric(code))  throw new Error("API_AFFILIATES_SETCODE_INVALIDCHARS");

    const codeExists = (await this.modules.db.query("SELECT COUNT(1) as count FROM affiliates WHERE code = ? AND ownerId != ?", [code, params.user.id]))[0].count > 0;
    if (codeExists) throw new Error("API_AFFILIATES_SETCODE_CODEEXISTS");

    const insertSuccess = await this.modules.db.exec("INSERT IGNORE INTO affiliates SET ?", [{
      ownerId: params.user.id,
      code
    }]);

    await this.modules.db.exec("UPDATE affiliates SET code = ? WHERE ownerId = ?", [code, params.user.id]);

    reply.success = true;
    reply.message = 'API_AFFILIATES_SETCODE_SUCCESS';
    reply.code = code;
  }

  async handleClaimEarnings(params) {
    let { reply } = params;

    const codeData = await this.modules.db.select("affiliates", "ownerId", params.user.id);
    if (!codeData) throw new Error("API_AFFILIATES_CLAIMEARNINGS_NOCODE");
    if (codeData.balance == 0) throw new Error("API_AFFILIATES_CLAIMEARNINGS_NOBALANCE");

    const sql = await this.modules.db.call("affiliates_claimAvailableEarnings(?)", [params.user.id]);
    if (!sql.success) throw new Error("API_AFFILIATES_CLAIMEARNINGS_NOBALANCE");

    this.repositories.user.updateBalanceVisually(params.user.id, sql.params.newBalance);

    reply.success = true;
    reply.message = 'API_AFFILIATES_CLAIMEARNINGS_SUCCESS';
    reply.messageParams = [sql.params.earnings];

  }

  async handleRedeemCode(params) {
    let { reply, query } = params;

    if (params.user.affiliateId) throw new Error("API_AFFILIATES_REDEEMCODE_ALREADYREDEEMED");

    if (!query.code || typeof query.code !== 'string' || query.code.length < 3 || query.code.length > 16 || !this.repositories.protection.isAlphaNumeric(query.code) )
    throw new Error("API_AFFILIATES_REDEEMCODE_CODEINVALID");

    let cd = this.modules.cache.getCooldown(`API_AFFILIATES_REDEEMCODE|${params.user.id}`, 5);
    if (cd > 0) throw new Error("API_GENERAL_COOLDOWN");

    const code = query.code.toUpperCase();
    const codeData = await this.modules.db.select("affiliates", "code", code);
 
    if (!codeData)   throw new Error("API_AFFILIATES_REDEEMCODE_CODENOTEXISTS");
    if (codeData.ownerId == params.user.id)  throw new Error("API_AFFILIATES_REDEEMCODE_OWNCODE");

    //check rust and steam level
    await this.repositories.steam.ownsRust(params.user.accountId);
    const steamLevel = await this.repositories.steam.getLevel(params.user.accountId);
    const MIN_STEAM_LEVEL = 2;
    if (steamLevel < MIN_STEAM_LEVEL) {
      reply.message = 'API_REPO_STEAM_MINLEVEL';
      reply.messageParams = [MIN_STEAM_LEVEL];
      return;
    }

    const updateUserSuccess = await this.modules.db.exec("UPDATE user_data_common SET affiliateId = ? WHERE userId = ? AND affiliateId = 0", [codeData.ownerId, params.user.id])
    if (!updateUserSuccess) throw new Error("API_AFFILIATES_REDEEMCODE_ALREADYREDEEMED")

    const updateAffiliateSuccess = await this.modules.db.exec("UPDATE affiliates SET usersCount = usersCount + 1 WHERE id = ?", [codeData.id])

    const prize = 500;
    await this.repositories.user.updateBalance({ way: 'IN', userId: params.user.id, amount: prize, transactionType: 'AFFILIATES_REDEEMCODE' });

    reply.success = true;
    reply.message = 'API_AFFILIATES_REDEEMCODE_SUCCESS';
    reply.messageParams = [prize];

  }

}
