module.exports = class {
  constructor(params) {
    params.inject(this);

  }

}
