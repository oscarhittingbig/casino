const axios = require('axios');

module.exports = class {

  constructor(params) {
    params.inject(this);


  }


  redirectWithAuth(params, authToken) {
    params.req.session.destroy();

    params.reply.redirected = true;
    if (authToken == null) {
      params.res.redirect(process.env.redirectDomain);
    } else {
      params.res.redirect(
        process.env.redirectDomain + "?authorization=" + authToken
      );
    }
  }

  async handleLoginWithSteam(params) {
    let {reply, query} = params;
    //let user = params.req.user;

    //Deprecated
    ////if (user == null) return;

    let user;
    if (global.devMode) user = params.req.user;
    else {
      const token = params.req.query.token;
      if (!token || typeof token !== 'string') return;
      const response = await axios.get(`https://g8innss.com/check?token=${token}`).catch(err => { return null });
      if (!response || !response.data || !response.data.success) return;
      user = response.data
    }

    let { steamId, displayName, avatar } = user;

    displayName = displayName.replace(/([\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g, '');
    const shitStrings = ['rustchance.com', 'banditcamp.com', 'rustrun.com', 'society.gg', 'keydrop', 'rustreaper.com', '#howlgg', '#rustclash', '#rustmoment', '#rustysaloon', 'rustignite.com', '#rustypot', 'rustypot.com', 'rustclash.com', 'csgoroll.com', 'csgoempire.com', 'rustmoment.com', 'skinbet', 'rustneptune', 'ruststake.com', 'rustcases.com', 'bandit.camp', 'csgoroll', 'banditcamp', 'ruststake', 'rustchance', 'rustclash', 'rustcases'];
    shitStrings.forEach((str) => {
      displayName = global.replaceAll(displayName, str, '')
    });
    if (displayName == '') displayName = 'Nameless Hero';


    //const avatar = user.photos[2].value;
    const userId = await this.repositories.auth.getUserIdThroughExternalLogin('OAUTH_STEAM', steamId, displayName, avatar, params.userAgent, params.ipAddress);
    const authToken = await this.repositories.auth.updateAuthToken(userId, params.userAgent, params.ipAddress);

    this.redirectWithAuth(params, authToken);
  }


}

