module.exports = class {
  constructor(params) {
    params.inject(this);

  }

  async handleCallback(params) {
    //await this.services.coinpayments.ipn.handleCallback(params.req, params.res);
    
  }

}
