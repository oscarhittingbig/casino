const moment = require('moment');
const verifyHCaptcha = require('hcaptcha').verify;

module.exports = class {
    constructor(params) {
        params.inject(this);

    }

    async handleRedeem(params) {
        let { reply, query } = params;

        let cd = this.modules.cache.getCooldown(`API_EVENTS_PROMOCODE_REDEEM|${params.user.id}`, 10);
        if (cd > 0) throw new Error("API_GENERAL_COOLDOWN");

        if (!query.code || typeof query.code !== 'string' || query.code.length < 3 || query.code.length > 64 )
        throw new Error("API_EVENTS_PROMOCODE_REDEEM_CODEINVALID");

        const code = query.code.toLocaleUpperCase().replaceAll('İ', 'I');


        await this.repositories.steam.ownsRust(params.user.accountId);
        const steamLevel = await this.repositories.steam.getLevel(params.user.accountId);
        const MIN_STEAM_LEVEL = 5;
        if (steamLevel < MIN_STEAM_LEVEL) {
            reply.message = 'API_REPO_STEAM_MINLEVEL';
            reply.messageParams = [MIN_STEAM_LEVEL];
            return;
        }

        const userLevel = this.repositories.level.getLevelByExp(params.user.exp);
        const MIN_SITE_LEVEL = 5;
        if (userLevel < MIN_SITE_LEVEL) {
            reply.message = 'API_USER_MINLEVEL';
            reply.messageParams = [MIN_SITE_LEVEL];
            return;
        }

        let discordAccessToken = await this.repositories.discord.getUserAccessToken(params.user.id);
        if (!discordAccessToken) {
            reply.discordAuthUrl = await this.repositories.discord.generateRedirectUrl(params.user.id);
            throw new Error("API_REPO_DISCORD_NOTINOURSERVER");
        }


        const promocode = await this.modules.db.select("promocodes", "code", code);
        if (!promocode) throw new Error("API_EVENTS_PROMOCODE_REDEEM_CODEDOESNTEXIST");
        if (promocode.uses >= promocode.maxUses) throw new Error("API_EVENTS_PROMOCODE_REDEEM_CODENOTAVAILABLE");

        const callSql = await this.modules.db.call("events_promocode_claim(?, ?)", [params.user.id, promocode.id]);
        if (!callSql.success) throw new Error("API_EVENTS_PROMOCODE_REDEEM_ALREADYREDEEMED");

        await this.repositories.user.updateBalance({ way: 'IN', userId: params.user.id, amount: promocode.prize, transactionType: 'PROMOCODE_AWARD' });


        reply.success = true;
        reply.message = 'API_EVENTS_PROMOCODE_REDEEM_SUCCESS';
        reply.messageParams = [promocode.prize];
    }


}
