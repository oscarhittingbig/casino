const moment = require('moment');
const verifyHCaptcha = require('hcaptcha').verify;

module.exports = class {
    constructor(params) {
        params.inject(this);

    }

    async handleJoin(params) {
        let { reply, query } = params;

        let cd = this.modules.cache.getCooldown(`API_EVENTS_RAIN_JOIN|${params.user.id}`, 5);
        if (cd > 0) throw new Error("API_GENERAL_COOLDOWN");

        const token = query.captchaToken;
        if (!token || typeof token !== 'string' || token.length <= 0 || token.length >= 10240) return;

        const hCaptchaResponse = await verifyHCaptcha(process.env.HCAPTCHA_SECRET, token);
        if (!hCaptchaResponse.success) throw new Error("API_EVENTS_RAIN_CAPTCHAFAILED");

        await this.repositories.steam.ownsRust(params.user.accountId);
        const steamLevel = await this.repositories.steam.getLevel(params.user.accountId);
        const MIN_STEAM_LEVEL = 5;
        if (steamLevel < MIN_STEAM_LEVEL) {
            reply.message = 'API_REPO_STEAM_MINLEVEL';
            reply.messageParams = [MIN_STEAM_LEVEL];
            return;
        }

        const userLevel = this.repositories.level.getLevelByExp(params.user.exp);
        const MIN_SITE_LEVEL = 10;
        if (userLevel < MIN_SITE_LEVEL) {
            reply.message = 'API_USER_MINLEVEL';
            reply.messageParams = [MIN_SITE_LEVEL];
            return;
        }

        let discordAccessToken = await this.repositories.discord.getUserAccessToken(params.user.id);
        if (!discordAccessToken) {
            reply.discordAuthUrl = await this.repositories.discord.generateRedirectUrl(params.user.id);
            throw new Error("API_REPO_DISCORD_NOTINOURSERVER");
        }
        
        const hasDomain = await this.repositories.steam.hasUserDomain(params.user.accountId);
        if (!hasDomain) throw new Error("API_REPO_STEAM_NOTAGINNAME");

        const potId = parseInt(query.potId);
        if (isNaN(potId) || potId <= 0) return;

        const pot = await this.modules.db.select("events_rain_pots", "id", potId);
        if (!pot || pot.state !== 'ENDING') throw new Error("API_EVENTS_RAIN_POTCLOSED");

        const userJoined = (await this.modules.db.query("SELECT COUNT(1) as count FROM events_rain_pot_players WHERE potId = ? AND userId = ?", [potId, params.user.id]))[0].count > 0;
        if (userJoined) throw new Error("API_EVENTS_RAIN_ALREADYJOINED");

        const callSql = await this.modules.db.call("events_rain_handleJoin(?, ?)", [potId, params.user.id]);
        if (!callSql.success) throw new Error("API_EVENTS_RAIN_ALREADYJOINED");

        reply.success = true;
        reply.message = 'API_EVENTS_RAIN_JOINSUCCESSFUL';
    }


}
