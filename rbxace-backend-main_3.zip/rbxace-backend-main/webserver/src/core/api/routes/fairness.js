module.exports = class {
  constructor(params) {
    params.inject(this);

    this.defs = {
      AVAILABLE_GAMEMODES: ['ROULETTE', 'CRASH', 'BLACKJACK', 'COINFLIP', 'UPGRADER']
    };
  }

  async handleGetResults(params) {
    let { reply, query } = params

    const gameId = parseInt(query.gameId);
    if (!gameId || isNaN(gameId) || gameId <= 0) return;

    const gameMode = query.gameMode;
    if (!gameMode || typeof gameMode !== 'string' || !this.defs.AVAILABLE_GAMEMODES.includes(gameMode)) return;

    let results = {};
    let game = {};
    switch (gameMode) {


      case 'ROULETTE':
      game = await this.modules.db.select("game_roulette_rounds", "id", gameId);
      if (!game || game.state !== 'CLOSED') throw new Error("API_FAIRNESS_GETRESULTS_GAMENOTFOUND");
      results = {
        serverSecret: game.serverSecret,
        randomOrgSecret: game.randomOrgSecret,
        verificationLink: game.verificationLink,
        hash: game.hash,
        roll: game.roll
      }

      break;

      case 'CRASH':
      game = await this.modules.db.select("game_crash_rounds", "id", gameId);
      if (!game || game.state !== 'CRASHED') throw new Error("API_FAIRNESS_GETRESULTS_GAMENOTFOUND");
      results = {
        serverSecret: game.serverSecret,
        randomOrgSecret: game.randomOrgSecret,
        verificationLink: game.verificationLink,
        seedHash: game.seedHash,
        multiplier: game.multiplier,
        houseEdge: game.houseEdge
      }

      break;
      
      case 'BLACKJACK':
      game = await this.modules.db.select("game_blackjack_rounds", "id", gameId);
      if (!game || game.state !== 'CLOSED') throw new Error("API_FAIRNESS_GETRESULTS_GAMENOTFOUND");
      results = {
        serverSecret: game.serverSecret,
        randomOrgSecret: game.randomOrgSecret,
        verificationLink: game.verificationLink,
        deckCount: game.deckCount,
        seed: game.seed,
        shoeString: game.shoeString,
      }

      break;

            
      case 'COINFLIP':
      game = await this.modules.db.select("game_coinflip_rooms", "id", gameId);
      if (!game || game.phase !== 'FLIPPED') throw new Error("API_FAIRNESS_GETRESULTS_GAMENOTFOUND");
      results = {
        serverSecret: game.serverSecret,
        randomOrgSecret: game.randomOrgSecret,
        verificationLink: game.verificationLink,
        ticket: game.ticket,
        winnerColor: game.winnerColor,
        seed: game.seed,
        seedHash: game.seedHash
      }

      break;

                  
      case 'UPGRADER':
      game = await this.modules.db.select("game_upgrader_rounds", "id", gameId);
      if (!game) throw new Error("API_FAIRNESS_GETRESULTS_GAMENOTFOUND");
      results = {
        houseEdge: game.houseEdge,
        clientSeed: game.clientSeed,
        serverSeed: game.serverSeed,
        randomOrgSecret: game.randomOrgSecret,
        verificationLink: game.verificationLink,
        seed: game.seed,
        ticket: game.ticket,
        multiplier: game.multiplier,
        rollType: game.rollType
      }

      break;

      

    }

    reply.success = true;
    reply.results = results;
    reply.message = 'API_FAIRNESS_GETRESULTS_SUCCESS';
  }

}
