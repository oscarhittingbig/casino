module.exports = class {
  constructor(params) {
    params.inject(this);

    this.defs = {
      AVAILABLE_COLORS: ['BLACK', 'RED']
    }
  }

  validateRoom(room, userId) {
    if (!room || room.phase !== 'FLIPPED' || !(room.ownerId == userId || room.opponentId == userId)) return false;
    return true;
  }

  async handleGetWinningInfo(params) {
    let { reply, query } = params;
    delete reply.message;

    this.repositories.protection.checkMemCooldown('API_GAME_COINFLIP_GETWINNINGINFO', params.user.id, 5);

    const roomId = parseInt(query.roomId);
    if (!this.repositories.protection.isValidAmount(roomId)) return;

    const room = await this.modules.db.select("game_coinflip_rooms", "id", roomId);
    if (!this.validateRoom(room, params.user.id)) return;

    if (!room.taxesCalculated) {
      const hasDomain = await this.repositories.steam.hasUserDomain(params.user.accountId);
      const { totalSkinsValueWithTax } = await this.repositories.ext.coinflip.trading.updateTaxVariables(room.id, hasDomain);
      room.totalSkinsValueWithTax = totalSkinsValueWithTax;
    }

    reply.roomData = {
      id: roomId,
      totalSkinsValue: (room.ownerSkinsValue + room.opponentSkinsValue),
      totalSkinsValueWithTax: room.totalSkinsValueWithTax,
      userColor: room.ownerId == params.user.id ? room.ownerColor : (room.ownerColor == 'BLACK' ? 'RED' : 'BLACK'),
    };

    reply.success = true;
  }

  async handleClaimWinnings(params) {
    let { reply, query } = params;
    delete reply.message;

    this.repositories.protection.checkMemCooldown('API_GAME_COINFLIP_CLAIMWINNINGS', params.user.id, 5);

    const roomId = parseInt(query.roomId);
    if (!this.repositories.protection.isValidAmount(roomId)) return;

    const room = await this.modules.db.select("game_coinflip_rooms", "id", roomId);
    if (!this.validateRoom(room, params.user.id)) return;
    if (room.winnerId !== params.user.id) return;


    let tradeUrl = '';
    try {
      tradeUrl = await this.repositories.user.getTradeUrl(params.user.id);
    } catch (err) {
      reply.setTradeUrl = true;
      throw new Error(err.message);
    }
    if (params.user.hasTradeLock || params.user.isBanned) throw new Error("API_TRADING_STEAM_REQUESTWITHDRAW_NOTALLOWED")


    const bot = (await this.modules.db.query("SELECT steam_trade_bots.id, steam_trade_bots.steamId FROM `steam_trade_offers` INNER JOIN steam_trade_bots ON steam_trade_bots.id = steam_trade_offers.botId WHERE steam_trade_offers.id = ?", [room.lastOpponentOfferId]))[0];

    this.repositories.redis.publish("steam-trader", "claimCoinflipWinnings", { roomId, botId: bot.id, botSteamId: bot.steamId, userId: params.user.id, steamId: params.user.accountId, tradeUrl });
    reply.success = true;
    reply.message = 'API_TRADING_STEAM_PROCESSING';
  }

  async handleDoubledown(params) {
    let { reply, query } = params;
    delete reply.message;

    this.repositories.protection.checkMemCooldown('API_GAME_COINFLIP_DOUBLEDOWN', params.user.id, 5);

    const roomId = parseInt(query.roomId);
    if (!this.repositories.protection.isValidAmount(roomId)) return;

    let color = query.color;
    if (!color || typeof color !== 'string' || !this.defs.AVAILABLE_COLORS.includes(color)) {
      color = 'BLACK';
    }

    const room = await this.modules.db.select("game_coinflip_rooms", "id", roomId);
    if (!this.validateRoom(room, params.user.id)) return;
    if (room.winnerId !== params.user.id) return;
    if (room.endPhase !== 'AWAITING_CLAIM') throw new Error("SOCKET_TRADING_COINFLIP_ALREADYTRADEDONCE");

    this.repositories.redis.publish("steam-trader", "doubledownCoinflip", { roomId, userId: params.user.id, color });
    reply.success = true;
    reply.message = 'API_TRADING_STEAM_PROCESSING';
  }

}
