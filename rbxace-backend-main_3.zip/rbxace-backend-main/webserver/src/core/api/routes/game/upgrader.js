const moment = require('moment');
module.exports = class {
  constructor(params) {
    params.inject(this);
  }

  async handleGetUserInventory(params) {
    let { reply, query } = params;
    delete reply.message;

    reply.items = await this.repositories.ext.upgrader.game.getUserInventory(params.user.id); // await this.modules.db.query("SELECT * FROM game_upgrader_user_inventory WHERE userId = ? AND state = 'ACTIVE'", [params.user.id]);
    reply.success = true;
  }

  validateItemIds(itemIds) {
    for (let i in itemIds) {
      itemIds[i] = parseInt(itemIds[i]);
      const itemId = itemIds[i];
      if (isNaN(itemId) || itemId <= 0 || itemId >= 100000000) throw new Error("API_GAME_UPGRADER_INVALIDITEMID");
    }
  }

  async handleSellItems(params) {
    let { reply, query } = params;

    this.repositories.protection.checkMemCooldown('API_GAME_UPGRADER_SELLITEMS', params.user.id, 0.1);

    let itemIds = query.itemIds;
    if (!Array.isArray(itemIds) || itemIds.length > 20) return;
    itemIds = [...new Set(itemIds)];
    this.validateItemIds(itemIds);

    let totalValue = 0;
    for (let i in itemIds) {
      const itemId = itemIds[i];
      const item = await this.modules.db.select("game_upgrader_user_inventory", "id", itemId);
      if (!item || item.userId !== params.user.id || item.state !== 'ACTIVE') throw new Error("API_GAME_UPGRADER_ITEMDOESNTBELONGTOYOU");
      totalValue += item.price;
    }
    totalValue *= 10; //because of coins
    totalValue = Math.floor(totalValue * 1.035);

    const itemIdsString = itemIds.join(',');
    const updateItemStatesSql = await this.modules.db.call("upgrader_setItemStates(?,?)", [itemIdsString, 'SOLD']);
    if (!updateItemStatesSql.success) throw new Error("API_GAME_UPGRADER_ITEMSNOTAVAILABLE");

    await this.repositories.user.updateBalance({ way: 'IN', userId: params.user.id, amount: totalValue, transactionType: 'UPGRADER_SELL_ITEMS' });
    reply.success = true;
    reply.message = 'API_GAME_UPGRADER_SELLITEMS_SUCCESS';
    reply.itemIds = itemIds;
  }



  async generateAssetsList({ reply, targetItems }) {
    let assets = [];
    let currentAssetsAmount = {};
    const botInventoryItems = await this.modules.db.query("SELECT steam_bot_items.* FROM steam_bot_items INNER JOIN steam_trade_bots ON steam_trade_bots.id = steam_bot_items.botId WHERE app = 'RUST' AND steam_trade_bots.type = 'VAULT' ");

    for (let i in targetItems) {
      const item = targetItems[i];
      const expectedAmount = item.amount;
      const targetAssets = botInventoryItems.filter(el => el.market_hash_name == item.market_hash_name && el.available);

      for (let j in targetAssets) {
        const currentAssetAmount = currentAssetsAmount[item.market_hash_name] || 0;
        const requiredAmount = expectedAmount - currentAssetAmount;
        if (requiredAmount <= 0) break;
        const targetAsset = targetAssets[j];
        let takenAmount = targetAsset.amount;
        if (takenAmount > requiredAmount) takenAmount = requiredAmount;
        if (currentAssetsAmount[item.market_hash_name]) currentAssetsAmount[item.market_hash_name] += takenAmount;
        else currentAssetsAmount[item.market_hash_name] = takenAmount;
        assets.push({ ...targetAsset, amount: takenAmount });
      }

      const takenAmount = currentAssetsAmount[item.market_hash_name] || 0;
      if (expectedAmount !== takenAmount) {
        reply.messageParams = [item.market_hash_name];
        throw new Error("API_GAME_UPGRADER_WITHDRAWITEMS_SOMEASSETSDONTEXISTATMARKET");
      }
    }
    return assets;
  }

  async handleWithdrawItems(params) {
    let { reply, query } = params;

    this.repositories.protection.checkMemCooldown('API_GAME_UPGRADER_WITHDRAWITEMS', params.user.id, 1);

    let itemIds = query.itemIds;
    if (!Array.isArray(itemIds) || itemIds.length > 20) return;
    itemIds = [...new Set(itemIds)];
    this.validateItemIds(itemIds);

    const targetItems = {};
    for (let i in itemIds) {
      const itemId = itemIds[i];
      const item = await this.modules.db.select("game_upgrader_user_inventory", "id", itemId);
      if (!item || item.userId !== params.user.id || item.state !== 'ACTIVE') throw new Error("API_GAME_UPGRADER_ITEMDOESNTBELONGTOYOU");
      if (targetItems[item.market_hash_name]) targetItems[item.market_hash_name].amount++;
      else targetItems[item.market_hash_name] = {
        ...item,
        amount: 1
      }
    }

    const assets = await this.generateAssetsList({ reply, targetItems });
    const botIds = assets.reduce((arr, el) => { if (!arr.includes(el.botId)) arr.push(el.botId); return arr; }, []);
    if (botIds.length > 1) throw new Error("API_GAME_UPGRADER_WITHDRAWITEMS_MORETHANONEBOT");

    let tradeUrl = '';
    try {
      tradeUrl = await this.repositories.user.getTradeUrl(params.user.id);
    } catch (err) {
      reply.setTradeUrl = true;
      throw new Error(err.message);
    }

    if (params.user.hasTradeLock || params.user.isBanned) throw new Error("API_TRADING_STEAM_REQUESTWITHDRAW_NOTALLOWED")

    const timeCutoff = moment().utc().unix() - (60 * 10);
    const assignedBotSql = (await this.modules.db.query("SELECT id, steamId FROM steam_trade_bots WHERE isOnline = 1 AND type = 'MULE' AND lastPing >= ? ORDER BY RAND() LIMIT 1", [timeCutoff]));
    if (assignedBotSql.length == 0) throw new Error("API_TRADING_STEAM_REQUESTDEPOSIT_NOONLINEBOTS");
    const sourceMuleBot = assignedBotSql[0];

    this.repositories.redis.publish("steam-trader", "upgraderWithdrawItems", {
      userId: params.user.id,
      steamId: params.user.accountId,
      tradeUrl,
      itemIds,
      assets,
      botId: botIds[0],
      sourceMuleBot
    });
    reply.success = true;
    reply.message = 'API_TRADING_STEAM_PROCESSING';
    reply.itemIds = itemIds;

  }


}
