const moment = require('moment');

module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      FAUCET: {
        AWARD: 30,
        COOLDOWN: 30 * 60
      }
    };
  }

  async handleClaimFaucet(params) {
    let { reply, query } = params;

    throw new Error("Disabled for a while!");

    let cd = this.modules.cache.getCooldown(`API_PLAYER_CLAIMFAUCET|${params.user.id}`, 5);
    if (cd > 0) throw new Error("API_GENERAL_COOLDOWN");

    const now = moment().utc().unix();
    const lastFaucetClaim = (await this.modules.db.query("SELECT lastFaucetClaim FROM user_data_cooldowns WHERE userId = ?", [params.user.id]))[0].lastFaucetClaim;
    const diff = now - lastFaucetClaim;
    const timeCutOff = now - (this.defs.FAUCET.COOLDOWN);
    if (diff < this.defs.FAUCET.COOLDOWN) {
      const remainingTime = this.defs.FAUCET.COOLDOWN - diff;
      reply.message = 'API_PLAYER_CLAIMFAUCET_HASCOOLDOWN';
      reply.messageParams = [remainingTime];
      return;
    }

    let success = true;
    reply.checks = {
      rust: false,
      discord: false,
      tag: false,
      balance: false
    };

    try {
      reply.checks.balance = params.user.balance < 10;
      if (!reply.checks.balance) throw new Error('!');

      reply.checks.rust = await this.repositories.steam.ownsRust(params.user.accountId);

      let discordAccessToken = await this.repositories.discord.getUserAccessToken(params.user.id);
      if (!discordAccessToken) reply.discordAuthUrl = await this.repositories.discord.generateRedirectUrl(params.user.id);
      else reply.checks.discord = true;

      reply.checks.tag = await this.repositories.steam.hasUserDomain(params.user.accountId);
      
    } catch(err) {

    } finally {
      Object.keys(reply.checks).map((checkKey) => { if (!reply.checks[checkKey]) success = false; });
    }

    if (success) {
      const updateSuccess = await this.modules.db.exec("UPDATE user_data_cooldowns SET lastFaucetClaim = ? WHERE userId = ? AND lastFaucetClaim < ?", [now, params.user.id, timeCutOff]);
      if (!updateSuccess) throw new Error("NO WAY");
      await this.repositories.user.updateBalance({ way: 'IN', userId: params.user.id, amount: this.defs.FAUCET.AWARD, transactionType: 'FAUCET_AWARD' });
    }

    reply.success = success;
    reply.message = success ? 'API_PLAYER_CLAIMFAUCET_SUCCESS' : 'API_PLAYER_CLAIMFAUCET_CHECKSARENOTCOMPLETED';
  }
  
}
