const moment = require('moment');
module.exports = class {
    constructor(params) {
        params.inject(this);
    }

    async handleGetWallet(params) {
        let { reply, query } = params;

        const currency = query.currency;
        if (!currency || typeof currency !== 'string') return;
        if (!this.services.coinpayments.core.defs.availableCurrencies.includes(currency)) return;
        try {
            const address = await this.services.coinpayments.core.getUserWalletAddress(currency, params.user.id);
            const transactions = await this.modules.db.query("SELECT currency, fiatAmount, cryptoAmount, status, createdAt FROM coinpayments_transactions WHERE currency = ? AND userId = ? AND type = 'DEPOSIT' ORDER BY createdAt DESC LIMIT 5", [currency, params.user.id])
            reply.walletData = {
                currency,
                address,
                transactions
            };
        } catch(err) {
            console.log(err)
         }

        reply.prices = await this.services.coinpayments.core.getPrices();
        reply.success = true;
        delete reply.message;
    }

    async handleGetPrices(params) {
        let { reply, query } = params;

        reply.prices = await this.services.coinpayments.core.getPrices();
        reply.success = true;
        delete reply.message;
    }




}
