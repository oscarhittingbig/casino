const moment = require('moment');
module.exports = class {
    constructor(params) {
        params.inject(this);
    }

    async handleRedeem(params) {
        let { reply, query } = params;

        let cd = this.modules.cache.getCooldown(`API_TRADING_GIFTCARD_REDEEM|${params.user.id}`, 5);
        if (cd > 0) throw new Error("API_GENERAL_COOLDOWN");

        const { code } = query;
        if (!code || typeof code != "string" || code.length > 128 || !(/^[a-zA-Z0-9-_]+$/.test(code))) throw new Error("API_TRADING_GIFTCARD_REDEEM_INVALIDCODE");
        
        const giftcard = await this.modules.db.select("giftcards", "code", code);
        if (!giftcard) throw new Error("API_TRADING_GIFTCARD_REDEEM_CODEDOESNTEXIST");

        const coinsAmount = Math.floor(giftcard.amount * 1.30);
        const updateSuccess = await this.modules.db.exec("UPDATE giftcards SET coinsAmount = ?, usedBy = ?, usedAt = ? WHERE code = ? AND usedBy = 0", [coinsAmount, params.user.id, moment().utc().unix(), code]);
        if (!updateSuccess) throw new Error("API_TRADING_GIFTCARD_REDEEM_CODEALERADYUSED");
        
        this.modules.logger.log("gifcard-redeems", `User Id #${params.user.id} redeemed the code ${code} - Giftcard Id: ${giftcard.id} - Coins Amount: ${coinsAmount}`);
        await this.repositories.user.updateBalance({way: 'IN', userId: params.user.id, amount: coinsAmount, transactionType: 'DEPOSIT_GIFTCARD', alterType: 'DEPOSIT', alterName: 'GIFTCARD' });

        reply.success = true;
        reply.message = "API_TRADING_GIFTCARD_REDEEM_SUCCESS";
        reply.messageParams = [coinsAmount];
    }




}
