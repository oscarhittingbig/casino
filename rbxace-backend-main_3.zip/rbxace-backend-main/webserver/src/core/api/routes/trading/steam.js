const moment = require('moment');
module.exports = class {
    constructor(params) {
        params.inject(this);

        this.defs = {
            AVAILABLE_APPS: ['RUST'],
            AVAILABLE_TARGETS: ['BALANCE', 'COINFLIP'],
            AVAILABLE_COLORS: ['BLACK', 'RED']
        }
    }

    validateAndReturnAssets(assets, isAdmin) {
        if (!isAdmin && (!assets || !Array.isArray(assets) || assets.length > 20)) throw new Error("API_TRADING_STEAM_REQUESTDEPOSIT_WRONGASSETS");
        for (let i = 0; i < assets.length; i++) {
            let asset = assets[i];
            if (typeof asset !== 'object') throw new Error("Nice try.");
            if (!asset.assetid || !(/^\d+$/.test(asset.assetid))) throw new Error("Asset id is allowed to be a number!");
            if (!asset.amount) throw new Error("Asset amount doesn't exist!");
            asset.amount = parseInt(asset.amount);
            if (isNaN(asset.amount) || asset.amount <= 0 || asset.amount >= 250) throw new Error("Wrong asset amounts!");
        }
        assets = [...new Map(assets.map(el => [el.assetid, el])).values()];
        return assets;
    }




    async handleRequestInventory(params) {
        let { reply, query } = params;

        this.repositories.protection.checkMemCooldown('API_TRADING_STEAM_REQUESTINVENTORY', params.user.id, 0.1);

        const app = query.app;
        if (!app || typeof app !== 'string' || !this.defs.AVAILABLE_APPS.includes(app)) return;

        const userInventory = await this.repositories.redis.get(`STEAM_USER_INVENTORY_${params.user.id}`);
        if (userInventory) return socket.emit("steamTrader:requestInventoryResponse", JSON.parse(userInventory));

        this.repositories.redis.publish("steam-trader", "requestInventory", { app, userId: params.user.id, steamId: params.user.accountId });
        reply.success = true;
        delete reply.message;
    }

    async getCoinflipParams(target, params, query, totalItemsValue) {
        const coinflip = {};
        if (target !== 'COINFLIP') return coinflip;

        coinflip.color = query.color;
        if (!coinflip.color || typeof coinflip.color !== 'string' || !this.defs.AVAILABLE_COLORS.includes(coinflip.color)) {
            coinflip.color = 'BLACK';
        }

        coinflip.isCreation = query.isCreation == true;
        if (!coinflip.isCreation) {
            coinflip.roomId = parseInt(query.roomId);
            if (isNaN(coinflip.roomId) || coinflip.roomId <= 0 || coinflip.roomId >= 999999999) throw new Error("NO!");
            const coinflipRoom = await this.modules.db.select("game_coinflip_rooms", "id", coinflip.roomId);
            if (!coinflipRoom || coinflipRoom.phase !== 'AWAITING_OPPONENT') throw new Error("SOCKET_COINFLIP_ALREADYJOINED");

            if (!global.devMode && (totalItemsValue < coinflipRoom.rangeMin || totalItemsValue > coinflipRoom.rangeMax)) throw new Error("API_TRADING_COINFLIP_SKINSOUTOFRANGE");
            if (coinflipRoom.ownerId == params.user.id && !global.devMode) throw new Error("API_TRADING_COINFLIP_CANTDEPOSITOWN");
        }
        return coinflip;
    }

    async handleRequestDeposit(params) {
        let { reply, query } = params;

        this.repositories.protection.checkMemCooldown('API_TRADING_STEAM_REQUESTDEPOSIT', params.user.id, 1);

        const app = query.app;
        if (!app || typeof app !== 'string' || !this.defs.AVAILABLE_APPS.includes(app)) return;



        const hasAwaitingDeposit = (await this.modules.db.query("SELECT COUNT(1) as count FROM steam_trade_offers WHERE type = 'DEPOSIT' AND userId = ? AND (requestState = 'CREATING' OR requestState = 'IN_QUEUE' OR (requestState = 'CREATED' AND steamState = 'ACTIVE'))", [params.user.id]))[0].count > 0;
        if (hasAwaitingDeposit) throw new Error("API_TRADING_STEAM_REQUESTDEPOSIT_HAVEPENDINGDEPOSIT");

        let assets = this.validateAndReturnAssets(query.assets, params.user.role == 'ADMIN');

        let totalItemsValue = parseFloat(query.totalItemsValue);
        if (!totalItemsValue || isNaN(totalItemsValue) || totalItemsValue <= 0 || totalItemsValue >= 99999999) return;
        totalItemsValue = Math.round(totalItemsValue);




        let target = query.target;
        if (!target || typeof target !== 'string' || !this.defs.AVAILABLE_TARGETS.includes(target)) {
            target = 'BALANCE';
        }

        //FOR COINFLIP
        const coinflip = await this.getCoinflipParams(target, params, query, totalItemsValue);
        target = 'BALANCE';


        let tradeUrl = '';
        try {
            tradeUrl = await this.repositories.user.getTradeUrl(params.user.id);
        } catch (err) {
            reply.setTradeUrl = true;
            throw new Error(err.message);
        }

        const timeCutoff = moment().utc().unix() - (60 * 10);
        let assignedBotSql = [];
        if (target == 'BALANCE')
            assignedBotSql = (await this.modules.db.query("SELECT id, steamId FROM steam_trade_bots WHERE isOnline = 1 AND type = 'MULE' AND lastPing >= ? ORDER BY RAND() LIMIT 1", [timeCutoff]));
        else
            assignedBotSql = (await this.modules.db.query("SELECT id, steamId FROM steam_trade_bots WHERE isOnline = 1 AND type = 'COINFLIP' AND lastPing >= ?", [timeCutoff]));

        if (assignedBotSql.length == 0) throw new Error("API_TRADING_STEAM_REQUESTDEPOSIT_NOONLINEBOTS");
        const assignedBot = assignedBotSql[0];

        this.repositories.redis.publish("steam-trader", "requestDeposit", { app, target, coinflip, botId: assignedBot.id, botSteamId: assignedBot.steamId, userId: params.user.id, steamId: params.user.accountId, tradeUrl, assets, totalItemsValue });
        reply.success = true;
        reply.message = 'API_TRADING_STEAM_PROCESSING';
    }

    async handleRequestWithdraw(params) {
        let { reply, query } = params;

        const app = 'RUST';

        this.repositories.protection.checkMemCooldown('API_TRADING_STEAM_REQUESTWITHDRAW', params.user.id, 2);

        if (global.settings.maintenance) throw new Error("PAGE_GAMES_MAINTENANCE");

        const assets = this.validateAndReturnAssets(query.assets, params.user.role == 'ADMIN');
        let totalItemsValue = parseFloat(query.totalItemsValue);
        if (!totalItemsValue || isNaN(totalItemsValue) || totalItemsValue <= 0 || totalItemsValue >= 999999) return;
        totalItemsValue = Math.round(totalItemsValue);

        let calculatedTotalItemsValue = 0;
        const shopItems = await this.modules.db.query("SELECT steam_bot_items.* FROM steam_bot_items INNER JOIN steam_trade_bots ON steam_trade_bots.id = steam_bot_items.botId WHERE app = 'RUST' AND steam_trade_bots.type = 'VAULT' ");

        for (let i in assets) {
            const asset = assets[i];
            const dbShopItem = shopItems.find((item) => item.assetid == asset.assetid); //await this.modules.db.select("steam_bot_items", "assetid", asset.assetid);
            if (!dbShopItem) throw new Error("API_TRADING_STEAM_REQUESTWITHDRAW_SOMEITEMSDONTEXIST");
            if (dbShopItem.app !== 'RUST') throw new Error("API_TRADING_STEAM_REQUESTWITHDRAW_SOMEITEMSDONTEXIST");
            if (!dbShopItem.available || dbShopItem.busy) {
                reply.message = 'API_TRADING_STEAM_REQUESTWITHDRAW_SOMEITEMSBUSY';
                reply.messageParams = [dbShopItem.market_hash_name];
            }
            if (dbShopItem.amount < asset.amount) throw new Error("API_TRADING_STEAM_REQUESTWITHDRAW_SOMEITEMSBUSY");
            calculatedTotalItemsValue += dbShopItem.price * asset.amount;
        }

        if (totalItemsValue !== calculatedTotalItemsValue) throw new Error("API_TRADING_STEAM_REQUESTWITHDRAW_PRICESUPDATED");

        let tradeUrl = '';
        try {
            tradeUrl = await this.repositories.user.getTradeUrl(params.user.id);
        } catch (err) {
            reply.setTradeUrl = true;
            throw new Error(err.message);
        }

        if (params.user.hasTradeLock || params.user.isBanned) throw new Error("API_TRADING_STEAM_REQUESTWITHDRAW_NOTALLOWED")
        if (params.user.balance < totalItemsValue) throw new Error("API_GENERAL_INSUFFICIENTBALANCE");

        /* DEPRECATED */
        /*
        const FLAG_MIN = 20000;
        if (calculatedTotalItemsValue >= FLAG_MIN && !params.user.isWhitelisted) {
            if (!params.user.whitelistRequest) await this.modules.db.exec("UPDATE user_data_common SET whitelistRequest = 1 WHERE userId = ?", [params.user.id]);
            throw new Error("API_TRADING_STEAM_REQUESTWITHDRAW_NOTALLOWED");
        }
        
        */

        const timeCutoff = moment().utc().unix() - (60 * 10);
        const assignedBotSql = (await this.modules.db.query("SELECT id, steamId FROM steam_trade_bots WHERE isOnline = 1 AND type = 'MULE' AND lastPing >= ? ORDER BY RAND() LIMIT 1", [timeCutoff]));
        if (assignedBotSql.length == 0) throw new Error("API_TRADING_STEAM_REQUESTDEPOSIT_NOONLINEBOTS");
        const sourceMuleBot = assignedBotSql[0];


        this.repositories.redis.publish("steam-trader", "requestWithdraw", { app, userId: params.user.id, steamId: params.user.accountId, tradeUrl, assets, totalItemsValue, sourceMuleBot });
        reply.success = true;
        reply.message = 'API_TRADING_STEAM_PROCESSING';
    }

    async handleGetSteamOffer(params) {
        let { reply, query } = params;
        delete reply.message;

        const offerId = parseInt(query.offerId);
        if (isNaN(offerId) || offerId < 0) return;

        const offerData = await this.modules.db.select("steam_trade_offers", "id", offerId);
        if (!offerData || offerData.userId !== params.user.id) return;

        const items = await this.modules.db.query("SELECT market_hash_name, image, value, amount FROM steam_trade_offer_items WHERE offerId = ? ORDER BY id ASC", [offerId]);

        reply.offerData = {
            type: offerData.type,
            target: offerData.target,
            steamOfferId: offerData.steamOfferId,
            trackingId: offerData.trackingId,
            overall: offerData.overall,
            items
        }
        reply.success = true;
    }

    async handleGetWithdrawTransaction(params) {
        let { reply, query } = params;
        delete reply.message;

        const transactionId = parseInt(query.transactionId);
        if (isNaN(transactionId) || transactionId < 0) return;

        const transaction = await this.modules.db.select("steam_trade_vault_mule_transactions", "id", transactionId);
        if (!transaction) return;

        let items = [];
        let target = '';
        let overall = 0;
        let steamOfferId = null;
        let trackingId = null;
        let state = 'ACTIVE';
        if (transaction.state == 'COMPLETED') {
            const offerData = await this.modules.db.select("steam_trade_offers", "id", transaction.finalOfferId);
            if (!offerData || offerData.userId !== params.user.id) return;
            items = await this.modules.db.query("SELECT market_hash_name, image, value, amount FROM steam_trade_offer_items WHERE offerId = ? ORDER BY id ASC", [transaction.finalOfferId]);
            target = offerData.target;
            overall = offerData.overall;
            steamOfferId = offerData.steamOfferId;
            trackingId = offerData.trackingId;
            
            state = offerData.requestState;
        } else {
            const transactionLinks = await this.modules.db.query("SELECT * FROM steam_trade_vault_mule_transaction_links WHERE transactionId = ?", [transactionId]);
            for (let i in transactionLinks) {
                const transactionLink = transactionLinks[i];
                const offerId = transactionLink.offerId;
                const offerData = await this.modules.db.select("steam_trade_offers", "id", offerId);
                if (!offerData || offerData.userId !== params.user.id) return;
                target = offerData.target;
                overall += offerData.overall;
                const offerItems = await this.modules.db.query("SELECT market_hash_name, image, value, amount FROM steam_trade_offer_items WHERE offerId = ? ORDER BY id ASC", [offerId]);
                items = items.concat(offerItems);
            }
            const finalized = transactionLinks.filter(link => link.state == 'ACTIVE').length == 0;
            const transactionSuccess = transactionLinks.filter(link => link.state == 'COMPLETED').length == transactionLinks.length;
            if (finalized && transactionSuccess) state = 'CREATING_FINAL_OFFER';
            else if (finalized && !transactionSuccess) state = 'FAILED';
            else state = 'ACTIVE';
        }

        reply.offerData = {
            type: 'WITHDRAW',
            state,
            target,
            steamOfferId,
            trackingId,
            overall,
            items
        }
        reply.success = true;
    }




}
