
module.exports = class {

  constructor(params) {
    params.inject(this);

  }

  async handleInfo(params) {
    params.reply.success = true;
    delete params.reply.msg;

    const user = params.user;
    
    if (user.isLoggedIn) params.reply.user_data = this.repositories.user.getGeneralUserVars(user);
    else params.reply.user_data = user;
    
  }
  
}
