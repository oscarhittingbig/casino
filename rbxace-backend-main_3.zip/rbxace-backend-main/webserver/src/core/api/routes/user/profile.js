const moment = require('moment');

module.exports = class {
  constructor(params) {
    params.inject(this);
  }

  get cases() {
    const entries = JSON.parse(JSON.stringify(this.repositories.dailycases.core.cases));
    entries.forEach((entry) => {
      delete entry.ticketRanges;
    });
    return entries;
  }

  get currentDay() {
    return Math.floor(moment().utc().unix() / 86400);
  }

  get dayEndsAt() {
    return moment().utc().endOf('day').utc().unix();
  }

  async handleGetDailyCases(params) {
    let { reply, query } = params;
    delete reply.message;

    
    reply.entries = this.cases;
    reply.lastOpen = await this.repositories.user.getCooldown(params.user.id, 'lastDailyCaseOpen');
    /* DEPRECATED */
    /*
    reply.lastOpenDay = await this.repositories.dailycases.game.getLastOpenDay(params.user.id);
    reply.currentDay = this.currentDay;
    reply.dayEndsAt = this.dayEndsAt;
    */
    reply.success = true;
  }

  async handleOpenCase(params) {
    let { reply, query } = params;

    const caseId = parseInt(query.caseId);
    if (!caseId || isNaN(caseId) || caseId <= 0) return;

    
    const now = moment().utc().unix();
    const lastOpen = await this.repositories.user.getCooldown(params.user.id, 'lastDailyCaseOpen');
    const diff = now - lastOpen;
    const cooldown = 86400;
    const timeCutOff = now - cooldown;

    if (diff < cooldown) throw new Error("API_USER_PROFILE_OPENCASE_ALREADYOPENEDTODAY")

    /* DEPRECATED */
    /*
    const lastOpenDay = await this.repositories.dailycases.game.getLastOpenDay(params.user.id);
    const currentDay = this.currentDay;
    if (currentDay == lastOpenDay) throw new Error("API_USER_PROFILE_OPENCASE_ALREADYOPENEDTODAY");
    */

    const targetCase = this.repositories.dailycases.core.cases.find(el => el.id == caseId);
  
    const userLevel = this.repositories.level.getLevelByExp(params.user.exp);
    if (!targetCase || userLevel < targetCase.requiredLevel) throw new Error("API_USER_PROFILE_OPENCASE_LEVELNOTENOUGH");

    const updateSuccess = await this.modules.db.exec("UPDATE user_data_cooldowns SET lastDailyCaseOpen = ? WHERE userId = ? AND lastDailyCaseOpen < ?", [now, params.user.id, timeCutOff]);
    if (!updateSuccess) throw new Error("NO WAY");

    const gameVariables = this.repositories.dailycases.game.open(caseId);
   
    let igredientItemVariables = {};
    if (gameVariables.ingredientWon.type == 'ITEM') {
      igredientItemVariables = {
        ingredientItemName: gameVariables.ingredientWon.item.name,
        ingredientItemPrice: gameVariables.ingredientWon.item.price,
        ingredientItemIcon: gameVariables.ingredientWon.item.icon
      }
    }
    await this.modules.db.insert("INSERT INTO dailycases_history SET ?", [{
      caseId,
      userId: params.user.id,
      prize: gameVariables.winnings,
      ticket: gameVariables.ticket,
      ingredientType: gameVariables.ingredientWon.type,
      ...igredientItemVariables,
      createdAt: moment().utc().unix()
    }]);

    setTimeout(() => {
    this.repositories.user.updateBalance({ way: 'IN', userId: params.user.id, amount: gameVariables.winnings, transactionType: 'DAILYCASES_OPEN' });
  }, 5000);

    reply.success = true;
    reply.lastOpen = now;
    reply.spinnerData = {
      id: Date.now(),
      animation: gameVariables
    }
    delete reply.message;
  }

  async handleGetStats(params) {
    let { reply, query } = params;
    delete reply.message;

    const generalStats = (await this.modules.db.select("user_stats", "userId", params.user.id));
    generalStats.totalWagered = (await this.modules.db.query("SELECT SUM(amount) as totalWagered FROM user_wagers WHERE userId = ? AND time >= 0", [params.user.id]))[0].totalWagered;
    generalStats.totalWinnings = (await this.modules.db.query("SELECT SUM(winnings) as totalWinnings FROM user_gamehistory WHERE userId = ?", [params.user.id]))[0].totalWinnings;
    delete generalStats.userId;

    const functionKeys = [ 'Monthly', 'ThisMonths', 'Todays' ];
    const chartKeys = {
      'Monthly': 'allTime',
      'ThisMonths': 'monthly',
      'Todays': 'daily'
    };
    const charts = { allTime: [], monthly: [], daily: [] };
    for (let i in functionKeys) {
      const functionKey = functionKeys[i];
      const chartKey = chartKeys[functionKey];

      if (i > 0 && charts['allTime'].length == 0) continue;

      let start, end = null;
      if (functionKey == 'Monthly') {
        let startSql = await this.modules.db.query("SELECT time FROM user_trades WHERE userId = ? ORDER BY time ASC LIMIT 1", [params.user.id]);
        if (startSql.length > 0) start = startSql[0].time;

        let endSql =  await this.modules.db.query("SELECT time FROM user_trades WHERE userId = ? ORDER BY time DESC LIMIT 1", [params.user.id]);
        if (endSql.length > 0) end = endSql[0].time;
      }
      const timeRanges = this.repositories.stats[`generate${functionKey}TimeRanges`](start, end);

      let dataset = [];
      for (let j in timeRanges) {
        const timeRange = timeRanges[j];
        let netValueSql = (await this.modules.db.query("SELECT SUM(winnings - betAmount) as value FROM user_gamehistory WHERE userId = ? AND time > ? AND time <= ?", [params.user.id, timeRange.start, timeRange.end]));
        const netValue = netValueSql.length > 0 ? (netValueSql[0].value || 0) : 0
        dataset.push(parseFloat( (netValue).toFixed(0)));
      }

      charts[chartKey] = dataset;
    }

    reply.success = true;
    reply.generalStats = generalStats;
    reply.charts = charts;

  }

  async handleGetGameHistory(params) {
    let { reply, query } = params;
    delete reply.message;

    let page = parseInt(query.page);
    if (isNaN(page) || page < 0 || page > 10000) throw new Error('...');

    let maxEntries = 5;
    let startOffset = page * maxEntries;

    reply.currentPage = page + 1;
    reply.pageCount = Math.floor( ( (await this.modules.db.query("SELECT COUNT(1) as count FROM user_gamehistory WHERE userId = ?", [params.user.id]))[0].count || 0) / maxEntries);

    const entries = await this.modules.db.query(`SELECT * FROM user_gamehistory WHERE userId = ? ORDER BY time DESC LIMIT ${startOffset},${maxEntries}`, [params.user.id]);
    reply.success = true;
    reply.entries = entries;
  }

  
  async handleGetTransactions(params) {
    let { reply, query } = params;
    delete reply.message;

    let page = parseInt(query.page);
    if (isNaN(page) || page < 0 || page > 10000) throw new Error('...');

    let maxEntries = 5;
    let startOffset = page * maxEntries;

    reply.currentPage = page + 1;
    reply.pageCount = Math.floor( ( (await this.modules.db.query("SELECT COUNT(1) as count FROM user_trades WHERE userId = ?", [params.user.id]))[0].count || 0) / maxEntries);

    const entries = await this.modules.db.query(`SELECT * FROM user_trades WHERE userId = ? ORDER BY time DESC LIMIT ${startOffset},${maxEntries}`, [params.user.id]);
    reply.success = true;
    reply.entries = entries;
  }

}
