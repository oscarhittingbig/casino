
module.exports = class {

  constructor(params) {
    params.inject(this);

  }

  async handleAlter(params) {
    const input = params.query.input;

    if (input.volume == undefined || input.isAnon == undefined || input.isPrivate == undefined) return;

    let { volume, isAnon, isPrivate } = input;
 
    volume = parseInt(volume);
    if (isNaN(volume) || volume < 0 || volume > 100) return;
    isAnon = isAnon == 1;
    isPrivate = isPrivate == 1;

    const updateSuccess = await this.modules.db.exec("UPDATE user_data_settings SET volume = ?, isAnon = ?, isPrivate = ? WHERE userId = ?", [volume, isAnon, isPrivate, params.user.id]);
    if (!updateSuccess) throw new Error("Something went wrong while updating!");

    this.repositories.redis.publishToOtherWorkers("user:setSocketProperty", { 
      userId: params.user.id,
      property: 'settings.isAnon', 
      value: isAnon
    });

    params.reply.success = true;
    delete params.reply.msg;
    
  }

  async handleSetTradeUrl(params) {
    let { reply, query } = params;
    const input = query.input;
    if (!input.tradeUrl || typeof input.tradeUrl !== 'string') return;

    const tradeUrl = input.tradeUrl.trim();
    if ( !tradeUrl.startsWith("https://steamcommunity.com/tradeoffer/new/?partner=") || !(/steamcommunity\.com\/tradeoffer\/new\/\?partner=[0-9]*&token=[a-zA-Z0-9_-]*/i).test(tradeUrl))
    throw new Error("API_USER_SETTINGS_SETTRADEURL_WRONGFORMAT")

    const updateSuccess = await this.modules.db.exec("UPDATE user_data_settings SET tradeUrl = ? WHERE userId = ?", [tradeUrl, params.user.id]);

    reply.success = true;
    reply.tradeUrl = tradeUrl;
    reply.message = 'API_USER_SETTINGS_SETTRADEURL_SUCCESS';
  }

  async handleInfo(params) {
    let { reply, query } = params;

    let discordAccessToken = await this.repositories.discord.getUserAccessToken(params.user.id);
    reply.discordAuthorized = false;
    if (discordAccessToken) reply.discordAuthorized = true;
    reply.success = true;
  }

  async handleAuthorizeDiscord(params) {
    let { reply, query } = params;

    let discordAccessToken = await this.repositories.discord.getUserAccessToken(params.user.id);
    if (discordAccessToken) return;

    reply.success = true;
    reply.discordAuthUrl = await this.repositories.discord.generateRedirectUrl(params.user.id);

  }
  
}
