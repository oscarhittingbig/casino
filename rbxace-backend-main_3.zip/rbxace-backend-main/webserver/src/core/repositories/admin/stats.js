const moment = require('moment');
moment.locale('en', {
    week: {
        dow: 1
    }
});

const cutAfter = 0;

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.ignoredUserIds = [8, 9, 10, 841];

    }

   
    getFilterConditionsString() {
        let str = '';
        for (let i in this.ignoredUserIds) {
            const userId = this.ignoredUserIds[i];
            str += `userId != ${userId}`;
            if (i != this.ignoredUserIds.length - 1) str += ' AND ';
        }
        return str;
    }

    
    get startOfToday() { return moment().startOf('day').utc().unix(); }
    get startOfTodayMoment() { return moment().startOf('day').utc(); }
    get endOfToday() { return moment().endOf('day').utc().unix(); }
    get startOfWeek() { return moment().isoWeekday(1).startOf('week').utc().unix(); }
    get startOfWeekMoment() { return moment().isoWeekday(1).startOf('week') }
    get endOfWeek() { return moment().isoWeekday(1).endOf('week').utc().unix(); }
    get startOfMonth() { return moment().startOf('month').utc().unix(); }
    get startOfMonthMoment() { return moment().startOf('month').utc(); }
    get endOfMonth() { return moment().endOf('month').utc().unix(); }
    get startOfYear() { return moment().startOf('year').utc().unix(); }


    async calculateDepositDataByGroup(timeRangeStart, timeRangeEnd) {
        const depositData = { amounts: [], totalAmount: 0 };
        depositData.amounts = await this.modules.db.query(`SELECT type, SUM(amount) as totalAmount FROM user_trades WHERE ${this.getFilterConditionsString()} AND way = 'DEPOSIT' AND time > ? AND time <= ? GROUP BY type`, [timeRangeStart, timeRangeEnd]);
        

        depositData.amounts.forEach(el => {
            switch (el.type) {
                case "STEAM_SKINS": el.totalAmount *= 0.65; break;
                case "COINPAYMENTS": el.totalAmount /= 1.40; break;
                case "GIFTCARD": el.totalAmount /= 1.8; break;
                case "SKINSBACK": el.totalAmount /= 1; break;
                case "PAYDASH": el.totalAmount /= 1.4; break;
            }
            el.totalAmount /= 1000;
            depositData.totalAmount += el.totalAmount;
        });

        return depositData;
    }

    async calculateTotalWithdrawAmount(timeRangeStart, timeRangeEnd) {
        const totalAmount = (await this.modules.db.query(`SELECT SUM(amount) as totalAmount FROM user_trades WHERE ${this.getFilterConditionsString()} AND way = 'WITHDRAW' AND time > ? AND time <= ?`, [timeRangeStart, timeRangeEnd]))[0].totalAmount || 0;

        return totalAmount / 1.1 * 0.65 / 1000;
    }

    async calculateNetProfit(timeRangeStart, timeRangeEnd) {
        timeRangeStart = Math.max(cutAfter, timeRangeStart);
        const totalDepositAmount = (await this.calculateDepositDataByGroup(timeRangeStart, timeRangeEnd)).totalAmount;
        const totalWithdrawAmount = await this.calculateTotalWithdrawAmount(timeRangeStart, timeRangeEnd);
        return totalDepositAmount - totalWithdrawAmount;
    }


    async getDailyAmounts() {
        const amounts = {};
        const todayStartedAt = Math.max(cutAfter, moment().startOf('day').utc().unix());
        amounts.totalDepositAmount = (await this.modules.db.query("SELECT SUM(amount) as totalAmount FROM `user_trades` WHERE way = 'DEPOSIT' AND time > ?", [todayStartedAt]))[0].totalAmount || 0;
        amounts.totalWithdrawAmount = (await this.modules.db.query("SELECT SUM(amount) as totalAmount FROM `user_trades` WHERE way = 'WITHDRAW' AND time > ?", [todayStartedAt]))[0].totalAmount || 0;
  
        return amounts;
    }

    async getDailyDistributionData() {
        const todayStartedAt = Math.max(cutAfter, moment().startOf('day').utc().unix());
        const distribution = await this.modules.db.query("SELECT type, SUM(amount) as totalAmount FROM `user_trades` WHERE way = 'DEPOSIT' AND time > ? GROUP BY type", [todayStartedAt]);
        
        const pieChartData = distribution.reduce((arr, obj) => { arr.push([obj.type, parseFloat((obj.totalAmount / 100).toFixed(2))]);return arr;}, []);
        pieChartData.unshift(['X', 'X']);
        return pieChartData;
    }

    async getDailyStats() {
        const data = {};
        data.totalWithdrawAmount = await this.calculateTotalWithdrawAmount( Math.max(cutAfter, this.startOfToday), this.endOfToday);
        data.depositData = await this.calculateDepositDataByGroup(Math.max(cutAfter, this.startOfToday), this.endOfToday);
        data.netProfit = (data.depositData.totalAmount - data.totalWithdrawAmount);
        return data;
    }

    async getDailyTable() {
        const days = [ "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" ];
           
        let data = [];
        const dailyTimeRanges = this.generateDailyTimeRanges();
        for (let i in days) {
            const timeRange = dailyTimeRanges[i];
            const netProfit = await this.calculateNetProfit(timeRange.start, timeRange.end);
            data.push( parseFloat((netProfit).toFixed(2)));
        }

        return data;
    }

    async getGeneralStats() {
        const data = {};
        data.netProfitWeekly = (await this.calculateNetProfit(this.startOfWeek, this.endOfWeek));
        data.netProfitMonthly = (await this.calculateNetProfit(this.startOfMonth, this.endOfMonth));
        data.netProfitAllTime = (await this.calculateNetProfit(0, moment().utc().unix()));
        return data;
    }

    generateMonthlyTimeRanges() {
        let timeRanges = [];
        for (let i = 0; i < 12; i++) {
            const monthMoment = moment().utc().startOf('year').add(i, 'month').add('1', 'hour');
            timeRanges.push({ start: monthMoment.startOf('month').utc().unix(), end: monthMoment.endOf('month').utc().unix() });
        }
        return timeRanges;
    }

    generateDailyTimeRanges() {
        let timeRanges = [];
        for (let i = 0; i < 7; i++) {
            const dayMoment = this.startOfWeekMoment.add((i), 'day');
            timeRanges.push({ start: dayMoment.startOf('day').utc().unix(), end: dayMoment.utc().add('24', 'hours').unix() });
        }
        return timeRanges;
    }

    async getMonthlyChart(){
        const months = [ "January", "February", "March", "April", "May", "June", 
        "July", "August", "September", "October", "November", "December" ];
           
        let chartData = [];
        const monthlyTimeRanges = this.generateMonthlyTimeRanges();
        for (let i in monthlyTimeRanges) {
            const timeRange = monthlyTimeRanges[i];
            const netProfit = await this.calculateNetProfit(timeRange.start, timeRange.end);
            chartData.push(parseFloat((netProfit).toFixed(2)));
        }

        return [ ...chartData];
    }

    async getNewUsersData() {
        let newUsers = [];
        const timeRanges = [
            { startTime: this.startOfTodayMoment, key: 'DAILY' },
            { startTime: this.startOfWeekMoment, key: 'WEEKLY' },
            { startTime: this.startOfMonthMoment, key: 'MONTHLY' },
            { startTime: moment(0), key: 'ALL TIME' },
        ];
        for (let i in timeRanges) {
            const timeRange = timeRanges[i];
            const timestamp = timeRange.startTime.format('YYYY-MM-DD HH:mm:ss');
            const time = timeRange.startTime.utc().unix();
            const count = (await this.modules.db.query("SELECT COUNT(1) as count FROM users WHERE createdAt >= ?", [time]))[0].count;
            newUsers.push({key: timeRange.key, count})
        }
        return newUsers;
    }

    async getLatests() {
        const latestsData = {trades: [] };
        latestsData.trades = await this.modules.db.query("SELECT user_trades.*, user_data_common.displayName, user_data_common.avatar FROM user_trades INNER JOIN user_data_common ON user_data_common.userId = user_trades.userId ORDER BY id DESC LIMIT 100");
        return latestsData;
    }

    async getDashboardData() {
        const dashboardData = { dailyStats: {}, charts: {} };

        dashboardData.dailyStats = await this.getDailyStats();

        dashboardData.generalStats = await this.getGeneralStats();

        dashboardData.charts.daily = await this.getDailyTable();
        dashboardData.charts.monthly = await this.getMonthlyChart();
        
        dashboardData.newUsersData = await this.getNewUsersData();

        dashboardData.latestsData = await this.getLatests();


        return dashboardData;
    }


}