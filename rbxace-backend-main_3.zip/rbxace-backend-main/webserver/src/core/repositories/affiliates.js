module.exports = class {

  constructor(params) {
    params.inject(this);

    this.getStatsCharts(4);
  }

  async getStatsCharts(codeId) {
    const functionKeys = [ 'Monthly', 'ThisMonths', 'Todays' ];
    const chartKeys = {
      'Monthly': 'allTime',
      'ThisMonths': 'monthly',
      'Todays': 'daily'
    };
    const charts = { allTime: [], monthly: [], daily: [] };
    for (let i in functionKeys) {
      const functionKey = functionKeys[i];
      const chartKey = chartKeys[functionKey];

      if (i > 0 && charts['allTime'].length == 0) continue;

      let start, end = null;
      if (functionKey == 'Monthly') {
        let startSql = await this.modules.db.query("SELECT time FROM affiliate_earnings WHERE codeId = ? ORDER BY time ASC LIMIT 1", [codeId]);
        if (startSql.length > 0) start = startSql[0].time;

        let endSql =  await this.modules.db.query("SELECT time FROM affiliate_earnings WHERE codeId = ? ORDER BY time DESC LIMIT 1", [codeId]);
        if (endSql.length > 0) end = endSql[0].time;
      }
      const timeRanges = this.repositories.stats[`generate${functionKey}TimeRanges`](start, end);
  
      let dataset = [];
      for (let j in timeRanges) {
        const timeRange = timeRanges[j];
        let valueSql = (await this.modules.db.query("SELECT SUM(feeAmount) as value FROM affiliate_earnings WHERE codeId = ? AND time > ? AND time <= ?", [codeId, timeRange.start, timeRange.end]));
        const value = valueSql.length > 0 ? (valueSql[0].value || 0) : 0
        dataset.push(parseFloat( (value / 1000).toFixed(2 )));
      }

      charts[chartKey] = dataset;
    }
    return charts;
  }

  async getLevelData(amount) {
    const levelsData = await this.modules.db.query("SELECT * FROM affiliate_level_table ORDER BY level ASC");
    for (let i in levelsData) {
      const levelData = levelsData[i];
      if (amount >= levelData.max && levelData.max !== 0) continue;
      let currentProgress = 0;
      let diff = levelData.max - levelData.min;
      let expDiff = amount - levelData.min;
      currentProgress = parseFloat(((expDiff / diff) * 100).toFixed(2));
      let requiredAmount = levelData.max - expDiff;
      if (levelData.max == 0) {
        currentProgress = 0;
        requiredAmount = 0;
      }
      return {
        levels: levelsData,
        exp: amount,
        currentProgress, 
        requiredAmount,
        currentLevel: levelData.level,
        currentCut: levelData.cut
      };
    }
  }

}