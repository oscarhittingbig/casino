const crypto = require("crypto");
const { v1: uuidv1 } = require('uuid');
const shortid = require("shortid");

module.exports = class {


    constructor(params) {
        params.inject(this);

        //let passhash = this.generatePasswordHash('12345678a');
        //console.log(passhash)
    }

    clearIllegalChars(str) {
        return str.replace(/([\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g, '')
    }

    isEmailValid(email) {
        let emailDomain = email.split("@")[1];
        if (!this.modules.email_validator.validate(email) || domains.includes(emailDomain)) {
            throw new Error("E-mail you entered is not valid!");
        }

        return true;
    }

    generatePasswordHash(password) {
        return crypto.createHash("sha512").update(password + ":" + process.env.AUTH_LOGIN_SALT_PASSWORD).digest("hex");
    }

    generateAuthToken(userId) {
        return crypto.createHash('sha512').update(userId + ':' + process.env.AUTH_LOGIN_SALT_TOKEN + ':' + new Date().getTime() + ':' + uuidv1()).digest("hex");
    }


    async updateAuthToken(userId, userAgent, ipAddress) {
        let authToken = this.generateAuthToken(userId);
        let updateSql = await this.modules.db.call(`auth_updateAuthToken(?, ?, ?, ?)`, [userId, authToken, userAgent, ipAddress]);
        if (!updateSql.success) throw new Error('Something went wrong while updating auth token!');
        return authToken;
    }

    
    async getUserIdThroughExternalLogin(accountType, accountId, displayName, avatar, userAgent, ipAddress) {
        const urlId = shortid.generate();
        let loginSql = await this.modules.db.call(`auth_handleExternalLogin(?, ?, ?, ?, ?, ?, ?)`, [accountType, accountId, urlId, displayName, avatar, userAgent, ipAddress]);
        if (!loginSql.success) throw new Error('Something went wrong on database!');

        return loginSql.params.userId;
    }

}
