const Chance = require('chance');

module.exports = class {
    constructor(params) {
        params.inject(this);

        this.defs = {
            CASES: [
                {
                    id: 1,
                    requiredLevel: 5,
                    defs: [
                        { amount: 10, type: 'COINS', chance: 85 },
                        { amount: 100, type: 'ITEM', chance: 12.5 },
                        { amount: 250, type: 'ITEM', chance: 2.5 }
                    ],
                },
                {
                    id: 2,
                    requiredLevel: 10,
                    defs: [
                        { amount: 10, type: 'COINS', chance: 99 },
                        { amount: 4500, type: 'ITEM', chance: 1 }
                    ],
                },
                {
                    id: 3,
                    requiredLevel: 20,
                    defs: [
                        { amount: 10, type: 'COINS', chance: 95 },
                        { amount: 3000, type: 'ITEM', chance: 3 },
                        { amount: 2000, type: 'ITEM', chance: 2 },
                    ],
                },
                {
                    id: 4,
                    requiredLevel: 30,
                    defs: [
                        { amount: 10, type: 'COINS', chance: 90 },
                        { amount: 2500, type: 'ITEM', chance: 5 },
                        { amount: 3000, type: 'ITEM', chance: 5 },
                    ],
                },
                {
                    id: 5,
                    requiredLevel: 40,
                    defs: [
                        { amount: 10, type: 'COINS', chance: 70 },
                        { amount: 3000, type: 'ITEM', chance: 25 },
                        { amount: 7500, type: 'ITEM', chance: 5 },
                    ],
                },
                {
                    id: 6,
                    requiredLevel: 50,
                    defs: [
                        { amount: 10, type: 'COINS', chance: 60 },
                        { amount: 3000, type: 'ITEM', chance: 39 },
                        { amount: 80000, type: 'ITEM', chance: 1 },
                    ],
                },
                {
                    id: 7,
                    requiredLevel: 60,
                    defs: [
                        { amount: 10, type: 'COINS', chance: 90 },
                        { amount: 110000, type: 'ITEM', chance: 1 },
                        { amount: 10000, type: 'ITEM', chance: 9 },
                    ],
                },
                {
                    id: 8,
                    requiredLevel: 70,
                    defs: [
                        { amount: 10, type: 'COINS', chance: 90 },
                        { amount: 25000, type: 'ITEM', chance: 5 },
                        { amount: 10000, type: 'ITEM', chance: 5 },
                    ],
                },
                {
                    id: 9,
                    requiredLevel: 80,
                    defs: [
                        { amount: 1000, type: 'COINS', chance: 50 },
                        { amount: 2000, type: 'ITEM', chance: 19 },
                        { amount: 10000, type: 'ITEM', chance: 30 },
                        { amount: 180000, type: 'ITEM', chance: 0.5 },
                        { amount: 50000, type: 'ITEM', chance: 0.5 },
                    ],
                },
                {
                    id: 10,
                    requiredLevel: 90,
                    defs: [
                        { amount: 250, type: 'COINS', chance: 50 },
                        { amount: 5000, type: 'ITEM', chance: 49 },
                        { amount: 50000, type: 'ITEM', chance: 0.8 },
                        { amount: 800000, type: 'ITEM', chance: 0.2 },
                    ],
                },
                {
                    id: 11,
                    requiredLevel: 100,
                    defs: [
                        { amount: 3000, type: 'COINS', chance: 70 },
                        { amount: 5000, type: 'ITEM', chance: 20 },
                        { amount: 10000, type: 'ITEM', chance: 9 },
                        { amount: 180000, type: 'ITEM', chance: 1 }
                    ],
                },
                {
                    id: 12,
                    requiredLevel: 200,
                    defs: [
                        { amount: 12000, type: 'COINS', chance: 50 },
                        { amount: 20000, type: 'ITEM', chance: 30 },
                        { amount: 50000, type: 'ITEM', chance: 13.3 },
                        { amount: 100000, type: 'ITEM', chance: 6.7 },
                    ],
                }
            ]
        };

        this.cachedDef = {};
        this.cases = [];
    }

    async init() {
        this.loadCache();
        await this.compareCache();
    }

    async loadCache() {
        const cache = this.modules.cache.fileGet('daily-cases');
        if (Array.isArray(cache)) return;
        this.cachedDef = cache.defs;
        this.cases = cache.cases;
    }

    async compareCache() {
        let generate = false;
        if (Array.isArray(this.cachedDef)) {
            generate = true;
        } else {
            const currentDefString = JSON.stringify(this.defs);
            const cachedDefString = JSON.stringify(this.cachedDef);
            if (currentDefString !== cachedDefString) generate = true;
        }
        if (generate) {
            await this.generateCases();
            this.saveCache();
        }
    }

    saveCache() {
        const cachedToBeSaved = {
            defs: this.defs,
            cases: this.cases
        };
        this.modules.cache.fileSet('daily-cases', cachedToBeSaved);
    }

    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    generateCaseAnimationSlots(ingredients) {
        ingredients = JSON.parse(JSON.stringify(ingredients));
        let animationSlots = [];
        while (true) {
            let anyAddition = false;
            for (let i in ingredients) {
                const ingredient = ingredients[i];
                if (ingredient.chance > 0) {
                    ingredient.chance -= 5;
                    anyAddition = true;
                    animationSlots.push(i);
                }
            }
            if (!anyAddition) break;
        }
        return this.shuffleArray(animationSlots);
    }

    async generateCases() {
        const priceList = this.repositories.item.getPriceList();

        const casesCloned = JSON.parse(JSON.stringify(this.defs.CASES));
        for (let i in casesCloned) {
            const caseCloned = casesCloned[i];
            let ingredients = [];
            let ticketRanges = [];
            let lastRange = 0;
            for (let j in caseCloned.defs) {
                const def = caseCloned.defs[j];
                let item = null;
                if (def.type == 'ITEM') {
                    const expectedPrice = Math.floor(def.amount / 10);
                    item = await this.repositories.item.findClosestItem(expectedPrice, priceList);
                    item.price = expectedPrice;
                }
                ingredients.push({ item, chance: def.chance, prize: def.amount, type: def.type });
                ticketRanges.push({ index: j, min: (lastRange / 100), max: (lastRange + def.chance) / 100 });
                lastRange += def.chance;

            }
            caseCloned.ingredients = ingredients;
            caseCloned.ticketRanges = ticketRanges;
            caseCloned.animationSlots = this.generateCaseAnimationSlots(ingredients);
            delete caseCloned.defs;
        }

        this.cases = casesCloned;
    }




}
