const Chance = require('chance');

module.exports = class {
    constructor(params) {
        params.inject(this);
    }

    get wrapper() {
        return this.repositories.dailycases;
    }

    getItemWonIndex(targetCase, ticket) {
        for (let i in targetCase.ticketRanges) {
            const ticketRange = targetCase.ticketRanges[i];
            if (ticket >= ticketRange.min && ticket < ticketRange.max) return i;
        }
        return 0;
    }

    generateRandomSlotOffset(targetCase, targetIngredientIndex) {
        const targetItemSlots = [];
        for (let i in targetCase.animationSlots) {
            const ingredientIndex = targetCase.animationSlots[i];
            if (ingredientIndex == targetIngredientIndex) targetItemSlots.push(i);
        }

        return targetItemSlots[Math.floor(Math.random() * targetItemSlots.length)];
    }

    open(caseId) {
        const targetCase = this.wrapper.core.cases.find(entry => entry.id == caseId);
        const ticket = new Chance().floating({min: 0, max: 1, fixed: 15});
        const itemWonIndex = this.getItemWonIndex(targetCase, ticket);
        const ingredientWon = targetCase.ingredients[itemWonIndex];
        const slotOffset = this.generateRandomSlotOffset(targetCase, itemWonIndex);
        const wobble = Math.random();
        return {
            ticket,
            ingredientWon,
            slotOffset,
            wobble,
            winnings: ingredientWon.prize
        };
    }

    async getLastOpenDay(userId) {
        const lastOpenDaySql = (await this.modules.db.query("SELECT day FROM dailycases_opens WHERE userId = ? ORDER BY id ASC", [userId]));
        return lastOpenDaySql.length ? lastOpenDaySql[0].day : 0;
    }

}
