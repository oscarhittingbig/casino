const crypto = require('crypto')
const DiscordOauth2 = require("discord-oauth2");
const oauth = new DiscordOauth2({
    clientId: process.env.DISCORD_API_CLIENTID,
    clientSecret: process.env.DISCORD_API_SECRET,
    redirectUri: process.env.domain + 'auth/discord/callback',
    requestTimeout: 5 * 1000
});

const APP_GUILD_ID = "878524647237357589";

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.guild = null;
        //this.init();
        //this.veryTestFunc();
    }
    async veryTestFunc() {

        const response = await this.generateRedirectUrl(4);
        console.log(response)

        /*
        const accessToken = "3FTnWs5w9Qh6NzrCbwevIjGsN9kVaH";
        let userData = await oauth.getUser(accessToken);
        console.log(userData)

        const userGuildsData = await oauth.getUserGuilds(accessToken);
        console.log(userGuildsData)
        */
    }

    async checkIfUserHasToken(userId) {
        const dbUserRedirect = await this.modules.db.select("discord_user_redirects", "userId", userId);
        if (!dbUserRedirect) return false;
        return true;
    }

    async getUserAccessToken(userId) {
        const dbDiscordUserLink = await this.modules.db.select("discord_user_links", "userId", userId);
        if (!dbDiscordUserLink) return false;
        return true;

        let accessToken = dbDiscordUserLink.accessToken;
        let userData = null;
        try {
            userData = await oauth.getUser(accessToken);
        } catch (err) { }

        if (userData && userData.id == dbDiscordUserLink.discordUserId) return accessToken;
        await this.modules.db.exec("DELETE FROM discord_user_links WHERE userId = ?", [userId]);
        return false;
        /*
        const tokenData = await oauth.tokenRequest({
            clientId: process.env.DISCORD_API_CLIENTID,
            clientSecret: process.env.DISCORD_API_SECRET,
            refreshToken: dbDiscordUserLink.refreshToken,
            grantType: "refresh_token"
        });
        */
    }

    async checkUserInGuild(accessToken) {
        const userGuildsData = await oauth.getUserGuilds(accessToken);
        if (!userGuildsData) throw new Error("API_REPO_DISCORD_FETCHERROR");
        const inGuild = userGuildsData.filter(el => el.id == APP_GUILD_ID).length > 0;
        if (!inGuild) throw new Error("API_REPO_DISCORD_NOTINOURSERVER");
    }

    async generateRedirectUrl(userId) {
        const state = crypto.randomBytes(24).toString("hex");
        const insertSuccess = await this.modules.db.exec("INSERT INTO discord_user_redirects SET ?", [{
            state,
            userId,
            createdAt: Math.floor(Date.now() / 1000)
        }]);
        if (!insertSuccess) throw new Error("Something went wrong while inserting discord redirect state!");
        return oauth.generateAuthUrl({
            scope: ["identify", "guilds"],
            state,
            responseType: 'code',
            guildId: APP_GUILD_ID,
            
        });

    }

    async handleCallback(req, res) {
        try {
            let { code, state } = req.query;
            const validationRegex = /^[a-z0-9]+$/i;
            if (!code || !state || !validationRegex.test(code) || !validationRegex.test(state) || code.length > 128 || state.length > 128) return;

            const dbDiscordUserRedirect = await this.modules.db.select("discord_user_redirects", "state", state);
            if (!dbDiscordUserRedirect) return;

            const requestData = {
                clientId: process.env.DISCORD_API_CLIENTID,
                clientSecret: process.env.DISCORD_API_SECRET,
                code: code,
                scope: "identify guilds",
                grantType: "authorization_code",
                redirectUri: process.env.domain + 'auth/discord/callback',
            };
            const tokenData = await oauth.tokenRequest(requestData);
            const accessToken = tokenData.access_token;
            const refreshToken = tokenData.refresh_token;
            const userData = await oauth.getUser(accessToken);

            const userId = dbDiscordUserRedirect.userId;
            try {
                await this.repositories.discord.checkUserInGuild(accessToken);
               
                await this.modules.db.exec("INSERT IGNORE INTO discord_user_links SET ?", [{
                    userId,
                    discordUserId: userData.id,
                    discordUserName: userData.username,
                    discordUserDiscriminator: userData.discriminator,
                    accessToken,
                    refreshToken,
                    createdAt: Math.floor(Date.now() / 1000)
                }]);
                
                this.repositories.user.notify({ userId, type: 'success', message: 'API_REPO_DISCORD_AUTHSUCCESS' });
            } catch (err) {
                console.log('err', err);
                this.repositories.user.notify({ userId, type: 'error', message: err.message });
                //this.externalModules.user.sendMsg(userId, { type: 'error', msg: err.message });
            }

            this.repositories.socket.publishToUser(userId, 'user:closeDiscordAuth', true);

        } catch (err) {
            console.log('err', err);
        }
        res.write("YOU CAN CLOSE THE WINDOW!");
    }
}