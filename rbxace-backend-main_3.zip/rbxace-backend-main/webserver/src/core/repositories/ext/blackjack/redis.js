const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  get wrapper() {
    return this.repositories.ext.blackjack;
  }

  getTable(data) {
    const targetTableId = data.tableId;
    const tableTypes = Object.keys(this.repositories.ext.blackjack.game.tables);
    for (let i in tableTypes) {
      const tableType = tableTypes[i];
      const table = this.repositories.ext.blackjack.game.tables[tableType].find(el => el.id == targetTableId);
      if (table) return table;
      /*
      const tableIds = Object.keys(this.repositories.ext.blackjack.game.tables[tableType]);
      for (let j in tableIds) {
        const tableId = tableIds[j];
        if (tableId === targetTableId) 
        return this.repositories.ext.blackjack.game.tables[tableType][tableId];
      }
      */
    }
    return null;
  
  }

  getPlayer(table, data) {
    const { offset } = data;
    return table.players[offset];
  }


  async on_round_setPhase(data) {
    const { newPhase, newLastPhaseStartedAt } = data;
    //reset decisions there maybe
    const table = this.getTable(data);
    if (!table) return;
    table.phase = newPhase;
    table.lastPhaseStartedAt = newLastPhaseStartedAt;
  }

  async on_round_setData(data) {
    const { newData } = data;
    let table = this.getTable(data);
    if (!table) return;
    for (let i in this.repositories.ext.blackjack.game.tables[table.type]) {
      if(this.repositories.ext.blackjack.game.tables[table.type][i].id == table.id) {
        this.repositories.ext.blackjack.game.tables[table.type][i] = newData;
      }
    }
  }

  
  async on_round_setPlayingPlayerOffset(data) {
    const { newOffset } = data;
    let table = this.getTable(data);
    if (!table) return;
    table.playingPlayerOffset = newOffset;
  }

  async on_round_resetPhaseTimer(data) {
    const { newLastPhaseStartedAt } = data;
    const table = this.getTable(data);
    if (!table) return;
    table.lastPhaseStartedAt = newLastPhaseStartedAt;
  }

  async on_round_resetUserDecisions(data) {
    const table = this.getTable(data);
    if (!table) return;
    const playerOffsets = Object.keys(table.players);
    for (let i in playerOffsets) {
      const offset = playerOffsets[i];
      table.players[offset].lastDecision = null;
    }
  }

  async on_round_removeInsurances(data) {
    const table = this.getTable(data);
    if (!table) return;
    const playerOffsets = Object.keys(table.players);
    for (let i in playerOffsets) {
      const offset = playerOffsets[i];
      table.players[offset].insuranceCost = 0;
    }
  }

  
  async on_round_setSideBetPayouts(data) {
    const table = this.getTable(data);
    if (!table) return;
    const playerOffsets = Object.keys(table.players);
    for (let i in playerOffsets) {
      const offset = playerOffsets[i];
      table.players[offset].bets['21+3'] = 0;
      table.players[offset].bets['PERFECT_PAIRS'] = 0;
    }
  }


  async on_player_setUser(data) {
    const { user, bets } = data;
    let table = this.getTable(data);
    if (!table) return;
    let player = this.getPlayer(table, data);
    player.user = user;
    player.bets = bets;
  }

  async on_player_setBetAmount(data) {
    const { handType, newBet } = data;
    let table = this.getTable(data);
    let player = this.getPlayer(table, data);
    player.bets[handType] = newBet;
  }

  async on_player_setBets(data) {
    const { newBets } = data;
    let table = this.getTable(data);
    let player = this.getPlayer(table, data);
    player.bets = newBets;
  }

  async on_player_pushCard(data) {
    const { handType, newCard, newScore } = data;
    let table = this.getTable(data);
    let player = this.getPlayer(table, data);
    player.hands[handType].cards.push(newCard);
    player.hands[handType].score = newScore;
  }

  async on_player_setDecision(data) {
    const { newDecision } = data;
    let table = this.getTable(data);
    let player = this.getPlayer(table, data);
    player.lastDecision = newDecision;
  }

  async on_player_setDecisionHand(data) {
    const { newDecisionHand } = data;
    let table = this.getTable(data);
    let player = this.getPlayer(table, data);
    player.decisionHand = newDecisionHand;
  }
  async on_player_addInsurance(data) {
    const { newInsuranceCost } = data;
    let table = this.getTable(data);
    let player = this.getPlayer(table, data);
    player.insuranceCost = newInsuranceCost;
    //player.bets['MAIN'] = newBetAmount;
  }

  async on_player_splitHand(data) {
    const { newHands, newDecisionHand } = data;
    let table = this.getTable(data);
    let player = this.getPlayer(table, data);
    player.hands = newHands;
    player.decisionHand = newDecisionHand;
    player.splitted = true;
    player.bets['MAIN'].amount = 0;
  }

  async on_player_doubleDown(data) {
    const { handKey, betAmount } = data;
    let table = this.getTable(data);
    let player = this.getPlayer(table, data);
    player.hands[handKey].betAmount = betAmount;
  }


  async on_dealer_pushCard(data) {
    const { newCard, newScore } = data;
    let table = this.getTable(data);
    table.dealer.hand.cards.push(newCard);
    table.dealer.hand.score = newScore;
  }

  async on_dealer_showHiddenCard(data) {
    const { newCard, newScore } = data;
    let table = this.getTable(data);
    table.dealer.hand.cards[1] = newCard;
    table.dealer.hand.score = newScore;
  }


}