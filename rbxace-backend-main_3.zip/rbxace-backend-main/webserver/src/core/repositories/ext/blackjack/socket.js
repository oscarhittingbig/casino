module.exports = class {

  constructor(params) {
    params.inject(this);

  }

  async injectEventHandlers(socket) {
    socket.on("blackjack:tables:subscribe", (data) => this.on_tables_subscribe(socket, data));
    socket.on("blackjack:tables:unsubscribe", (data) => this.on_tables_unsubscribe(socket, data));
    socket.on("blackjack:table:subscribe", (data) => this.on_table_subscribe(socket, data));
    socket.on("blackjack:table:unsubscribe", (data) => this.on_table_unsubscribe(socket, data));

    socket.on("blackjack:player:sit", (data) => this.on_player_sit(socket, data));
    socket.on("blackjack:player:placeBet", (data) => this.on_player_placeBet(socket, data));
    socket.on("blackjack:player:commandBet", (data) => this.on_player_commandBet(socket, data));
    socket.on("blackjack:player:setInsuranceStatus", (data) => this.on_player_setInsuranceStatus(socket, data));

    socket.on("blackjack:player:setDecision", (data) => this.on_player_setDecision(socket, data));
    socket.on("blackjack:player:stand", (data) => this.on_player_stand(socket, data));
    socket.on("blackjack:player:hit", (data) => this.on_player_hit(socket, data));
    socket.on("blackjack:player:doubleDown", (data) => this.on_player_doubleDown(socket, data));
    socket.on("blackjack:player:splitHand", (data) => this.on_player_splitHand(socket, data));

  }

  async on_tables_subscribe(socket, data) {
    socket.join('game:blackjack:tables');

    const packetData = {
      tables: this.repositories.ext.blackjack.game.tables,
      time: Date.now()
    };

    socket.emit('blackjack:tables:info', packetData);
  }
  async on_tables_unsubscribe(socket, data) {
    socket.leave('game:blackjack:tables');
  }

  async on_table_subscribe(socket, data) {
    if (!data || !data.id || !data.type || typeof data.id !== 'string' || data.id.length <= 3 || data.id.length >= 64 || typeof data.type !== 'string') return;
    const tableId = this.repositories.protection.clearIllegalChars(data.id);
    const tableType = this.repositories.protection.clearIllegalChars(data.type);

    const availableTableTypes = ['STANDARD', 'HIGHROLLER'];
    if (!availableTableTypes.includes(tableType)) return;

    const table = this.repositories.ext.blackjack.game.tables[tableType].find(el => el.id == tableId);
    if (!table) return;
    const packetData = {
      defs: this.repositories.ext.blackjack.game.defs,
      tableData: table,
      time: Date.now()
    };
    socket.join(`game:blackjack:table:${tableId}`);
    socket.emit('blackjack:table:info', packetData);

  }

  async on_table_unsubscribe(socket, data) {
    if (!data || !data.id || typeof data.id !== 'string' || data.id.length <= 3 || data.id.length >= 64) return;
    const tableId = this.repositories.protection.clearIllegalChars(data.id);
    socket.leave(`game:blackjack:table:${tableId}`);
  }

  async on_player_sit(socket, data) {
    try {
      if (!data || !data.offset || !data.tableId || typeof data.tableId !== 'string' || data.tableId.length <= 3 || data.tableId.length >= 64 || !socket.user.isLoggedIn) return;
      this.repositories.protection.checkMemCooldown('SOCKET_BLACKJACK_PLAYER_SIT', socket.user.id, 5);

      const tableId = this.repositories.protection.clearIllegalChars(data.tableId);
      const offset = parseInt(data.offset);
      if (isNaN(offset) || offset < 1 || offset > 5) return;


      const packetData = {
        user: this.repositories.user.getUserProfile(socket.user),
        tableId,
        offset
      };
      this.repositories.redis.publish("head", "blackjack:player:sit", packetData);
    } catch (err) {

    }
  }

  async on_player_leave(socket, data) {
    try {
      if (!data || !data.offset || !data.tableId || typeof data.tableId !== 'string' || data.tableId.length <= 3 || data.tableId.length >= 64 || !socket.user.isLoggedIn) return;
      this.repositories.protection.checkMemCooldown('SOCKET_BLACKJACK_PLAYER_LEAVE', socket.user.id, 1);

      const tableId = this.repositories.protection.clearIllegalChars(data.tableId);
      const packetData = {
        user: this.repositories.user.getUserProfile(socket.user),
        tableId
      };
      this.repositories.redis.publish("head", "blackjack:player:leave", packetData);
    } catch (err) {

    }
  }

  async on_player_placeBet(socket, data) {
    let messageParams = [];
    try {

      if (global.settings.maintenance) throw new Error("PAGE_GAMES_MAINTENANCE")
      if (!data || !data.betType || !data.betAmount || typeof data.betType !== 'string' || !data.tableId || typeof data.tableId !== 'string' || data.tableId.length <= 3 || data.tableId.length >= 64 || !socket.user.isLoggedIn) return;
      this.repositories.protection.checkMemCooldown('SOCKET_BLACKJACK_PLAYER_PLACEBET', socket.user.id, 0.1);

      const tableId = this.repositories.protection.clearIllegalChars(data.tableId);
      const availableBetTypes = ['MAIN', '21+3', 'PERFECT_PAIRS'];
      const betType = data.betType;
      if (!availableBetTypes.includes(betType)) return;

      const betAmount = parseInt(data.betAmount);
      if (!this.repositories.protection.isValidAmount(betAmount)) return; //socket emit, inform user?

      const packetData = {
        user: this.repositories.user.getUserProfile(socket.user),
        betAmount,
        betType,
        tableId
      };
      this.repositories.redis.publish("head", "blackjack:player:placeBet", packetData);
    } catch (err) {
      socket.emit('user:notify', { type: 'error', message: err.message, messageParams });
    }
  }

  async on_player_commandBet(socket, data) {
    try {
      if (!data || !data.command || typeof data.command !== 'string' || !data.tableId || typeof data.tableId !== 'string' || data.tableId.length <= 3 || data.tableId.length >= 64 || !socket.user.isLoggedIn) return;
      this.repositories.protection.checkMemCooldown('SOCKET_BLACKJACK_PLAYER_COMMANDBET', socket.user.id, 0.1);

  
      const tableId = this.repositories.protection.clearIllegalChars(data.tableId);
      const availableCommands = ['DOUBLE', 'REDO', 'CLEAR'];
      const command = data.command;
      if (!availableCommands.includes(command)) return;

      const packetData = {
        user: this.repositories.user.getUserProfile(socket.user),
        command,
        tableId
      };
      this.repositories.redis.publish("head", "blackjack:player:commandBet", packetData);
    } catch (err) {

    }
  }



  async on_player_setInsuranceStatus(socket, data) {
    try {
      if (!data || !data.tableId || typeof data.tableId !== 'string' || data.tableId.length <= 3 || data.tableId.length >= 64 || !socket.user.isLoggedIn) return;
      this.repositories.protection.checkMemCooldown('SOCKET_BLACKJACK_PLAYER_SETINSURANCESTATUS', socket.user.id, 5);

      const tableId = this.repositories.protection.clearIllegalChars(data.tableId);
      const wants = data.wants == true;

      const packetData = {
        tableId,
        user: this.repositories.user.getUserProfile(socket.user),
        wants
      };
      this.repositories.redis.publish("head", "blackjack:player:setInsuranceStatus", packetData);
    } catch (err) {

    }
  }

  async on_player_setDecision(socket, data) {
    try {
      if (!socket.user.isLoggedIn || !data.decision || typeof data.decision !== 'string' || !data.tableId || typeof data.tableId !== 'string' || data.tableId.length <= 3 || data.tableId.length >= 64) return;
      this.repositories.protection.checkMemCooldown('SOCKET_BLACKJACK_PLAYER_SETDECISION', socket.user.id, 0.5);

      const availableDecisions = ['HIT', 'STAND', 'SPLIT', 'DOUBLEDOWN'];
      const decision = data.decision;
      if (!availableDecisions.includes(decision)) return;

      const tableId = this.repositories.protection.clearIllegalChars(data.tableId);
      const packetData = {
        tableId,
        user: this.repositories.user.getUserProfile(socket.user),
        decision
      };
      this.repositories.redis.publish("head", "blackjack:player:setDecision", packetData);
    } catch (err) {

    }
  }

  async on_player_hit(socket, data) {
    try {
      if (!socket.user.isLoggedIn || !data.tableId || typeof data.tableId !== 'string' || data.tableId.length <= 3 || data.tableId.length >= 64) return;
      this.repositories.protection.checkMemCooldown('SOCKET_BLACKJACK_PLAYER_HIT', socket.user.id, 0.1);

      const tableId = this.repositories.protection.clearIllegalChars(data.tableId);
      const packetData = {
        user: this.repositories.user.getUserProfile(socket.user)
      };
      this.repositories.redis.publish("head", "blackjack:player:hit", packetData);
    } catch (err) {

    }
  }

  async on_player_doubleDown(socket, data) {
    try {
      if (!socket.user.isLoggedIn || !data.tableId || typeof data.tableId !== 'string' || data.tableId.length <= 3 || data.tableId.length >= 64) return;
      this.repositories.protection.checkMemCooldown('SOCKET_BLACKJACK_PLAYER_DOUBLEDOWN', socket.user.id, 5);

      const tableId = this.repositories.protection.clearIllegalChars(data.tableId);
      const packetData = {
        user: this.repositories.user.getUserProfile(socket.user)
      };
      this.repositories.redis.publish("head", "blackjack:player:doubleDown", packetData);
    } catch (err) {

    }
  }

  async on_player_splitHand(socket, data) {
    try {
      if (!socket.user.isLoggedIn || !data.tableId || typeof data.tableId !== 'string' || data.tableId.length <= 3 || data.tableId.length >= 64) return;
      this.repositories.protection.checkMemCooldown('SOCKET_BLACKJACK_PLAYER_SPLITHAND', socket.user.id, 5);

      const tableId = this.repositories.protection.clearIllegalChars(data.tableId);
      const packetData = {
        user: this.repositories.user.getUserProfile(socket.user)
      };
      this.repositories.redis.publish("head", "blackjack:player:splitHand", packetData);
    } catch (err) {

    }
  }




}