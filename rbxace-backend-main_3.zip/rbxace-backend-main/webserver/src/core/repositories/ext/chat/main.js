module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      COOLDOWN_SEND: 700,
      MAX_MESSAGE_COUNT: 50
    }


    this.messages = { 'EN': [], 'RU': [], 'FR': [], 'ES': [], 'TR': [] };
  }


  pushClear(channel, userId) {
    if (userId) {
        let channels = Object.keys(this.messages);
        for (let i = 0; i < channels.length; i++) {
            let channelKey = channels[i];

            this.messages[channelKey] = this.messages[channelKey].filter(
              (message) => message.type != "USER" || message.user.id != userId
            );
        }
    } else {
        this.messages[channel] = [];
    }
}

  getHistory(channel) {
    if (this.messages[channel] == undefined) {
      return null;
    } else {
      return this.messages[channel];
    }
  }

  pushMessage(channel, message) {
    if (!this.messages[channel]) return;
    this.messages[channel].push(message);
    if (this.messages[channel].length > this.defs.MAX_MESSAGE_COUNT) {
      this.messages[channel] = this.messages[channel].slice(-this.defs.MAX_MESSAGE_COUNT);
    }
  }

  mute(userId, muteEndsAt) {
    let users = this.repositories.socket.getUsersInRoom(userId);
    users.forEach(user => {
      user.muteEndsAt = muteEndsAt;
    });
    this.pushClear(null, userId)
  }

  unmute(userId) {
    let users = this.repositories.socket.getUsersInRoom(userId);
    users.forEach(user => {
      user.muteEndsAt = 0;
    });
  }

  ban(userId) {
    let users = this.repositories.socket.getUsersInRoom(userId);
    users.forEach(user => {
      user.isBanned = true;
    });
  }

  unban(userId) {
    let users = this.repositories.socket.getUsersInRoom(userId);
    users.forEach(user => {
      user.isBanned = false;
    });
  }
}