const moment = require('moment');
const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {
      COOLDOWN_SEND: 4750
    }

  }

  isEmptyOrSpaces(str) {
    return str === null || str.match(/^ *$/) !== null;
  }


  async injectEventHandlers(socket) {
    socket.on("chat:subscribe", (data) => this.on_subscribe(socket, data));
    socket.on("chat:sendMessage", (data) => this.on_sendMessage(socket, data));
  }


  async on_subscribe(socket, data) {
    if (!data || !data.channel || !this.repositories.ext.chat.main.messages[data.channel]) return;
    socket.join(`chat-${data.channel}`);
    socket.emit('chat:channelHistory', { channel: data.channel, messages: this.repositories.ext.chat.main.messages[data.channel] });
  }

  async on_sendMessage(socket, data) {
    if (!socket.user.isLoggedIn || !data || !data.channel || !data.content) return;
    if (typeof data.channel !== 'string' || typeof data.content !== 'string') return;
    if (!this.repositories.ext.chat.main.messages[data.channel] || data.content.length > 180) return;
    data.content = global.clearHTML(data.content);
    if (this.isEmptyOrSpaces(data.content)) return;

    try {
      if (socket.user.isBanned) throw new Error("You have been banned!");
      const nowUnix = moment().utc().unix();
      if (nowUnix < socket.user.muteEndsAt && socket.user.roleLevel < 10) {
        const diff = socket.user.muteEndsAt - nowUnix;
        throw new Error(`You have been muted for ${diff} seconds!`);
      }

      const now = Date.now();
      const chatCd = now - socket.user.lastMessage;
      if (socket.user.lastMessage && chatCd <= this.defs.COOLDOWN_SEND && socket.user.roleLevel < 10) throw new Error("Calm down!");

      socket.user.lastMessage = now;

      const messageData = {
        channel: data.channel,
        message: {
          user: this.repositories.user.getUserProfile(socket.user),
          content: data.content,
          type: 'USER'
        }
      };

      this.repositories.redis.publish("head", "chat:sendMessage", messageData);
    } catch (err) {
      socket.emit('chat:pushMessage', {
        channel: data.channel,
        message: {
          id: uuidv1(),
          type: 'SYS',
          content: err.message
        }
      });
    }
  }


}