module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {};
    this.rooms = [];
    this.history = [];
    this.stats = { 'BLACK': 0, 'RED': 0, 'TOTAL': 0 };

  }



}