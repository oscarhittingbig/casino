const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  getRoom(data) {
    const { roomId } = data;
    let room = this.repositories.ext.coinflip.game.rooms.find(el => el.id == roomId);
    return room;
  }

  async on_coinflip_pushRoom(data) {
    this.repositories.ext.coinflip.game.rooms.push(data);
  }

  async on_coinflip_clearOpponent(data) {
    let room = this.getRoom(data);
    if (!room) return;
    delete room.opponent;
    room.phase = 'AWAITING_OPPONENT';
  }

  async on_coinflip_setOpponent(data) {
    let room = this.getRoom(data);
    if (!room) return;
    const { opponent, lastUpdateMs, chances } = data;
    room.opponent = opponent;
    room.opponent.chance = chances.opponentChance;
    room.owner.chance = chances.ownerChance;
    room.phase = 'AWAITING_OPPONENT_DEPOSIT';
    room.lastUpdateMs = lastUpdateMs;
  }

  async on_coinflip_completeOpponentDeposit(data) {
    let room = this.getRoom(data);
    if (!room) return;
    const { items, lastUpdateMs } = data;
    room.opponent.items = items;
    room.phase = 'STARTING';
    room.lastUpdateMs = lastUpdateMs;
  }

  async on_coinflip_setPhase(data) {
    let room = this.getRoom(data);
    if (!room) return;
    const { newPhase, lastUpdateMs } = data;
    room.phase = newPhase;
    room.lastUpdateMs = lastUpdateMs;
  }

  async on_coinflip_flipCoin(data) {
    let room = this.getRoom(data);
    if (!room) return;
    const { winnerColor, lastUpdateMs } = data;
    room.phase = 'FLIPPING';
    room.winnerColor = winnerColor;
    room.lastUpdateMs = lastUpdateMs;
  }

  async on_coinflip_updateStats(data) {
    const { newStats } = data;
    this.repositories.ext.coinflip.game.stats = newStats;
  }

  async on_coinflip_deleteRoom(data) {
    const { roomId } = data;
    this.repositories.ext.coinflip.game.rooms = this.repositories.ext.coinflip.game.rooms.filter(el => el.id !== roomId);
  }
  async on_coinflip_pushHistory(data) {
    const { color } = data;
    let history = this.repositories.ext.coinflip.game.history;
    history.unshift(color);
    if (history.length > 30) {
      this.repositories.ext.coinflip.game.history = history.slice(0, 30);
    }

  }

}