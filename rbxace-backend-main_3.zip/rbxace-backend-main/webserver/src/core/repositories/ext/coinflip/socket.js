module.exports = class {

  constructor(params) {
    params.inject(this);

  }

  async injectEventHandlers(socket) {
    socket.on("coinflip:subscribe", (data) => this.on_subscribe(socket, data));
    socket.on("coinflip:unsubscribe", (data) => this.on_unsubscribe(socket, data));
  }

  async on_subscribe(socket, data) {
    socket.join('game:coinflip');

    const packetData = {
      defs: this.repositories.ext.coinflip.game.defs,
      rooms: this.repositories.ext.coinflip.game.rooms,
      history: this.repositories.ext.coinflip.game.history,
      stats: this.repositories.ext.coinflip.game.stats,
      time: Date.now()
    };

    socket.emit('coinflip:info', packetData);
  }
  async on_unsubscribe(socket, data) {
    socket.leave('game:coinflip');
  }


}