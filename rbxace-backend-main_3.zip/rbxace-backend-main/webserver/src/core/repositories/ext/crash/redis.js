const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async on_bet(data) {


  }

  get round() {
    return this.repositories.ext.crash.game.round;
  }

  async on_startRolling(data) {
    let round = this.repositories.ext.crash.game.round;
    round.state = 'ROLLING';
    round.rollingStartedAt = data.rollingStartedAt;
  }

  async on_draw(data) {
    let round = this.repositories.ext.crash.game.round;
    round.elapsed = data.elapsed;
    round.currentMultiplier = data.currentMultiplier;
  }

  async on_pushBet(data) {
    let round = this.repositories.ext.crash.game.round;
    if (!round.bets[data.user.id])
      round.bets[data.user.id] = data;
    else
      round.bets[data.user.id].amount += data.amount;
  }

  async on_playerCashedOut(data) {
    let round = this.repositories.ext.crash.game.round;
    let bet = round.bets[data.userId];
    bet.cashedOut = data.cashedOut;
    bet.elapsed = data.elapsed;
  }

  async on_pushRound(data) {
    this.repositories.ext.crash.game.round = data.newRound;
    let history = this.repositories.ext.crash.game.history;
    history.unshift(data.lastRound);
    if (history.length > 20) {
      this.repositories.ext.crash.game.history = history.slice(0, 20);
    }
    
  }

  async on_explode(data) {
    let round = this.repositories.ext.crash.game.round;
    round.state = 'CRASHED';
    round.elapsed = data.elapsed;
    round.multiplier = data.multiplier;
  }



}