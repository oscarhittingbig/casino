module.exports = class {

  constructor(params) {
    params.inject(this);

  }

  async injectEventHandlers(socket) {
    socket.on("crash:subscribe", (data) => this.on_subscribe(socket, data));
    socket.on("crash:unsubscribe", (data) => this.on_unsubscribe(socket, data));
    socket.on("crash:bet", (data) => this.on_bet(socket, data));
    socket.on("crash:cashout", (data) => this.on_cashout(socket, data));
  }


  async on_subscribe(socket, data) {
    socket.join('game:crash');

    const packetData = {
      defs: this.repositories.ext.crash.game.defs,
      round: this.repositories.ext.crash.game.round,
      history: this.repositories.ext.crash.game.history,
      time: Date.now()
    };

    socket.emit('crash:info', packetData);
  }

  async on_unsubscribe(socket, data) {
    socket.leave('game:crash')
  }

  async on_bet(socket, data) {
    if (!data || !socket.user.isLoggedIn) return;
    if (!data.betAmount || !data.betType) return;

    let messageParams = [];
    try {
      if (global.settings.maintenance) throw new Error("PAGE_GAMES_MAINTENANCE")
      
      let { betType, betAmount } = data;
      const availableBetTypes = ['AUTO', 'MANUAL'];
      if (!availableBetTypes.includes(betType)) return;

      betAmount = parseInt(betAmount);
      const autoCashout = Math.floor((parseFloat(data.autoCashout || 0) || 0) * 100) / 100;

      //if (!this.repositories.protection.isValidAmount(betAmount)) return;
      if (isNaN(betAmount) || betAmount <= 0 || betAmount < global.settings.minBet || betAmount > global.settings.maxBet) {
        messageParams = [global.settings.minBet, global.settings.maxBet];
        throw new Error('SOCKET_GENERAL_BETRANGE')
      }

      if (autoCashout !== 0 && (autoCashout < 1.01 || autoCashout > 99999)) return;

      const betData = {
        user: this.repositories.user.getUserProfile(socket.user),
        betAmount,
        autoCashout
      };
      this.repositories.redis.publish("head", "crash:bet", betData);
    } catch (err) {
      socket.emit('user:notify', { type: 'error', message: err.message, messageParams });
    }
  }

  async on_cashout(socket) {
    if (!socket.user.isLoggedIn) return;

    let cd = this.modules.cache.getCooldown(`SOCKET_CRASH_CASHOUT|${socket.user.id}`, 1);
    if (cd > 0) return;

    this.repositories.redis.publish("head", "crash:cashout", { userId: socket.user.id });
  }


}