module.exports = class {

  constructor(params) {
    params.inject(this);

    this.defs = {}
    this.leaderboard = {};
  }

  async getUserPositionData(type, userId) {
    let entry = this.leaderboard[type];
    const entryCreatedAtMoment = moment(entry.createdAt * 1000).utc();
    const timeRangeStart = this.getTimeRangeStart(type, entryCreatedAtMoment);
    const timeRangeEnd = this.getTimeRangeEnd(type, entryCreatedAtMoment);
    const userWagerSql = (await this.modules.db.query(`SELECT IFNULL(SUM(betAmountWithRisk), 0) as wageredAmount FROM user_gamehistory WHERE userId = ? AND time > ? AND time <= ?`, [userId, timeRangeStart, timeRangeEnd]))

    let userPositionData = userWagerSql[0];
    userPositionData.place = (await this.modules.db.query(`SELECT COUNT(1) as count FROM
    (
    SELECT SUM(betAmountWithRisk) as wageredAmount FROM user_gamehistory WHERE time > ? AND time <= ? GROUP BY user_gamehistory.userId ORDER BY wageredAmount DESC
    ) AS topUsers
    WHERE topUsers.wageredAmount > ?`, [timeRangeStart, timeRangeEnd, userPositionData.wageredAmount]))[0].count; //(await this.modules.db.query(`SELECT COUNT(1) as count, SUM(amount) as wageredAmount FROM leaderboard_tickets WHERE createdAt >= ? AND createdAt < ? GROUP BY leaderboard_tickets.userId ORDER BY wageredAmount DESC`, [timeRangeStart, timeRangeEnd]))
    return userPositionData;
}
}