module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async on_setEntry(data) {
    const { type, entry } = data;
    try {
    this.repositories.ext.leaderboard.main.leaderboard[type] = entry;
    } catch(err) {
      
    }

  }

  async on_setTopUsers(data) {
    const { type, entryNewTopUsers } = data;
    try {
    this.repositories.ext.leaderboard.main.leaderboard[type].topUsers = entryNewTopUsers;
    } catch(err) {

    }
  }


}