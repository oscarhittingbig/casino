module.exports = class {

  constructor(params) {
    params.inject(this);

  }

  async injectEventHandlers(socket) {
    socket.on("leaderboard:subscribe", (data) => this.on_subscribe(socket, data));
    socket.on("leaderboard:fetch", (data) => this.on_fetch(socket, data));
    socket.on("leaderboard:unsubscribe", (data) => this.on_unsubscribe(socket, data));
  }


  async getLeaderboardEntries(userId) {
    let entries = {};
    try {
      entries = JSON.parse(JSON.stringify(this.repositories.ext.leaderboard.main.leaderboard));
      if (userId) {
        const leaderboardTypes = Object.keys(entries);
        for (let i in leaderboardTypes) {
          const leaderboardType = leaderboardTypes[i];
          if (entries[leaderboardType].topUsers.length <= 3 || entries[leaderboardType].topUsers.find(el => el.id == userId)) continue;
          const userPositionData = await this.repositories.ext.leaderboard.main.getUserPositionData(leaderboardType, userId);
          entries[leaderboardType].topUsers.push(userPositionData)
        }
      }
    } catch (err) {
    }
    return entries;
  }

  async on_subscribe(socket, data) {
    try {
      this.repositories.protection.checkMemCooldown('API_REPOSITORIES_EXT_LEADERBOARD_SUBSCRIBE', socket.id, 1);
      socket.join('events:leaderboard');
      let entries = await this.getLeaderboardEntries(!socket.user.isLoggedIn ? null : socket.user.id);
      socket.emit('leaderboard:info', { entries });
    } catch (err) {

    }
  }

  async on_fetch(socket, data) {
    try {
      this.repositories.protection.checkMemCooldown('API_REPOSITORIES_EXT_LEADERBOARD_FETCH', socket.id, 1);
      let entries = await this.getLeaderboardEntries(!socket.user.isLoggedIn ? null : socket.user.id);
      socket.emit('leaderboard:entries', { entries });
    } catch (err) {

    }
  }

  async on_unsubscribe(socket, data) {
    socket.leave('events:leaderboard')
  }


}