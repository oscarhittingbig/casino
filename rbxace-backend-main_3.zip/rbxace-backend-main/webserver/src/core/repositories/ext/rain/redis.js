module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async on_setPot(data) {
    this.repositories.ext.rain.main.pot = data.newPot;
  }

  async on_setState(data) {
    this.repositories.ext.rain.main.pot.state = data.newState;
    this.repositories.ext.rain.main.pot.lastUpdateMs = data.lastUpdateMs;
  }

  async on_updatePotVariables(data) {
    this.repositories.ext.rain.main.pot.prize = data.newPrize;
    this.repositories.ext.rain.main.pot.joinedPlayersCount = data.newJoinedPlayersCount;
  }


}