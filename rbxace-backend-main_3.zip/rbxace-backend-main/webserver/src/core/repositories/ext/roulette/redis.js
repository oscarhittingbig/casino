const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async on_bet(data) {


  }

  async on_startRoll(data) {
    let round = this.repositories.ext.roulette.game.round;
    round.rolledAt = Date.now();
    round.state = data.state;
    round.roll = data.roll;
    round.wobble = data.wobble;
  }

  async on_pushRound(data) {
    this.repositories.ext.roulette.game.round = data.newRound;
    this.repositories.ext.roulette.game.counts = data.newCounts;
    let history = this.repositories.ext.roulette.game.history;
    history.unshift(data.lastRound);
    if (history.length > 10) {
      this.repositories.ext.roulette.game.history = history.slice(0, 10);
    }
    
  }

  async on_pushBet(data) {
    let round = this.repositories.ext.roulette.game.round;
    if (!round.bets[data.color][data.bet.user.id])
      round.bets[data.color][data.bet.user.id] = data.bet;
    else
      round.bets[data.color][data.bet.user.id].amount += data.bet.amount;
  }

}