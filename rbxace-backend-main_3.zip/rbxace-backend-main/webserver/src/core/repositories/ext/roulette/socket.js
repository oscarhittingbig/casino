module.exports = class {

  constructor(params) {
    params.inject(this);

  }

  async injectEventHandlers(socket) {
    socket.on("roulette:subscribe", (data) => this.on_subscribe(socket, data));
    socket.on("roulette:unsubscribe", (data) => this.on_unsubscribe(socket, data));
    socket.on("roulette:bet", (data) => this.on_bet(socket, data));
  }


  async on_subscribe(socket, data) {
    socket.join('game:roulette');

    const packetData = {
      defs: this.repositories.ext.roulette.game.defs,
      round: this.repositories.ext.roulette.game.round,
      history: this.repositories.ext.roulette.game.history,
      counts: this.repositories.ext.roulette.game.counts,
      time: Date.now()
    };

    socket.emit('roulette:info', packetData);
  }

  async on_unsubscribe(socket, data) {
    socket.leave('game:roulette')
  }

  async on_bet(socket, data) {
    if (!data || !data.betAmount || !data.color || !socket.user.isLoggedIn) return;
    const colors = ['RED', 'GOLD', 'BLACK'];
    if (typeof data.color !== 'string' || !colors.includes(data.color)) return;

    let messageParams = [];
    try {
      if (global.settings.maintenance) throw new Error("PAGE_GAMES_MAINTENANCE")

      const betAmount = parseInt(data.betAmount);
      if (isNaN(betAmount) || betAmount <= 0 || betAmount < global.settings.minBet || betAmount > global.settings.maxBet) {
        messageParams = [global.settings.minBet, global.settings.maxBet];
        throw new Error('SOCKET_GENERAL_BETRANGE')
      }

      const betData = {
        user: this.repositories.user.getUserProfile(socket.user),
        betAmount,
        color: data.color
      };
      this.repositories.redis.publish("head", "roulette:bet", betData);
    } catch (err) {
      socket.emit('user:notify', { type: 'error', message: err.message, messageParams });
    }
  }


}