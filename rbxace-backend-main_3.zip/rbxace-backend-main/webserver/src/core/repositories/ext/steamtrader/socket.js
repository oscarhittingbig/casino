module.exports = class {

  constructor(params) {
    params.inject(this);


  }


  async injectEventHandlers(socket) {
    socket.on("steamtrader:shop:subscribe", (data) => this.on_shop_subscribe(socket, data));
    socket.on("steamtrader:shop:unsubscribe", (data) => this.on_shop_unsubscribe(socket, data));
  }


  async on_shop_subscribe(socket, data) {

    const items = await this.modules.db.query("SELECT steam_bot_items.* FROM steam_bot_items INNER JOIN steam_trade_bots ON steam_trade_bots.id = steam_bot_items.botId WHERE app = 'RUST' AND steam_trade_bots.type = 'VAULT' ");

    socket.join('steamtrader:shop');
    socket.emit("steamtrader:shop:info", {
        items
    });

  }

  async on_shop_unsubscribe(socket, data) {
    socket.leave('steamtrader:shop');
  }


}