module.exports = class {

  constructor(params) {
    params.inject(this);
    this.defs = {

    }

    this.history = [];

  }

  async getUserInventory(userId) {
    return await this.modules.db.query("SELECT * FROM game_upgrader_user_inventory WHERE userId = ? AND state = 'ACTIVE'", [userId]);
  }

  async getInventoryItem(itemId) {
    return await this.modules.db.select("game_upgrader_user_inventory", "id", itemId);
  }
  async getShopItem(itemId) {
    return await this.modules.db.select("steam_market_items", "id", itemId);
  }

  async getSeedData(userId) {
    const seedData = (await this.modules.db.query("SELECT upgraderClientSeed, upgraderServerSeed FROM user_data_games WHERE userId = ?", [userId]))[0];
    return {
      clientSeed: seedData.upgraderClientSeed,
      serverSeed: seedData.upgraderServerSeed
    }
  }

  
  async generateSeedData(userId) {
    const clientSeed = this.repositories.random.generateRandomString(64);
    const serverSeed = this.repositories.random.generateRandomString(64);
    const updateSuccess = await this.modules.db.exec("UPDATE user_data_games SET upgraderClientSeed = ?, upgraderServerSeed = ? WHERE userId = ?", [clientSeed, serverSeed, userId]);
    if (!updateSuccess) throw new Error("Seeds couldn't be updated!");

    return { clientSeed, serverSeed };
}


}