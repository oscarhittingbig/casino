const { v1: uuidv1 } = require('uuid');

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async on_pushHistory(data) {
    this.repositories.ext.upgrader.game.history.unshift(data.history);
    if (this.repositories.ext.upgrader.game.history.length > 15) {
      this.repositories.ext.upgrader.game.history = this.repositories.ext.upgrader.game.history.slice(0, 15);
    }
  }

}