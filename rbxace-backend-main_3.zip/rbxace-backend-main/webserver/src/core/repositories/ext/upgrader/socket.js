module.exports = class {

  constructor(params) {
    params.inject(this);

  }

  async injectEventHandlers(socket) {
    socket.on("upgrader:subscribe", (data) => this.on_subscribe(socket, data));
    socket.on("upgrader:unsubscribe", (data) => this.on_unsubscribe(socket, data));
    socket.on("upgrader:play", (data) => this.on_play(socket, data));
  }


  async on_subscribe(socket, data) {

    try {
      this.repositories.protection.checkMemCooldown('SOCKET_UPGRADER_SUBSCRIBE', socket.id, 0.5);
      const packetData = {
        defs: this.repositories.ext.upgrader.game.defs,
        history: this.repositories.ext.upgrader.game.history,
        inventoryItems: [],
        //shopItems: [],
      };


      //GENERATE SEED THERE!!
      //GENERATE SEED THERE!!
      //GENERATE SEED THERE!!
      //GENERATE SEED THERE!!
      //GENERATE SEED THERE!!
      //GENERATE SEED THERE!!
      
      if (socket.user.isLoggedIn) {
        let seedData = await this.repositories.ext.upgrader.game.getSeedData(socket.user.id);

        if (!seedData.clientSeed || !seedData.serverSeed)
        seedData = await this.repositories.ext.upgrader.game.generateSeedData(socket.user.id);

        packetData.inventoryItems = await this.repositories.ext.upgrader.game.getUserInventory(socket.user.id);
      }
      //packetData.shopItems = await this.modules.db.query("SELECT * FROM steam_shop_items WHERE app = 'RUST'");

      socket.join('game:upgrader');

      socket.emit('upgrader:info', packetData);
    } catch (err) {
      console.log(err);
    }
  }

  async on_unsubscribe(socket, data) {
    socket.leave('game:upgrader')
  }

  async on_play(socket, data) {

    if (!data || !socket.user.isLoggedIn
      || !data.inputBetAmount
      //|| !data.inputItemIds || !Array.isArray(data.inputItemIds) || data.inputItemIds.length == 0
      || !data.outputItemIds || !Array.isArray(data.outputItemIds) || data.outputItemIds.length == 0 || data.outputItemIds.length > 5
      || !data.rollType || typeof data.rollType !== 'string')
      return;


    //inputItems -> item ids in user inventory
    //outputItems -> item ids in database)
    
    let messageParams = [];
    try {
      this.repositories.protection.checkMemCooldown('SOCKET_UPGRADER_PLAY', socket.user.id, 3);

      if (global.settings.maintenance) throw new Error("PAGE_GAMES_MAINTENANCE")
      
      const availableRollTypes = ['UNDER', 'OVER'];
      const rollType = data.rollType;
      if (!availableRollTypes.includes(rollType)) return;

      const fastAnimation = data.fastAnimation == true;
      /* DEPRECATED */
      /*
      let inputItems = [];
      const inputItemIds = [...new Set(data.inputItemIds)];
      for (let i in inputItemIds) {
        const inventoryItemId = inputItemIds[i];
        const inventoryItem = await this.repositories.ext.upgrader.getInventoryItem(inventoryItemId);
        if (!inventoryItem || inventoryItem.state !== 'ACTIVE') throw new Error("SOCKET_UPGRADER_PLAY_INPUTITEMNOTAVAILABLE");
        inputItems.push(inventoryItem);
      }
      */

      const inputBetAmount = parseInt(data.inputBetAmount); //inputItems.reduce((sum, obj) => { sum += obj.price; return sum; }, 0);
      if (isNaN(inputBetAmount) || inputBetAmount < 25 || inputBetAmount > global.settings.maxBet) {
        messageParams = [25, global.settings.maxBet];
        throw new Error('SOCKET_GENERAL_BETRANGE')
      }

      const shopItems = await this.modules.db.query("SELECT steam_bot_items.* FROM steam_bot_items INNER JOIN steam_trade_bots ON steam_trade_bots.id = steam_bot_items.botId WHERE app = 'RUST' AND steam_trade_bots.type = 'VAULT' ");

      let outputItems = [];
      const outputItemIds = data.outputItemIds; // may be same asset ids, bcz not stacked [...new Set(data.outputItemIds)];
      for (let i in outputItemIds) {
        const shopItemId = outputItemIds[i];
        const shopItem = shopItems.find((item) => item.id == shopItemId);
        if (!shopItem || !shopItem.available || shopItem.busy) throw new Error("SOCKET_UPGRADER_PLAY_OUTPUTITEMNOTAVAILABLE");
        outputItems.push(shopItem);
      }

      const outputBetAmount = outputItems.reduce((sum, obj) => { sum += obj.price; return sum; }, 0) * 10;
      if (isNaN(inputBetAmount) || inputBetAmount <= 0 || isNaN(outputBetAmount) || outputBetAmount <= 0) throw new Error("SOCKET_UPGRADER_PLAY_BETAMOUNTSAREINVALID");
   
      if (outputBetAmount < inputBetAmount) throw new Error("SOCKET_UPGRADER_PLAY_OUTPUTCANTBELOWERTHANINPUT")
      const betData = {
        user: this.repositories.user.getUserProfile(socket.user),
        rollType,
        fastAnimation,
        inputBetAmount,
        outputItems,
        outputBetAmount
      };

      
      this.repositories.redis.publish("head", "upgrader:play", betData);

    } catch (err) {
      socket.emit('user:notify', { type: 'error', message: err.message, messageParams });
    }

  }




}