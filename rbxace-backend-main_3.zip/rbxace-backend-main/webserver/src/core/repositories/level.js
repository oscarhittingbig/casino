module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  getLevelByExp(exp) {
    let level = Math.floor(Math.pow((exp / 1000), (1 / global.settings.levelScale)));
    if (level > this.levelMax - 1) {
      level = this.levelMax - 1;
    }
    return level + 1;
  }
  getExpByLevel(level) {
    let exp = Math.floor(Math.pow(level - 1, global.settings.levelScale)) * 1000;
    return exp;
  }

}