module.exports = class {


    constructor(params) {
        params.inject(this);
    }

   
    isValidAmount(amount) {
        if (isNaN(amount) || amount <= 0 || amount > 10000000) return false;
        return true;
    }

    clearIllegalChars(str) {
        return str.replace(/[|&;$%@"<>()+,]/g, "");
    }
    clearHTML(str) {
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }


    /* Cooldown */
    checkMemCooldown(key, value, timeInSeconds) {
        let cd = this.modules.cache.getCooldown(
            `${key}|${value}`,
            timeInSeconds
        );

        if (cd > 0)  throw new Error(`API_GENERAL_COOLDOWN`)
    }

    async checkRedisCooldown(key, value, errMsg) {
        let redisKey = `${key}|${value}`;
        let exists = (await this.modules.redis.get(redisKey)) !== null; //  //this.modules.cache.memGet(ipKey);
        if (exists) { //undefined
            throw new Error(errMsg);
        }
    }

    isAlphaNumeric(str) {
        
    const alphanumericCheck = /^([0-9]|[A-Z])+([0-9A-Z]+)$/i;
    if (!alphanumericCheck.test(str)) return false;
    return true;

    }
}

