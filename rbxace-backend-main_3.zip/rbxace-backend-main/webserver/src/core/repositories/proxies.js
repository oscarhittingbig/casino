const axios = require('axios');

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.proxyList = [];
        this.proxyListUnique = [];
        
    }
    async init() {
        await this.storeProxyList();
    }

    async retrieveProxyList() {
        const response = await axios.get("https://proxy.webshare.io/api/proxy/list", { 'headers': { 'Authorization': "Token " + process.env.WEBSHARE_API_KEY } }).catch(err => { return null; });
        if (!response) return [];
        return response.data.results;
    }

    async storeProxyList() {
        const proxies = await this.retrieveProxyList();
    
        let temp = [];
        proxies.map((proxy) => {
            if (proxy.valid) {
                temp.push(`http://${proxy.username}:${proxy.password}@${proxy.proxy_address}:${proxy.ports.http}`);
            }
        })
    
        this.proxyList = temp;
        this.proxyListUnique = JSON.parse(JSON.stringify(this.proxyList));
    }

    getProxy() {
        if (this.proxyListUnique.length > 0) {
            var proxy = this.proxyListUnique[0];
            this.proxyListUnique.shift();
            return proxy;
        } else {
            return false;
        }
    }

    getRandomProxy() {
        const randomOffset = Math.floor(Math.random() * this.proxyList.length)
        return this.proxyList[randomOffset];
    }
}