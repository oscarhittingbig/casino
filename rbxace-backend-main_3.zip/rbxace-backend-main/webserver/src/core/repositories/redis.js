const redis = require("redis");
const client = redis.createClient();
const publisher = redis.createClient();
const subscriber = redis.createClient();

module.exports = class {

  constructor(params) {
    params.inject(this);

    this.loggedIn = false;

    subscriber.on("message", (channel, messageJson) => {

      let message = JSON.parse(messageJson);
      if (message.sender !== process.pid) {
        this.handle_workerPackets(channel, message.header, message.content);
      }
    });

    subscriber.on("subscribe", (channel, count) => {
      if (channel == this.workerChannel) {
        this.requestInitialization();
      }
    });


    subscriber.subscribe("workers");
    subscriber.subscribe(this.workerChannel);
  }

  async get(key) {
    return await new Promise(function (resolve, reject) {
      client.get(key, function (err, reply) {
        if (err) {
          reject(err);
        } else {
          resolve(reply);
        }
      });

    });
  }

  set(key, expire, val) {
    client.setex(key, expire, val);
  }


  get client() {
    return client;
  }

  get workerChannel() {
    return `worker-${global.WORKER}`;
  }

  requestInitialization() {
    const loginData = {
      pid: process.pid
    };
    this.publish('head', 'initialization', loginData);
    console.log(`Cluster - #${process.env.NODE_APP_INSTANCE} - Worker Id #${global.WORKER} ~ [PID ${process.pid}] - Request initialiation is asked to core server!`);
  }

  handle_workerPackets(channel, header, content) {
    switch (header) {

      case 'requestInitialization':
        this.publish('head', 'initialization', true);
        break;

      case "initialization":
        this.on_initialization(content);
        this.repositories.socket.publish('user:forceDisconnect');
        //console.log(this.workerChannel, 'got init', content)

        break;


        /* Chat Messages */

        case "chat:pushMessage":
          this.repositories.ext.chat.main.pushMessage(content.channel, content.message);
          break;

          case "chat:mute":
            this.repositories.ext.chat.main.mute(content.userId, content.muteEndsAt);
           break;

           case "chat:unmute":
            this.repositories.ext.chat.main.unmute(content.userId);
           break;

           case "chat:ban":
            this.repositories.ext.chat.main.ban(content.userId);
           break;

           case "chat:unban":
            this.repositories.ext.chat.main.unban(content.userId);
           break;

           case "chat:clear":
            this.repositories.ext.chat.main.pushClear(content.channel, content.userId);
           break;



      case "roulette:startRoll":
        this.repositories.ext.roulette.redis.on_startRoll(content);
        break;

      case "roulette:pushRound":
        this.repositories.ext.roulette.redis.on_pushRound(content);
        break;
      case "roulette:pushBet":
        this.repositories.ext.roulette.redis.on_pushBet(content);
        break;





      case "crash:pushBet":
        this.repositories.ext.crash.redis.on_pushBet(content);
        break;

      case "crash:startRolling":
        this.repositories.ext.crash.redis.on_startRolling(content);
        break;

      case "crash:draw":
        this.repositories.ext.crash.redis.on_draw(content);
        break;

      case "crash:playerCashedOut":
        this.repositories.ext.crash.redis.on_playerCashedOut(content);
        break;

      case "crash:explode":
        this.repositories.ext.crash.redis.on_explode(content);
        break;

      case "crash:pushRound":
        this.repositories.ext.crash.redis.on_pushRound(content);
        break;



      case "blackjack:player:setUser":
        this.repositories.ext.blackjack.redis.on_player_setUser(content);
        break;

      case "blackjack:player:setBetAmount":
        this.repositories.ext.blackjack.redis.on_player_setBetAmount(content);
        break;

      case "blackjack:player:setBets":
        this.repositories.ext.blackjack.redis.on_player_setBets(content);
        break;


      case "blackjack:round:setPhase":
        this.repositories.ext.blackjack.redis.on_round_setPhase(content);
        break;
      case "blackjack:round:setData":
        this.repositories.ext.blackjack.redis.on_round_setData(content);
        break;
      case "blackjack:round:setPlayingPlayerOffset":
        this.repositories.ext.blackjack.redis.on_round_setPlayingPlayerOffset(content);
        break;
      case "blackjack:round:resetPhaseTimer":
        this.repositories.ext.blackjack.redis.on_round_resetPhaseTimer(content);
        break;
      case "blackjack:round:resetUserDecisions":
        this.repositories.ext.blackjack.redis.on_round_resetUserDecisions(content);
        break;
      case "blackjack:round:removeInsurances":
        this.repositories.ext.blackjack.redis.on_round_removeInsurances(content);
        break;


      case "blackjack:player:pushCard":
        this.repositories.ext.blackjack.redis.on_player_pushCard(content);
        break;

      case "blackjack:player:setDecision":
        this.repositories.ext.blackjack.redis.on_player_setDecision(content);
        break;

      case "blackjack:player:setDecisionHand":
        this.repositories.ext.blackjack.redis.on_player_setDecisionHand(content);
        break;

      case "blackjack:player:addInsurance":
        this.repositories.ext.blackjack.redis.on_player_addInsurance(content);
        break;

      case "blackjack:player:splitHand":
        this.repositories.ext.blackjack.redis.on_player_splitHand(content);
        break;

      case "blackjack:player:doubleDown":
        this.repositories.ext.blackjack.redis.on_player_doubleDown(content);
        break;



      case "blackjack:round:setSideBetPayouts":
        this.repositories.ext.blackjack.redis.on_round_setSideBetPayouts(content);
        break;



      case "blackjack:dealer:pushCard":
        this.repositories.ext.blackjack.redis.on_dealer_pushCard(content);
        break;

      case "blackjack:dealer:showHiddenCard":
        this.repositories.ext.blackjack.redis.on_dealer_showHiddenCard(content);
        break;



      case "coinflip:pushRoom":
        this.repositories.ext.coinflip.redis.on_coinflip_pushRoom(content);
        break;

      case "coinflip:clearOpponent":
        this.repositories.ext.coinflip.redis.on_coinflip_clearOpponent(content);
        break;

      case "coinflip:setOpponent":
        this.repositories.ext.coinflip.redis.on_coinflip_setOpponent(content);
        break;

        case "coinflip:completeOpponentDeposit":
          this.repositories.ext.coinflip.redis.on_coinflip_completeOpponentDeposit(content);
          break;

          case "coinflip:flipCoin":
            this.repositories.ext.coinflip.redis.on_coinflip_flipCoin(content);
          break;

          case "coinflip:setPhase":
            this.repositories.ext.coinflip.redis.on_coinflip_setPhase(content);
            break;

            case "coinflip:deleteRoom":
              this.repositories.ext.coinflip.redis.on_coinflip_deleteRoom(content);
            break;

            case "coinflip:updateStats":
              this.repositories.ext.coinflip.redis.on_coinflip_updateStats(content);
            break;

            case "coinflip:pushHistory":
              this.repositories.ext.coinflip.redis.on_coinflip_pushHistory(content);
            break;

            case "upgrader:pushHistory":
              this.repositories.ext.upgrader.redis.on_pushHistory(content);
            break;



            case "events:rain:setPot":
              this.repositories.ext.rain.redis.on_setPot(content);
            break;

            case "events:rain:setState":
              this.repositories.ext.rain.redis.on_setState(content);
            break;

            case "events:rain:updatePotVariables":
              this.repositories.ext.rain.redis.on_updatePotVariables(content);
            break;



            case "leaderboard:setEntry":
              this.repositories.ext.leaderboard.redis.on_setEntry(content);
            break;


            case "leaderboard:setTopUsers":
              this.repositories.ext.leaderboard.redis.on_setTopUsers(content);
            break;




            case "misc:setOnline":
              this.repositories.ext.chat.main.online = content;
            break;





      case "user:setSocketProperty":
        this.repositories.user.redis.on_setSocketProperty(content);
        break;

    }
  }

  on_initialization(data) {
    this.repositories.ext.chat.main.defs = data.chat.defs;
    this.repositories.ext.chat.main.messages = data.chat.messages;
    this.repositories.ext.chat.main.online = data.chat.online;

    this.repositories.ext.roulette.game.defs = data.roulette.defs;
    this.repositories.ext.roulette.game.round = data.roulette.round;
    this.repositories.ext.roulette.game.history = data.roulette.history;
    this.repositories.ext.roulette.game.counts = data.roulette.counts;

    this.repositories.ext.crash.game.defs = data.crash.defs;
    this.repositories.ext.crash.game.round = data.crash.round;
    this.repositories.ext.crash.game.history = data.crash.history;

    this.repositories.ext.blackjack.game.defs = data.blackjack.defs;
    this.repositories.ext.blackjack.game.tables = data.blackjack.tables;

    this.repositories.ext.coinflip.game.defs = data.coinflip.defs;
    this.repositories.ext.coinflip.game.rooms = data.coinflip.rooms;
    this.repositories.ext.coinflip.game.history = data.coinflip.history;
    this.repositories.ext.coinflip.game.stats = data.coinflip.stats;

    this.repositories.ext.upgrader.game.defs = data.upgrader.defs;
    this.repositories.ext.upgrader.game.history = data.upgrader.history;

    this.repositories.ext.rain.main.defs = data.rain.defs;
    this.repositories.ext.rain.main.pot = data.rain.pot;

    this.repositories.ext.leaderboard.main.leaderboard = data.leaderboard;
  }


  publish(channel, header, obj) {
    let message = { header: header, content: obj, sender: process.pid, workerChannel: this.workerChannel };
    let messageJson = JSON.stringify(message);
    publisher.publish(channel, messageJson);
  }

  publishToOtherWorkers(header, data) {
    this.publish('head', 'publishToOtherWorkers', { header, data })
  }
}