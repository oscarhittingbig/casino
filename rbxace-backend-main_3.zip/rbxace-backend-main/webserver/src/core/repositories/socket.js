const redisAdapter = require("socket.io-redis");

module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  init(server) {
    this.modules.io = require("socket.io")(server, { transports: ["websocket"] });
    this.modules.io.adapter(redisAdapter({ host: "localhost", port: 6379 }));
  }

  listen() {
    this.modules.io.on("connection", socket => {
      socket.on("authentication", (data) => this.on_authentication(socket, data));

      this.repositories.ext.chat.socket.injectEventHandlers(socket);
      this.repositories.ext.roulette.socket.injectEventHandlers(socket);
      this.repositories.ext.crash.socket.injectEventHandlers(socket);
      this.repositories.ext.blackjack.socket.injectEventHandlers(socket);
      this.repositories.ext.coinflip.socket.injectEventHandlers(socket);
      this.repositories.ext.upgrader.socket.injectEventHandlers(socket);
      this.repositories.ext.steamtrader.socket.injectEventHandlers(socket);
      this.repositories.ext.leaderboard.socket.injectEventHandlers(socket);
    });
  }

  /*
  getUsersInRoom(userId) {
    let users = [];
    let room = this.modules.io.sockets.adapter.rooms.get(`user-${userId}`);
    if (room == undefined) {
      return users;
    }
    room.forEach(clientId => {
      const clientSocket = io.sockets.sockets.get(clientId);
      users.push(clientSocket.user);
    })
    return users;
  }
  */

  getUsersInRoom(userId) {
    let users = [];
    let room = this.modules.io.sockets.adapter.rooms[`user-${userId}`];
    if (room == undefined) return users;

    let clients = room.sockets;
    //let numClients = clients ? Object.keys(clients).length : 0;

    for (let clientId in clients) {
      let clientSocket = this.modules.io.sockets.connected[clientId];
      if (clientSocket && clientSocket.user) users.push(clientSocket.user);
    }
    return users;
  }


  async on_authentication(socket, authToken) {
    if (socket.triedLogin) return;
    try {
      socket.triedLogin = true;
      socket.user = await this.repositories.user.getByAuthToken(authToken);
      socket.join("global");

      const userVariables = {
        events: {
          rain: {}
        }
      };

      if (socket.user.isLoggedIn) {
        socket.join("user-" + socket.user.id);
        userVariables.events.rain.meJoined = (await this.modules.db.query("SELECT COUNT(1) as count FROM events_rain_pot_players WHERE potId = ? AND userId = ?", [this.repositories.ext.rain.main.pot.id, socket.user.id]))[0].count > 0;
      }

      socket.emit('authenticationResponse', {
        userData: socket.user,
        defs: {
          LEVEL_SCALE: global.settings.levelScale
        },
        misc: {
          online: this.repositories.ext.chat.main.online
        },
        events: {
          rain: {
            defs: this.repositories.ext.rain.main.defs,
            pot: this.repositories.ext.rain.main.pot,
            meJoined: userVariables.events.rain.meJoined
          }
        }
      });
    } catch (err) {

    }
  }


  publish(type, data) {
    if (this.modules.io) this.modules.io.to("global").emit(type, data);
  }

  publishChannel(channelName, type, data) {
    if (this.modules.io) this.modules.io.to(channelName).emit(type, data);
  }

  publishToUser(userId, type, data) {
    if (this.modules.io) this.modules.io.to("user-" + userId).emit(type, data);
  }



}