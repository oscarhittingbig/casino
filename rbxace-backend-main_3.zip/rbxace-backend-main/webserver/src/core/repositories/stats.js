const moment = require('moment');
const cutAfter = 0;

module.exports = class {

  constructor(params) {
    params.inject(this);

    /*
    this.generateMonthlyTimeRanges('1629018615', moment().utc().unix())
    this.generateTodaysTimeRanges();
    */
  }

  generateMonthlyTimeRanges(start, end) {
    const startMoment = moment(start * 1000).startOf('month');
    const endMoment = moment(end * 1000).endOf('month');

    /*
    const startYear = startMoment.format('Y')
    const endYear = endMoment.format('Y')

    console.log(startYear, endYear)
    const startMonth = startMoment.format('M')
    const endMonth = endMoment.format('M')
    */

    const diffMonths = Math.floor(moment.duration(endMoment.diff(startMoment)).asMonths());
    let timeRanges = [];
    for (let i = 0;i <= diffMonths;i++) {
      const start = moment(startMoment.utc().unix() * 1000).add(i, 'month').startOf('month').utc().unix();
      const end = moment(start * 1000).endOf('month').utc().unix();
      timeRanges.push({start, end});
    }
    return timeRanges;
  }

  generateThisMonthsTimeRanges() {
    const now = moment().utc().unix();
    const monthStartMoment = moment(now * 1000).startOf('month');
    const monthEndMoment = moment(now * 1000).endOf('month');

    const daysInMonth = monthEndMoment.daysInMonth();
    let timeRanges = [];
    for (let i = 0;i < daysInMonth;i++) {
      const start = moment(monthStartMoment.utc().unix() * 1000).add(i, 'days').startOf('day').utc().unix();
      const end = moment(start * 1000).endOf('day').utc().unix();
      timeRanges.push({start, end});
    }
    return timeRanges;    
  }

  
  generateTodaysTimeRanges() {
    const now = moment().utc().unix();
    const dayStartMoment = moment(now * 1000).startOf('day');

    let timeRanges = [];
    for (let i = 0;i < 24;i++) {
      const start = moment(dayStartMoment.utc().unix() * 1000).add(i, 'hours').startOf('hours').utc().unix();
      const end = moment(start * 1000).endOf('hours').utc().unix();
      timeRanges.push({start, end});
    }
    return timeRanges;    
  }



}