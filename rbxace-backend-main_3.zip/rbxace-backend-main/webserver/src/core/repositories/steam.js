const axios = require("axios");
const HttpsProxyAgent = require("https-proxy-agent");

module.exports = class {

    constructor(params) {
        params.inject(this);

        this.tag = "#Gains.GG";


        /*
        setTimeout(async () => {
            await this.ownsRust('76561198881065094')
        });
        */

        /*
        setTimeout(async () => {
            const requestOptions = {
                timeout: 10 * 1000
            };
            const proxy = await this.repositories.proxies.getRandomProxy();
            requestOptions.httpsAgent = new HttpsProxyAgent({host: "154.12.100.229", port: "5838", auth: "qctrdzyh:zzyi9wuklp5o"})

            
            if (proxy){
                console.log(proxy)
            const proxyOptions = proxy; //`socks5://${proxy.username}:${proxy.password}@${proxy.proxy_address}:${proxy.ports.socks5}`;
            console.log(proxyOptions)
            requestOptions.httpsAgent = new HttpsProxyAgent(proxyOptions);
            }
            
            const response = await axios.get(`http://whatismyip.com/`, requestOptions).catch(err => { return null; });
            console.log(response.data)
        }, 199)
        */

    }

    async ownsRust(steamId) {
        const requestOptions = { timeout: 10 * 1000 };
        const proxy = await this.repositories.proxies.getRandomProxy();
        if (proxy) {
            const proxyOptions = proxy; //`socks5://${proxy.username}:${proxy.password}@${proxy.proxy_address}:${proxy.ports.socks5}`;
            requestOptions.httpsAgent = new HttpsProxyAgent(proxyOptions);
        }
        const response = await axios.get(`http://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/?key=${process.env.STEAM_API_KEY}&steamid=${steamId}&format=json`, requestOptions).catch(err => { return null });
        if (!response || !response.data || !response.data.response) throw new Error("API_REPO_STEAM_ERROR")
        if (!response.data.response.games) throw new Error("API_REPO_STEAM_PRIVACYERROR")

        const games = response.data.response.games;
        const rust = games.find(el => el.appid == 252490);
        if (!rust) throw new Error("API_REPO_STEAM_NORUST");
        const hoursPlayed = parseInt(rust.playtime_forever) / 60;
        if (hoursPlayed < 5) throw new Error("API_REPO_STEAM_RUSTMINHOURS");
        return true;
    }


    async getSteamProfile(steamId) {
        const requestOptions = { timeout: 10 * 1000 };
        const proxy = await this.repositories.proxies.getRandomProxy();
        if (proxy) {
            const proxyOptions = proxy; //`socks5://${proxy.username}:${proxy.password}@${proxy.proxy_address}:${proxy.ports.socks5}`;
            requestOptions.httpsAgent = new HttpsProxyAgent(proxyOptions);
        }
        const response = await axios.get(`http://steamcommunity.com/profiles/${steamId}/`, requestOptions).catch(err => { return null; });

        if (!response || !response.data) throw new Error("API_REPO_STEAM_ERROR");
        return response.data;
    }


    async hasUserDomain(steamId) {
        try {
            const profileData = await this.getSteamProfile(steamId);
            const personaname = global.getBetween(profileData, ` :: `, `">`);
            return personaname.toUpperCase().includes(this.tag.toUpperCase());
        } catch (err) {
            return false;
        }
    }


    async getLevel(steamId) {
        const profileData = await this.getSteamProfile(steamId);

        const isPrivateProfile = profileData.includes(`div class="profile_private_info">`);
        if (isPrivateProfile) throw new Error("API_REPO_STEAM_PRIVACYERROR");

        const levelData = global.getBetween(profileData, `friendPlayerLevelNum">`, `</span>`);
        const level = parseInt(levelData);
        return level;
    }




}