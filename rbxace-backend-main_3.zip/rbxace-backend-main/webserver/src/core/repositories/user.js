module.exports = class {

  constructor(params) {
    params.inject(this);
  }

  async getByAuthToken(authToken) {
    const nullUser = {
      id: -1,
      isLoggedIn: false,
      role: 'USER',
    };

    if (authToken && typeof authToken == 'string' && authToken.length == 128) authToken = authToken.replace(/\W/g, '').substring(0, 128);
    else return nullUser;

    let userSql = (await this.modules.db.query("SELECT users.*, user_data_common.displayName, user_data_common.avatar, user_data_common.balance, user_data_common.exp, user_data_common.muteEndsAt, user_data_common.isBanned, user_data_common.hasTradeLock, user_data_common.whitelistRequest, user_data_common.isWhitelisted, user_data_common.affiliateId, user_data_settings.tradeUrl, user_data_settings.volume, user_data_settings.isAnon, user_data_settings.isPrivate FROM user_sessions INNER JOIN users ON users.id = user_sessions.userId INNER JOIN user_data_common ON users.id = user_data_common.userId INNER JOIN user_data_settings ON users.id = user_data_settings.userId WHERE user_sessions.authToken = ?", [authToken]));
    if (userSql.length > 0) {
      const userData = userSql[0];
      const user = {
        id: userData.id,
        accountId: userData.accountId,
        displayName: userData.displayName,
        avatar: userData.avatar,
        balance: userData.balance,
        role: userData.role,
        roleLevel: this.roleToLevel(userData.role),

        isBanned: userData.isBanned,
        muteEndsAt: userData.muteEndsAt,
        
        hasTradeLock: userData.hasTradeLock,
        whitelistRequest: userData.whitelistRequest,
        isWhitelisted: userData.isWhitelisted,
        
        affiliateId: userData.affiliateId,
        exp: userData.exp,
        level: this.repositories.level.getLevelByExp(userData.level),
        settings: {
          tradeUrl: userData.tradeUrl,
          volume: userData.volume,
          isAnon: userData.isAnon,
          isPrivate: userData.isPrivate
        }
      }
      user.isLoggedIn = true;
      return user;
    } else return nullUser;

  }

  roleToLevel(role) {
    switch (role) {
        case 'USER': return 0;
        case 'MODERATOR': return 10;
        case 'ADMIN': return 100;
        default: return 0;
    }
}

  getUserProfile(user) {
    return {
      id: user.id,
      accountId: (!user.settings.isAnon && !user.settings.isPrivate) ? user.accountId : 0,
      displayName: !user.settings.isAnon ? user.displayName : 'Anonymous',
      avatar: !user.settings.isAnon ? user.avatar : 'https://steamuserimages-a.akamaihd.net/ugc/885384897182110030/F095539864AC9E94AE5236E04C8CA7C2725BCEFF/',
      role: user.role,
      roleLevel: user.roleLevel,
      exp: user.exp
    }
  }

  async notify({userId, type = 'info', message, messageParams }) {
    this.repositories.socket.publishToUser(userId, 'user:notify', { message, type, messageParams });
  }

  async getCooldown(userId, cooldownName) {
    const cooldown = (await this.modules.db.query(`SELECT ${cooldownName} FROM user_data_cooldowns WHERE userId = ?`, [userId]))[0][cooldownName];
    return cooldown;
  }

  async getTradeUrl(userId) {
    const tradeUrl = (await this.modules.db.query("SELECT tradeUrl FROM user_data_settings WHERE userId = ?", [userId]))[0].tradeUrl;
    if (!tradeUrl || !tradeUrl.startsWith("https://steamcommunity.com/tradeoffer/new/")) throw new Error("API_TRADING_STEAM_REQUESTDEPOSIT_SETTRADEURL");
    return tradeUrl;
}

  async updateBalance({way, userId, amount, transactionType, alterType, alterName}) {
    const sql = await this.modules.db.call(`${way == 'IN' ? "user_increaseBalance" : "user_decreaseBalance"}(?, ?, ?, ?, ?)`, [userId, amount, transactionType, alterType || '', alterName || '']);
    if (!sql.success) {
        if (way == 'IN') return false;
        else throw new Error("Insufficient balance!");
    }
    this.updateBalanceVisually(userId, sql.params.newBalance, sql.params.newExp);
    return true;
}

async updateBalanceVisually(userId, newBalance, newExp) {
  this.repositories.socket.publishToUser(userId, 'user:updateBalance', { value: newBalance, exp: newExp, time: Date.now() });
}




}