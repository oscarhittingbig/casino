const { v1: uuidv1 } = require('uuid');

module.exports = class {

    constructor(params) {
      params.inject(this);
    }

    on_setSocketProperty(data) {
     
       const userSockets = this.repositories.socket.getUsersInRoom(data.userId);
       userSockets.forEach(user => {
         const propertyTreeNodes = data.property.split('.');
         if (propertyTreeNodes.length == 1) user[propertyTreeNodes[0]] = data.value; 
         else if (propertyTreeNodes.length == 2) user[propertyTreeNodes[0]][propertyTreeNodes[1]] = data.value;
       });

    }
  
  
  }