const CPModule = require("coinpayments");
const CPClient = new CPModule({
    key: process.env.COINPAYMENTS_API_PUBLIC,
    secret: process.env.COINPAYMENTS_API_PRIVATE
});
const Mutex = require('async-mutex').Mutex;


module.exports = class {
    constructor(params) {
        params.inject(this);
        this.defs = {
            availableCurrencies: ["BTC", "ETH", "LTC", "DOGE"]
        };
        this.mutexes = {};
    }

    async getPrices() {
        const cacheKey = 'cryptos-pricing';
        const cachedPricing = this.modules.cache.memGet(cacheKey);
        if (cachedPricing) return cachedPricing;

        const ratesResponse = await CPClient.rates({ short: 1, accepted: 1 });
        const BTC_USD = 1 / (ratesResponse['USD'].rate_btc);
        const prices = {};
        this.defs.availableCurrencies.forEach((currency) => {
            prices[currency] = parseFloat((parseFloat(ratesResponse[currency].rate_btc) * BTC_USD).toFixed(0));
        });
        this.modules.cache.memSet(cacheKey, prices, 60);
        return prices;        
    }

    getUserMutex(userId) {
        if (this.mutexes.hasOwnProperty(userId)) return this.mutexes[userId];
        else {
            this.mutexes[userId] = new Mutex();
            return this.mutexes[userId];
        }
    }

    async createWallet(currency, userId) {
        const response = await CPClient.getCallbackAddress({ currency, label: `GAINSGG_DEPOSIT_USER_${userId}_${currency}`, ipn_url: `${process.env.domain}coinpayments/callback` }).catch(err => {
            throw new Error("Wallet couldn't be created!");
        })
        const address = response.address;
        const insertSuccess = await this.modules.db.exec("INSERT INTO coinpayments_wallets SET ?", [{
            currency,
            address,
            assignedTo: userId,
            createdAt: Math.floor(Date.now() / 1000)

        }]);
        if (!insertSuccess) throw new Error("Something went wrong while inserting your wallet address to the database!");
        return address;
    }

    async getUserWalletAddress(currency, userId) {
        let walletAddress = null;

        const release = await this.getUserMutex(userId).acquire();
        try {
            const dbWallet = (await this.modules.db.query("SELECT address FROM coinpayments_wallets WHERE currency = ? AND assignedTo = ?", [currency, userId]));
            if (dbWallet.length == 0) walletAddress = await this.createWallet(currency, userId);
            else walletAddress = dbWallet[0].address;
        } catch(err) {
            console.log(err)
        } finally {
            release();
        }

        return walletAddress;
    }

}