const crypto = require(`crypto`),
    qs = require(`querystring`);

module.exports = class {

    constructor(params) {
        params.inject(this);

        //this.testFunc();
    }

    testFunc() {
        const body = `{"address":"MEFzjJgiP9sEN2Nb64pGNWVQ7YbZLQJuSq","amount":"0.00800000","amounti":"800000","confirms":"0","currency":"LTC","deposit_id":"CDFIO4PAJHNZ70OIK78MULUDD3","fiat_amount":"1.46083370","fiat_amounti":"146083370","fiat_coin":"USD","ipn_id":"664ececcf16351fe09aeb93351c45ad2","ipn_mode":"hmac","ipn_type":"deposit","ipn_version":"1.0","label":"RUSTYSALOON_DEPOSIT_USER_45_LTC","merchant":"64c62f2c479a811980aee2c3557fc87f","status":"0","status_text":"Deposit seen on network, but not confirmed","txn_id":"567d40107fdf82bcaa36a5b2d0c828dcd9d7c9e91445cc01011eaca8f86a9111"}`;
        const bodyObj = JSON.parse(body);
        //console.log(bodyObj)
        this.verify("ec4afbc41df98446a8a6f3773ffbb45fc9899611c45b9645268bfd48108704a7c6bc08cf76129bde68dd4cae6303d7e0d0668f55da9e48e38a9b2ffa15c79335", process.env.COINPAYMENTS_API_IPN_SECRET, bodyObj);
    }

    generateQueryData(data) {
        let params = new URLSearchParams();
        Object.keys(data).forEach(key => {
            params.append(key, data[key]);
        })
        return params;
    }


    verify(hmac = ``, ipnSecret = ``, payload) {
        if (!hmac || typeof hmac !== `string`)
            throw new Error(`Invalid hmac`);
        if (!ipnSecret || typeof ipnSecret !== `string`)
            throw new Error(`Invalid ipnSecret`);
        if (typeof payload !== `object`)
            throw new Error(`Payload is not an object`);

            /*
        var paramString = Object.keys(payload).map((key) => {
            return encodeURIComponent(key) + '=' + encodeURIComponent(payload[key])
        }).join('&');
        */

        const paramString = qs.stringify(payload).replace(/%20/g, `+`);
        const calcHmac = crypto
            .createHmac(`sha512`, ipnSecret)
            .update(paramString)
            .digest(`hex`);

            this.modules.logger.log("coinpayments-callbacks", `Calculated HMAC: ${calcHmac}`);
        if (hmac !== calcHmac) return false;
        return true;
    }


    async handleCallback(req, res) {
        try {
            const ipAddr = req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
            this.modules.logger.log("coinpayments-callbacks", `${ipAddr} -> Body: ${JSON.stringify(req.body)}`);
            this.modules.logger.log("coinpayments-callbacks", `${ipAddr} -> Headers: ${JSON.stringify(req.headers)}`);

            let { merchant, deposit_id, ipn_type, status, address, txn_id, currency, amount, fiat_amount } = req.body;
            if (merchant != process.env.COINPAYMENTS_API_MERCHANTID) return this.modules.logger.log("coinpayments-callbacks", `${ipAddr} -> Merchant Id is not ours!`);

            const hmac = req.headers["hmac"];
            let isValid = false, error = '';
            try {
                isValid = this.verify(hmac, process.env.COINPAYMENTS_API_IPN_SECRET, req.body);
            } catch (e) {
                error = e.message;
            }

            if (!isValid) return this.modules.logger.log("coinpayments-callbacks", `${ipAddr} -> SECURITY not passed!`);
            this.modules.logger.log("coinpayments-callbacks", `${ipAddr} -> SECURITY Passed!`);

            if (ipn_type !== "deposit") return;

            const dbWalletSql = await this.modules.db.query("SELECT assignedTo FROM coinpayments_wallets WHERE currency = ? AND address = ?", [currency, address]);
            if (dbWalletSql.length == 0) return this.modules.logger.log("coinpayments-callbacks", `${ipAddr} -> Wallet addr doesn't belong to anyone!`);

            const walletOwnerId = dbWalletSql[0].assignedTo;
            const fiatAmount = parseFloat(fiat_amount) * 100;
            status = parseInt(status);

            const dbTransactionExists = !(await this.modules.db.exec("INSERT IGNORE INTO coinpayments_transactions SET ?", [{
                coinpaymentsId: deposit_id,
                currency,
                userId: walletOwnerId,
                type: 'DEPOSIT',
                status,
                cryptoAmount: amount,
                fiatAmount,
                txId: txn_id,
                createdAt: Math.floor(Date.now() / 1000)
            }]));

            const lastDbTransaction = await this.modules.db.select("coinpayments_transactions", "coinpaymentsId", deposit_id);
            if (!dbTransactionExists || lastDbTransaction.status != status) await this.processTransaction(lastDbTransaction, dbTransactionExists, status);
            res.json({ success: true });
        } catch (err) {
            console.log(err.stack)
            this.modules.logger.log("coinpayments-callback-errors", `Something went wrong! -- ${err.message} -- ${JSON.stringify(err.stack)}`);
        }
    }

    async processTransaction(dbTransaction, dbTransactionExists, newStatus) {
        const coinsAmount = Math.floor(dbTransaction.fiatAmount * 10 * 1.4);

        //if (!dbTransactionExists)
            //this.repositories.user.notify({userId: dbTransaction.userId, message: 'API_COINPAYMENTS_IPN_NEWTRANSACTION', messageParams: [coinsAmount]})
            //this.externalModules.user.sendToUser(dbTransaction.userId, "cryptocurrencies:walletUnshiftTransaction", { id: dbTransaction.id, status: newStatus, cryptoAmount: dbTransaction.cryptoAmount, fiatAmount: dbTransaction.fiatAmount, createdAt: dbTransaction.createdAt });

        switch (newStatus) {
            //Seen on network
            case 0:
                this.modules.logger.log("coinpayments-deposits", `Id #${dbTransaction.id} -- User Id #${dbTransaction.userId} has a new ${dbTransaction.currency} deposit that has been seen on network! Amount: ${dbTransaction.cryptoAmount} | Fiat Amount: ${dbTransaction.fiatAmount}`);
                this.repositories.user.notify({userId: dbTransaction.userId, type: 'success', message: 'API_COINPAYMENTS_IPN_TRANSACTIONSEEN', messageParams: [dbTransaction.currency]})
                //this.externalModules.user.sendMsg(dbTransaction.userId, { type: "success", msg: `Your ${dbTransaction.currency} deposit has been successfully seen on network!` });
                break;

            //Completed
            case 100:
                
                await this.modules.db.exec("UPDATE coinpayments_transactions SET coinsAmount = ? WHERE id = ?", [coinsAmount, dbTransaction.id]);
                this.modules.logger.log("coinpayments-deposits", `Id #${dbTransaction.id} -- User Id #${dbTransaction.userId} deposit completed! -- Coin Amount: ${coinsAmount}`);
                
                await this.repositories.user.updateBalance({way: 'IN', userId: dbTransaction.userId, amount: coinsAmount, transactionType: 'DEPOSIT_COINPAYMENTS', alterType: 'DEPOSIT', alterName: 'COINPAYMENTS' });
                this.repositories.user.notify({userId: dbTransaction.userId, type: 'success', message: 'API_COINPAYMENTS_IPN_TRANSACTIONCOMPLETED', messageParams: [dbTransaction.currency, coinsAmount]})

                
                //this.externalModules.user.sendToUser(dbTransaction.userId, "cryptocurrencies:walletUpdateTransactionStatus", { transactionId: dbTransaction.id, newStatus });
                //this.externalModules.user.sendMsg(dbTransaction.userId, { type: "success", msg: `Your ${dbTransaction.currency} deposit has been completed and you got ${(coinsAmount / 100).toFixed(2)} coins!` });
                break;

            default:

                break;
        }

        const updateSuccess = await this.modules.db.exec("UPDATE coinpayments_transactions SET status = ? WHERE id = ?", [newStatus, dbTransaction.id]);
        if (!updateSuccess) this.modules.logger.log("coinpayments-callback-errors", `Transaction couldn't be updated! -- ${JSON.stringify(dbTransaction)} -- New Status: ${newStatus}`);
        //Update there
    }

}