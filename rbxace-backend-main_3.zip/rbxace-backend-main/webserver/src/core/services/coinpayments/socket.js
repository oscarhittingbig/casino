module.exports = class {

    constructor(params) {
        params.inject(this);
    }

    async injectEventHandlers(socket) {
        try {
            socket.on("cryptocurrencies:getWallet", (data) => this.on_getWallet(socket, data));
        } catch (err) {
            console.log('ERRRR!');
        }
    }

    async on_getWallet(socket, data) {
        const userId = this.externalModules.user.getId(socket);
        if (!userId) return;

        const currency = data.currency;
        if (!this.services.coinpayments.core.defs.availableCurrencies.includes(currency)) return;
        try {
            const address = await this.services.coinpayments.core.getUserWalletAddress(currency, userId);
            const transactions = await this.modules.db.query("SELECT currency, fiatAmount, cryptoAmount, status, createdAt FROM coinpayments_transactions WHERE currency = ? AND userId = ? AND type = 'DEPOSIT' ORDER BY createdAt DESC LIMIT 5", [currency, userId])
            socket.emit("cryptocurrencies:walletInfo", {
                currency,
                address,
                transactions
            });
        } catch(err) {
            return socket.emit("message", {
                type: "error",
                msg: err.message
            })
        }
    }


}